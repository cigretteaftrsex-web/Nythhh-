.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static action_bar:I = 0x7f080034

.field public static action_bar_activity_content:I = 0x7f080035

.field public static action_bar_container:I = 0x7f080036

.field public static action_bar_root:I = 0x7f080037

.field public static action_bar_spinner:I = 0x7f080038

.field public static action_bar_subtitle:I = 0x7f080039

.field public static action_bar_title:I = 0x7f08003a

.field public static action_context_bar:I = 0x7f08003c

.field public static action_menu_divider:I = 0x7f08003f

.field public static action_menu_presenter:I = 0x7f080040

.field public static action_mode_bar:I = 0x7f080041

.field public static action_mode_bar_stub:I = 0x7f080042

.field public static action_mode_close_button:I = 0x7f080043

.field public static activity_chooser_view_content:I = 0x7f080046

.field public static add:I = 0x7f08004a

.field public static alertTitle:I = 0x7f08004d

.field public static buttonPanel:I = 0x7f0800d2

.field public static checkbox:I = 0x7f0800f7

.field public static checked:I = 0x7f0800f8

.field public static content:I = 0x7f080114

.field public static contentPanel:I = 0x7f080115

.field public static custom:I = 0x7f080122

.field public static customPanel:I = 0x7f080123

.field public static decor_content_parent:I = 0x7f080129

.field public static default_activity_button:I = 0x7f08012a

.field public static edit_query:I = 0x7f080148

.field public static expand_activities_button:I = 0x7f080153

.field public static expanded_menu:I = 0x7f080154

.field public static group_divider:I = 0x7f080171

.field public static home:I = 0x7f080178

.field public static icon:I = 0x7f08017c

.field public static image:I = 0x7f080184

.field public static listMode:I = 0x7f0801dc

.field public static list_item:I = 0x7f0801dd

.field public static message:I = 0x7f080217

.field public static multiply:I = 0x7f080243

.field public static none:I = 0x7f080250

.field public static normal:I = 0x7f080251

.field public static off:I = 0x7f080262

.field public static on:I = 0x7f080263

.field public static parentPanel:I = 0x7f080288

.field public static progress_circular:I = 0x7f0802aa

.field public static progress_horizontal:I = 0x7f0802ab

.field public static radio:I = 0x7f0802ac

.field public static screen:I = 0x7f0802d3

.field public static scrollIndicatorDown:I = 0x7f0802d5

.field public static scrollIndicatorUp:I = 0x7f0802d6

.field public static scrollView:I = 0x7f0802d8

.field public static search_badge:I = 0x7f0802da

.field public static search_bar:I = 0x7f0802db

.field public static search_button:I = 0x7f0802dc

.field public static search_close_btn:I = 0x7f0802dd

.field public static search_edit_frame:I = 0x7f0802de

.field public static search_go_btn:I = 0x7f0802df

.field public static search_mag_icon:I = 0x7f0802e0

.field public static search_plate:I = 0x7f0802e1

.field public static search_src_text:I = 0x7f0802e2

.field public static search_voice_btn:I = 0x7f0802e3

.field public static select_dialog_listview:I = 0x7f0802e6

.field public static shortcut:I = 0x7f0802f0

.field public static spacer:I = 0x7f080301

.field public static split_action_bar:I = 0x7f08030c

.field public static src_atop:I = 0x7f080311

.field public static src_in:I = 0x7f080312

.field public static src_over:I = 0x7f080313

.field public static submenuarrow:I = 0x7f08031d

.field public static submit_area:I = 0x7f08031e

.field public static tabMode:I = 0x7f08033e

.field public static textSpacerNoButtons:I = 0x7f080360

.field public static textSpacerNoTitle:I = 0x7f080361

.field public static title:I = 0x7f08036e

.field public static titleDividerNoCustom:I = 0x7f08036f

.field public static title_template:I = 0x7f080370

.field public static topPanel:I = 0x7f080374

.field public static unchecked:I = 0x7f080466

.field public static uniform:I = 0x7f080467

.field public static up:I = 0x7f080469

.field public static wrap_content:I = 0x7f08047b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
