import React from 'react';
import {
  ChevronLeft,
  Coins,
  Gamepad2,
  Gift,
  LayoutDashboard,
  Package,
  User,
} from 'lucide-react';
import { KONG_ASSETS } from '../lib/kongAssets';
import type { AppRoute, SavedAccount } from '../types';

interface TopBarProps {
  currentRoute: AppRoute;
  activeAccount: SavedAccount | null;
  onNavigate: (route: AppRoute) => void;
  onOpenPointsSheet: () => void;
}

export function TopBar({ currentRoute, activeAccount, onNavigate, onOpenPointsSheet }: TopBarProps) {
  const isGamesGroup =
    currentRoute === 'kong-island' ||
    currentRoute === 'kong-shop' ||
    currentRoute === 'kong-exchange' ||
    currentRoute === 'kong-spin' ||
    currentRoute === 'beat-zoo' ||
    currentRoute === 'car-racing' ||
    currentRoute === 'fighting-fish' ||
    currentRoute === 'kitty-fall' ||
    currentRoute === 'soft-climbers' ||
    currentRoute === 'myid-go';

  const isPointsGroup =
    currentRoute === 'points-exchange' || currentRoute === 'points-history';

  const navItems: { id: AppRoute; label: string; active: boolean; action: () => void }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      active: currentRoute === 'dashboard',
      action: () => onNavigate('dashboard'),
    },
    {
      id: 'kong-island',
      label: 'Kong Island',
      active: isGamesGroup,
      action: () => onNavigate('kong-island'),
    },
    {
      id: 'daily-claim',
      label: 'Daily Quest',
      active: currentRoute === 'daily-claim',
      action: () => onNavigate('daily-claim'),
    },
    {
      id: 'points-exchange',
      label: 'Points',
      active: isPointsGroup,
      action: onOpenPointsSheet,
    },
    {
      id: 'data-packages',
      label: 'Packages',
      active: currentRoute === 'data-packages',
      action: () => onNavigate('data-packages'),
    },
  ];

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-white/[0.08] bg-[#0C0F14]/92 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-4 sm:gap-8 px-4 sm:px-6">
          {/* Zone 1: Brand wordmark only */}
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C8942A] rounded-lg active:scale-[0.97] transition-transform"
          >
            <img
              src={KONG_ASSETS.brandMark}
              alt="KongPulse mark"
              referrerPolicy="no-referrer"
              className="h-7 w-7 rounded-lg object-cover border border-white/10"
            />
            <span className="font-display text-lg font-bold tracking-tight text-white">
              KongPulse
            </span>
          </button>

          {/* Zone 2: Clean single-line text nav links (Desktop) */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={item.action}
                className={`relative py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C8942A] rounded ${
                  item.active ? 'text-[#E8B040]' : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {item.label}
                {item.active && (
                  <span className="absolute inset-x-0 -bottom-[15px] h-0.5 bg-[#E8B040]" />
                )}
              </button>
            ))}
          </nav>

          {/* Zone 3: Account switcher button */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('accounts')}
              className="min-h-[40px] rounded-xl border border-white/10 bg-[#161A22] px-3 sm:px-3.5 py-1.5 flex items-center gap-2 text-xs font-semibold text-slate-100 hover:border-[#C8942A]/50 hover:bg-[#1E232E] active:scale-[0.97] transition-all whitespace-nowrap shrink-0 tabular-nums"
            >
              <span className="h-6 w-6 rounded-full bg-[#222834] border border-white/10 overflow-hidden flex items-center justify-center shrink-0">
                {activeAccount?.avatarUrl ? (
                  <img
                    src={activeAccount.avatarUrl}
                    alt={activeAccount.fullName}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <User className="h-3.5 w-3.5 text-slate-400" />
                )}
              </span>
              <span className="max-w-[110px] truncate font-mono-num">
                {activeAccount ? activeAccount.phone : 'Accounts'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Android / Mobile Bottom Navigation Bar (Thumb Zone + safe area) */}
      <nav
        aria-label="Primary mobile navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-white/[0.08] bg-[#0E1218]/95 backdrop-blur-lg safe-pb"
      >
        <div className="grid grid-cols-5 h-14 items-stretch">
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className={`relative flex flex-col items-center justify-center min-h-[44px] active:scale-95 transition-transform ${
              currentRoute === 'dashboard' ? 'text-[#E8B040]' : 'text-slate-400'
            }`}
          >
            {currentRoute === 'dashboard' && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 h-0.5 w-7 rounded-full bg-[#E8B040]" />
            )}
            <LayoutDashboard className="h-[20px] w-[20px]" />
            <span className="text-[10px] font-semibold mt-1 tracking-tight whitespace-nowrap">
              Home
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('kong-island')}
            className={`relative flex flex-col items-center justify-center min-h-[44px] active:scale-95 transition-transform ${
              isGamesGroup ? 'text-[#E8B040]' : 'text-slate-400'
            }`}
          >
            {isGamesGroup && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 h-0.5 w-7 rounded-full bg-[#E8B040]" />
            )}
            <Gamepad2 className="h-[20px] w-[20px]" />
            <span className="text-[10px] font-semibold mt-1 tracking-tight whitespace-nowrap">
              Games
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('daily-claim')}
            className={`relative flex flex-col items-center justify-center min-h-[44px] active:scale-95 transition-transform ${
              currentRoute === 'daily-claim' ? 'text-[#E8B040]' : 'text-slate-400'
            }`}
          >
            {currentRoute === 'daily-claim' && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 h-0.5 w-7 rounded-full bg-[#E8B040]" />
            )}
            <Gift className="h-[20px] w-[20px]" />
            <span className="text-[10px] font-semibold mt-1 tracking-tight whitespace-nowrap">
              Quest
            </span>
          </button>

          <button
            type="button"
            onClick={onOpenPointsSheet}
            className={`relative flex flex-col items-center justify-center min-h-[44px] active:scale-95 transition-transform ${
              isPointsGroup ? 'text-[#E8B040]' : 'text-slate-400'
            }`}
          >
            {isPointsGroup && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 h-0.5 w-7 rounded-full bg-[#E8B040]" />
            )}
            <Coins className="h-[20px] w-[20px]" />
            <span className="text-[10px] font-semibold mt-1 tracking-tight whitespace-nowrap">
              Points
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('data-packages')}
            className={`relative flex flex-col items-center justify-center min-h-[44px] active:scale-95 transition-transform ${
              currentRoute === 'data-packages' ? 'text-[#E8B040]' : 'text-slate-400'
            }`}
          >
            {currentRoute === 'data-packages' && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 h-0.5 w-7 rounded-full bg-[#E8B040]" />
            )}
            <Package className="h-[20px] w-[20px]" />
            <span className="text-[10px] font-semibold mt-1 tracking-tight whitespace-nowrap">
              Packs
            </span>
          </button>
        </div>
      </nav>
    </>
  );
}

export function PageBackHeader({
  title,
  subtitle,
  onBack,
  rightSlot,
}: {
  title: string;
  subtitle?: string;
  onBack: () => void;
  rightSlot?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 pb-4 sm:pb-5">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onBack}
          aria-label="Go back"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 hover:text-white active:scale-95 transition-all"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div className="min-w-0">
          <h1 className="font-display text-xl sm:text-2xl font-bold text-white truncate">
            {title}
          </h1>
          {subtitle && (
            <p className="text-xs text-slate-400 truncate mt-0.5">{subtitle}</p>
          )}
        </div>
      </div>
      {rightSlot && <div className="shrink-0">{rightSlot}</div>}
    </div>
  );
}
