import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { kongApi } from '../lib/api';
import type { KongUserInfo, SavedAccount } from '../types';

const GAME_DURATION_MS = 600_000; // 10 minutes (0x927c0 from KongIslandService)
const BANANA_INTERVAL_MS = 30; // 30ms tick (0x1e)
const MAP_ROTATE_INTERVAL_MS = 4_000; // 4s GROUND_SELECTED rotation
const AUTO_X2_INTERVAL_MS = 10_000; // 10s X2BANANA item refresh
const BETWEEN_GAMES_MS = 5_000; // 5s pause between games
const RECONNECT_DELAY_MS = 1_500;
const STALL_TIMEOUT_MS = 12_000;
const END_GAME_GRACE_MS = 5_000;
const START_PAYLOAD_DATA =
  'ZbZH3MS3Hdgv6nBzZPOdM07+y9xKB3RF54XeWY4VygUDD4AOykAwXfjylRy/kbT5knHNtqbPjQSiMPszBpB4Ug==';

const ALL_MAPS = [
  '62;7;57',
  '22;34;20',
  '78;10;42',
  '82;46;54',
  '16;55;3',
  '6;38;32',
  '69;50;28',
  '28;81;75',
  '47;11;61',
  '31;39;69',
  '4;60;55',
  '59;81;78',
  '26;81;10',
  '17;39;62',
];

export interface KongRunnerContextValue {
  kongToken: string;
  userInfo: KongUserInfo | null;
  loadingInfo: boolean;
  authError: string;
  isPlaying: boolean;
  alwaysLoop: boolean;
  autoX2: boolean;
  currentGame: number;
  totalGames: number;
  elapsedMs: number;
  gameDurationMs: number;
  liveBananas: number;
  serverMax: number;
  bananaRatePerMin: number;
  x2ActiveUntil: number | null;
  startedAt: number | null;
  estEndAt: number | null;
  statusMessage: string;
  ensureKongSession: (account: SavedAccount, forceRefresh?: boolean) => Promise<string | null>;
  refreshUserInfo: (tokenOverride?: string) => Promise<KongUserInfo | null>;
  startGames: (count: number, loop: boolean, tokenOverride?: string, useAutoX2?: boolean) => void;
  stopGames: () => void;
  useX2Banana: () => void;
  setAlwaysLoopState: (loop: boolean) => void;
  setAutoX2State: (enabled: boolean) => void;
  clearKongState: () => void;
}

const KongRunnerContext = createContext<KongRunnerContextValue | null>(null);

export function KongRunnerProvider({
  children,
  onTokenUpdate,
}: {
  children: React.ReactNode;
  onTokenUpdate?: (phone: string, kongToken: string, profile?: Partial<KongUserInfo>) => void;
}) {
  const [kongToken, setKongToken] = useState('');
  const [userInfo, setUserInfo] = useState<KongUserInfo | null>(null);
  const [loadingInfo, setLoadingInfo] = useState(false);
  const [authError, setAuthError] = useState('');

  const [isPlaying, setIsPlaying] = useState(false);
  const [alwaysLoop, setAlwaysLoopState] = useState(false);
  const [autoX2, setAutoX2State] = useState(false);
  const [currentGame, setCurrentGame] = useState(0);
  const [totalGames, setTotalGames] = useState(1);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [liveBananas, setLiveBananas] = useState(0);
  const [serverMax, setServerMax] = useState(0);
  const [bananaRatePerMin, setBananaRatePerMin] = useState(0);
  const [x2ActiveUntil, setX2ActiveUntil] = useState<number | null>(null);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [estEndAt, setEstEndAt] = useState<number | null>(null);
  const [statusMessage, setStatusMessage] = useState('');

  const activeWsRef = useRef<WebSocket | null>(null);
  const stopFlagRef = useRef(false);
  const loopFlagRef = useRef(false);
  const autoX2Ref = useRef(false);
  const total2xBananaRef = useRef(0);
  const tokenRef = useRef('');
  const timerTickRef = useRef<number | null>(null);
  const bananaTickRef = useRef<number | null>(null);
  const mapRotateTickRef = useRef<number | null>(null);
  const autoX2TickRef = useRef<number | null>(null);
  const stallCheckRef = useRef<number | null>(null);
  const endGameGraceTimerRef = useRef<number | null>(null);
  const lastAckRef = useRef<number>(Date.now());
  const baselineBananasRef = useRef<number | null>(null);

  useEffect(() => {
    loopFlagRef.current = alwaysLoop;
  }, [alwaysLoop]);

  useEffect(() => {
    autoX2Ref.current = autoX2;
  }, [autoX2]);

  useEffect(() => {
    total2xBananaRef.current = userInfo?.total2xBanana ?? 0;
  }, [userInfo?.total2xBanana]);

  const clearSocketIntervals = useCallback(() => {
    if (bananaTickRef.current) {
      window.clearInterval(bananaTickRef.current);
      bananaTickRef.current = null;
    }
    if (mapRotateTickRef.current) {
      window.clearInterval(mapRotateTickRef.current);
      mapRotateTickRef.current = null;
    }
    if (autoX2TickRef.current) {
      window.clearInterval(autoX2TickRef.current);
      autoX2TickRef.current = null;
    }
    if (stallCheckRef.current) {
      window.clearInterval(stallCheckRef.current);
      stallCheckRef.current = null;
    }
  }, []);

  const cleanupGameTimers = useCallback(() => {
    if (timerTickRef.current) {
      window.clearInterval(timerTickRef.current);
      timerTickRef.current = null;
    }
    if (endGameGraceTimerRef.current) {
      window.clearTimeout(endGameGraceTimerRef.current);
      endGameGraceTimerRef.current = null;
    }
    clearSocketIntervals();
    if (activeWsRef.current) {
      try {
        activeWsRef.current.close();
      } catch {
        // ignore
      }
      activeWsRef.current = null;
    }
  }, [clearSocketIntervals]);

  const refreshUserInfo = useCallback(
    async (tokenOverride?: string): Promise<KongUserInfo | null> => {
      const tok = tokenOverride || tokenRef.current;
      if (!tok) return null;
      try {
        const res = await kongApi.getUserInfo(tok);
        const data = res?.data;
        if (!data) return null;
        const gd = data.gameData || {};
        const parsed: KongUserInfo = {
          playerName: data.playerName || data.msisdn || 'Kong Player',
          msisdn: data.msisdn || '',
          avatar: data.avatar || '',
          totalBanana: Number(gd.totalBanana || 0),
          totalTicket: Number(gd.totalTicket || 0),
          totalBox: Number(gd.totalBox || 0),
          total2xBanana: Number(gd.total2xBanana || 0),
          totalMagnet: Number(gd.totalMagnet || 0),
          totalProtect: Number(gd.totalProtect || 0),
          totalReborn: Number(gd.totalReborn || 0),
          turnFree: Number(gd.turnFree || 0),
        };
        total2xBananaRef.current = parsed.total2xBanana;
        setUserInfo(parsed);
        return parsed;
      } catch {
        return null;
      }
    },
    []
  );

  const ensureKongSession = useCallback(
    async (account: SavedAccount, forceRefresh = false): Promise<string | null> => {
      setLoadingInfo(true);
      setAuthError('');
      try {
        let tok = !forceRefresh ? account.kongToken || '' : '';
        if (tok) {
          tokenRef.current = tok;
          setKongToken(tok);
          const info = await refreshUserInfo(tok);
          if (info) {
            setAuthError('');
            setLoadingInfo(false);
            return tok;
          }
          tok = '';
        }

        if (!account.thirdPartyToken || !account.mcuid) {
          setAuthError('Session token missing. Please re-verify OTP.');
          setLoadingInfo(false);
          return null;
        }

        const loginRes = await kongApi.loginViaGateway({
          thirdPartyToken: account.thirdPartyToken,
          mcuid: account.mcuid,
          phone: account.phone,
          avatar: account.avatarUrl,
          fullName: account.fullName,
        });

        const newToken = loginRes?.data?.accessToken;
        if (!newToken) {
          throw new Error(loginRes?.message || 'Kong Island login failed');
        }

        tokenRef.current = newToken;
        setKongToken(newToken);
        setAuthError('');
        const info = await refreshUserInfo(newToken);
        onTokenUpdate?.(account.phone, newToken, info || undefined);
        setLoadingInfo(false);
        return newToken;
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unable to connect to Kong Island';
        setAuthError(msg);
        setLoadingInfo(false);
        return null;
      }
    },
    [onTokenUpdate, refreshUserInfo]
  );

  const sendX2ItemOnSocket = useCallback((ws: WebSocket | null) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return false;
    if (total2xBananaRef.current <= 0) return false;
    ws.send(
      JSON.stringify({
        type: 'USE_ITEM',
        payload: { itemType: 'X2BANANA', isUserItem: true },
      })
    );
    total2xBananaRef.current = Math.max(0, total2xBananaRef.current - 1);
    setUserInfo((prev) =>
      prev ? { ...prev, total2xBanana: Math.max(0, prev.total2xBanana - 1) } : prev
    );
    setX2ActiveUntil(Date.now() + AUTO_X2_INTERVAL_MS);
    return true;
  }, []);

  const runSingleGame = useCallback(
    (gameIndex: number, tok: string): Promise<void> => {
      return new Promise((resolve) => {
        const gameStart = Date.now();
        const gameDeadline = gameStart + GAME_DURATION_MS;
        baselineBananasRef.current = null;
        setStartedAt(gameStart);
        setEstEndAt(gameDeadline);
        setElapsedMs(0);
        setLiveBananas(0);
        setServerMax(0);
        setBananaRatePerMin(0);
        setX2ActiveUntil(null);
        setCurrentGame(gameIndex);

        let gameDone = false;
        let endSent = false;
        let mapIdx = 0;

        const finishGame = () => {
          if (gameDone) return;
          gameDone = true;
          cleanupGameTimers();
          resolve();
        };

        timerTickRef.current = window.setInterval(() => {
          const now = Date.now();
          const elapsed = Math.min(GAME_DURATION_MS, now - gameStart);
          setElapsedMs(elapsed);

          if (now >= gameDeadline && !gameDone && !endSent) {
            endSent = true;
            if (activeWsRef.current && activeWsRef.current.readyState === WebSocket.OPEN) {
              activeWsRef.current.send(
                JSON.stringify({ type: 'END_GAME', payload: { complete: true } })
              );
              endGameGraceTimerRef.current = window.setTimeout(finishGame, END_GAME_GRACE_MS);
            } else {
              finishGame();
            }
          }
        }, 500);

        const connectAttempt = () => {
          if (stopFlagRef.current || gameDone) {
            finishGame();
            return;
          }

          const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
          const wsUrl = `${proto}//${window.location.host}/ws/kong?authToken=${encodeURIComponent(tok)}`;
          const ws = new WebSocket(wsUrl);
          activeWsRef.current = ws;
          lastAckRef.current = Date.now();

          ws.onmessage = (evt) => {
            try {
              const msg = JSON.parse(evt.data);
              if (msg.type === 'BRIDGE_OPEN') {
                setStatusMessage('');
                ws.send(
                  JSON.stringify({
                    type: 'START_GAME',
                    payload: { data: START_PAYLOAD_DATA, lang: 'my' },
                  })
                );

                // Initial map selection (Unix seconds timestamp per KongIslandService$1)
                const sendNextMap = () => {
                  if (stopFlagRef.current || gameDone || ws.readyState !== WebSocket.OPEN) return;
                  const mapList = ALL_MAPS[mapIdx % ALL_MAPS.length];
                  mapIdx += 1;
                  ws.send(
                    JSON.stringify({
                      type: 'GROUND_SELECTED',
                      payload: { mapList, timestamp: Math.floor(Date.now() / 1000) },
                    })
                  );
                };
                sendNextMap();

                if (mapRotateTickRef.current) window.clearInterval(mapRotateTickRef.current);
                mapRotateTickRef.current = window.setInterval(sendNextMap, MAP_ROTATE_INTERVAL_MS);

                // Auto X2 Banana item activation (on open + every 10s while enabled & available)
                if (autoX2Ref.current && total2xBananaRef.current > 0) {
                  sendX2ItemOnSocket(ws);
                }
                if (autoX2TickRef.current) window.clearInterval(autoX2TickRef.current);
                autoX2TickRef.current = window.setInterval(() => {
                  if (stopFlagRef.current || gameDone || ws.readyState !== WebSocket.OPEN) return;
                  if (autoX2Ref.current && total2xBananaRef.current > 0) {
                    sendX2ItemOnSocket(ws);
                  }
                }, AUTO_X2_INTERVAL_MS);

                // Send BANANA_COLLECTED every 30ms with Unix seconds timestamp
                if (bananaTickRef.current) window.clearInterval(bananaTickRef.current);
                bananaTickRef.current = window.setInterval(() => {
                  if (stopFlagRef.current || gameDone) return;
                  if (ws.readyState === WebSocket.OPEN) {
                    ws.send(
                      JSON.stringify({
                        type: 'BANANA_COLLECTED',
                        timestamp: Math.floor(Date.now() / 1000),
                      })
                    );
                  }
                }, BANANA_INTERVAL_MS);

                // Check for stalls
                if (stallCheckRef.current) window.clearInterval(stallCheckRef.current);
                stallCheckRef.current = window.setInterval(() => {
                  if (stopFlagRef.current || gameDone) return;
                  if (Date.now() - lastAckRef.current > STALL_TIMEOUT_MS) {
                    ws.close();
                  }
                }, 3000);
                return;
              }

              if (msg.type === 'BRIDGE_ERROR') {
                setStatusMessage(msg.message || 'WebSocket connection error');
                return;
              }

              if (msg.status === 'success') {
                lastAckRef.current = Date.now();
                const action = msg.action || '';
                if (action === 'BANANA_COLLECTED') {
                  const total = Number(msg.totalBananas ?? msg.total ?? 0);
                  const maxB = Number(msg.maxBananas ?? msg.max ?? 0);
                  if (baselineBananasRef.current === null) {
                    baselineBananasRef.current = 0;
                  }
                  const currentCount = Math.max(0, total - baselineBananasRef.current);
                  setLiveBananas(currentCount);
                  if (maxB > 0) setServerMax(maxB);

                  const elapsedMins = Math.max(1 / 60, (Date.now() - gameStart) / 60_000);
                  setBananaRatePerMin(Math.round(currentCount / elapsedMins));
                } else if (action === 'USE_ITEM') {
                  window.setTimeout(() => {
                    refreshUserInfo();
                  }, 400);
                } else if (action === 'END_GAME') {
                  finishGame();
                }
              }
            } catch {
              // ignore non-json
            }
          };

          ws.onclose = () => {
            clearSocketIntervals();
            if (!gameDone && !stopFlagRef.current && !endSent && Date.now() < gameDeadline) {
              window.setTimeout(connectAttempt, RECONNECT_DELAY_MS);
            } else {
              finishGame();
            }
          };

          ws.onerror = () => {
            try {
              ws.close();
            } catch {
              // ignore
            }
          };
        };

        connectAttempt();
      });
    },
    [cleanupGameTimers, clearSocketIntervals, refreshUserInfo, sendX2ItemOnSocket]
  );

  const startGames = useCallback(
    (count: number, loop: boolean, tokenOverride?: string, useAutoX2?: boolean) => {
      const tok = tokenOverride || tokenRef.current;
      if (!tok || isPlaying) return;

      stopFlagRef.current = false;
      loopFlagRef.current = loop;
      setAlwaysLoopState(loop);
      if (typeof useAutoX2 === 'boolean') {
        autoX2Ref.current = useAutoX2;
        setAutoX2State(useAutoX2);
      }
      setTotalGames(count);
      setIsPlaying(true);
      setStatusMessage('');

      (async () => {
        let gameNum = 0;
        while (!stopFlagRef.current) {
          if (!loopFlagRef.current && gameNum >= count) break;
          const info = await refreshUserInfo(tok);
          if (info && info.totalTicket <= 0) {
            setStatusMessage('ကစားကြိမ်ကုန်ပါပြီ (No tickets left)');
            break;
          }
          gameNum += 1;
          await runSingleGame(gameNum, tok);
          await refreshUserInfo(tok);
          if (stopFlagRef.current) break;
          if (!loopFlagRef.current && gameNum >= count) break;
          await new Promise((r) => window.setTimeout(r, BETWEEN_GAMES_MS));
        }
        cleanupGameTimers();
        setIsPlaying(false);
        setStartedAt(null);
        setEstEndAt(null);
        setX2ActiveUntil(null);
      })();
    },
    [cleanupGameTimers, isPlaying, refreshUserInfo, runSingleGame]
  );

  const stopGames = useCallback(() => {
    stopFlagRef.current = true;
    const ws = activeWsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify({ type: 'END_GAME', payload: { complete: false } }));
      } catch {
        // ignore
      }
    }
    cleanupGameTimers();
    setIsPlaying(false);
    setStartedAt(null);
    setEstEndAt(null);
    setX2ActiveUntil(null);
    setStatusMessage('ရပ်တန့်ပြီးပါပြီ (Stopped)');
  }, [cleanupGameTimers]);

  const useX2Banana = useCallback(() => {
    const ws = activeWsRef.current;
    if (sendX2ItemOnSocket(ws)) {
      window.setTimeout(() => {
        refreshUserInfo();
      }, 600);
    }
  }, [refreshUserInfo, sendX2ItemOnSocket]);

  const clearKongState = useCallback(() => {
    stopFlagRef.current = true;
    cleanupGameTimers();
    tokenRef.current = '';
    setKongToken('');
    setUserInfo(null);
    setAuthError('');
    setStatusMessage('');
    setIsPlaying(false);
    setX2ActiveUntil(null);
  }, [cleanupGameTimers]);

  return (
    <KongRunnerContext.Provider
      value={{
        kongToken,
        userInfo,
        loadingInfo,
        authError,
        isPlaying,
        alwaysLoop,
        autoX2,
        currentGame,
        totalGames,
        elapsedMs,
        gameDurationMs: GAME_DURATION_MS,
        liveBananas,
        serverMax,
        bananaRatePerMin,
        x2ActiveUntil,
        startedAt,
        estEndAt,
        statusMessage,
        ensureKongSession,
        refreshUserInfo,
        startGames,
        stopGames,
        useX2Banana,
        setAlwaysLoopState,
        setAutoX2State,
        clearKongState,
      }}
    >
      {children}
    </KongRunnerContext.Provider>
  );
}

export function useKongRunner(): KongRunnerContextValue {
  const ctx = useContext(KongRunnerContext);
  if (!ctx) {
    throw new Error('useKongRunner must be used inside KongRunnerProvider');
  }
  return ctx;
}
