async function requestJson<T = any>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(url, options);
  const text = await res.text();
  let data: any = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (res.status === 401) {
    throw new Error(data?.message || data?.error || 'Session expired (401). Please re-sync session.');
  }
  if (!res.ok && data?.errorCode === undefined && data?.success !== false) {
    throw new Error(data?.message || data?.error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const beatzooApi = {
  login(params: {
    thirdPartyToken: string;
    mcuid: string;
    phone: string;
    avatar?: string;
    fullName?: string;
  }) {
    return requestJson('/api/beatzoo/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  getBalance(jwt: string) {
    return requestJson('/api/beatzoo/balance', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getCurrency(jwt: string, code: 'ticket' | 'heart' | 'gem') {
    return requestJson(`/api/beatzoo/currency/${code}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getTopSongs(jwt: string) {
    return requestJson('/api/beatzoo/songs/top', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buySong(jwt: string, songId: number | string) {
    return requestJson('/api/beatzoo/songs/buy', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ song_id: songId }),
    });
  },
  startGamePlay(jwt: string, songId: number | string) {
    return requestJson('/api/beatzoo/game-play/start', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ song_id: songId }),
    });
  },
  saveScore(jwt: string, songId: number | string, score: number, mode: 'easy' | 'hard' = 'easy') {
    return requestJson('/api/beatzoo/songs/save-score', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ song_id: songId, score, mode }),
    });
  },
  getLeaderboard(jwt: string, type: 'weekly' | 'monthly' | 'overall' = 'weekly') {
    return requestJson(`/api/beatzoo/leaderboard?type=${encodeURIComponent(type)}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getMissions(jwt: string) {
    return requestJson('/api/beatzoo/missions', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  claimMission(jwt: string, missionId: number | string) {
    return requestJson('/api/beatzoo/missions/claim', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ mission_id: missionId }),
    });
  },
  getShopItems(jwt: string, kind: 'internal' | 'external') {
    return requestJson(`/api/beatzoo/shop/items/${kind}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyInternalItem(jwt: string, itemCode: string, note = '') {
    return requestJson('/api/beatzoo/cart/buy/internal', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_code: itemCode, note }),
    });
  },
  buyPaymentPackage(jwt: string, code: string) {
    return requestJson('/api/beatzoo/payment/package', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
  },
  getSpinPrizes(jwt: string) {
    return requestJson('/api/beatzoo/lucky-wheel/prizes', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  spinWheel(jwt: string) {
    return requestJson('/api/beatzoo/lucky-wheel/spin', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
  updateName(jwt: string, name: string) {
    return requestJson('/api/beatzoo/name', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
  },
};

export const carRacingApi = {
  login(params: {
    thirdPartyToken: string;
    mcuid: string;
    uuid?: string;
    phone: string;
    avatar?: string;
    fullName?: string;
  }) {
    return requestJson('/api/carracing/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  getUserInfo(jwt: string) {
    return requestJson('/api/carracing/user/info', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  updatePlayerName(jwt: string, playerName: string) {
    return requestJson('/api/carracing/user/player-name', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerName }),
    });
  },
  getAvatarList(jwt: string) {
    return requestJson('/api/carracing/avatar/list', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyAvatar(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/avatar/buy/${encodeURIComponent(String(id))}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyOrUseCar(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/car/buy-or-use/${encodeURIComponent(String(id))}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  checkPvp(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/game-pvp/check/${encodeURIComponent(String(id))}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  suggestPvpCars(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/game-pvp/suggest-cars/${encodeURIComponent(String(id))}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getConfigPvp(jwt: string, typeItem = 'COIN') {
    return requestJson(`/api/carracing/leaderboard/config-pvp?typeItem=${encodeURIComponent(typeItem)}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getLeaderboard(
    jwt: string,
    typeConfigRank: 'RANK_MONTH' | 'RANK_WEEK' = 'RANK_MONTH',
    typeRank = 'DISTANCE'
  ) {
    return requestJson(
      `/api/carracing/leaderboard/type?typeConfigRank=${encodeURIComponent(typeConfigRank)}&typeRank=${encodeURIComponent(typeRank)}`,
      { headers: { Authorization: `Bearer ${jwt}` } }
    );
  },
  getGemShop(jwt: string) {
    return requestJson('/api/carracing/shop/gem', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyShopItem(jwt: string, id: number | string, typeCurrency = 'GEM') {
    return requestJson('/api/carracing/shop/buy', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, typeCurrency }),
    });
  },
  getPackages(jwt: string, type: 'ALL' | 'RENEW' | 'RETAIL' = 'ALL') {
    return requestJson(`/api/carracing/package/list?type=${type}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyPackage(jwt: string, code: string) {
    return requestJson('/api/carracing/package/buy', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
  },
  getAchievements(jwt: string) {
    return requestJson('/api/carracing/achievement', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  claimAchievement(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/achievement/claim/${encodeURIComponent(String(id))}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
  getDailyLoginTasks(jwt: string) {
    return requestJson('/api/carracing/task/daily-login', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  claimDailyLoginTask(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/task/daily-login/claim/${encodeURIComponent(String(id))}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
  getUserTasks(jwt: string) {
    return requestJson('/api/carracing/task/user', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  claimUserTask(jwt: string, id: number | string) {
    return requestJson(`/api/carracing/task/user/claim/${encodeURIComponent(String(id))}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
  getSpinPrizes(jwt: string) {
    return requestJson('/api/carracing/lucky-spin', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  spinWheel(jwt: string) {
    return requestJson('/api/carracing/lucky-spin/spin', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
};

export const fishioApi = {
  login(params: {
    thirdPartyToken: string;
    mcuid: string;
    uuid?: string;
    phone: string;
    avatar?: string;
    fullName?: string;
  }) {
    return requestJson('/api/fishio/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  refresh(refreshToken: string) {
    return requestJson('/api/fishio/refresh', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
  },
  getUserInfo(jwt: string) {
    return requestJson('/api/fishio/user/info', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  updatePlayerName(jwt: string, playerName: string) {
    return requestJson('/api/fishio/user/player-name', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerName }),
    });
  },
  getAvatarList(jwt: string) {
    return requestJson('/api/fishio/avatar/list', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyAvatar(jwt: string, id: number | string) {
    return requestJson(`/api/fishio/avatar/buy/${encodeURIComponent(String(id))}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getLeaderboard(jwt: string, rankType: 'WEEK' | 'MONTH' | 'ALL' = 'WEEK') {
    return requestJson(`/api/fishio/leaderboard/rank?rankType=${encodeURIComponent(rankType)}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  getShopItems(jwt: string, typeCurrency = 'GEM') {
    return requestJson(`/api/fishio/shop/item?typeCurrency=${encodeURIComponent(typeCurrency)}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyShopItem(
    jwt: string,
    params: { code: string; value: number; quantity: number; amount: number }
  ) {
    return requestJson('/api/fishio/shop/item', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  getPackages(jwt: string, type: 'ALL' | 'RENEW' | 'RETAIL' = 'ALL') {
    return requestJson(`/api/fishio/package/list?type=${type}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  buyPackage(jwt: string, code: string) {
    return requestJson('/api/fishio/package/buy', {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
  },
  getAchievements(jwt: string) {
    return requestJson('/api/fishio/achievement/list', {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  claimAchievement(jwt: string, id: number | string) {
    return requestJson(`/api/fishio/achievement/claim/${encodeURIComponent(String(id))}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
  getTasks(jwt: string, type: 'DAILY' | 'USER' | 'EVENT' = 'DAILY') {
    return requestJson(`/api/fishio/task/list?type=${encodeURIComponent(type)}`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
  },
  claimTask(jwt: string, id: number | string) {
    return requestJson(`/api/fishio/task/award/${encodeURIComponent(String(id))}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  },
};

export const kittyFallApi = {
  bootstrap(params: {
    thirdPartyToken: string;
    phone: string;
    lang?: string;
    cookie?: string;
  }) {
    return requestJson('/api/kittyfall/bootstrap', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  startSession(params: {
    cookie: string;
    msisdn: string;
    token: string;
    transId: string;
    gameType?: string;
    level?: number;
    score?: number;
    gameOver?: number;
  }) {
    return requestJson('/api/kittyfall/start-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  saveResult(params: {
    cookie: string;
    msisdn: string;
    token: string;
    transId: string;
    level: number;
    score: number;
    gameType?: string;
    gameOver?: number;
  }) {
    return requestJson('/api/kittyfall/save-result', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  getLeaderboard(cookie: string, pageNumber = 1) {
    return requestJson(`/api/kittyfall/leaderboard?pageNumber=${pageNumber}`, {
      headers: { 'x-kitty-cookie': cookie },
    });
  },
  getHistory(cookie: string) {
    return requestJson('/api/kittyfall/history', {
      headers: { 'x-kitty-cookie': cookie },
    });
  },
  buyTurn(cookie: string, productName: string) {
    return requestJson('/api/kittyfall/buy-turn', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cookie, productName }),
    });
  },
  registerSubscription(cookie: string, productName: string) {
    return requestJson('/api/kittyfall/register-sub', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cookie, productName }),
    });
  },
};

export const softClimbersApi = {
  login(params: {
    msisdn: string;
    accessToken: string;
    avatar?: string;
    username?: string;
    lang?: string;
  }) {
    return requestJson('/api/softclimbers/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  getStatus(token: string, msisdn: string) {
    return requestJson('/api/softclimbers/subscription/status', {
      headers: { Authorization: `Bearer ${token}`, 'x-phone': msisdn },
    });
  },
  getLeaderboard(token: string, msisdn: string, type = 'WEEK') {
    return requestJson(`/api/softclimbers/leaderboard?type=${encodeURIComponent(type)}`, {
      headers: { Authorization: `Bearer ${token}`, 'x-phone': msisdn },
    });
  },
  getPrizeHistory(token: string, msisdn: string, page = 1, size = 20) {
    return requestJson(`/api/softclimbers/prize-history?page=${page}&size=${size}`, {
      headers: { Authorization: `Bearer ${token}`, 'x-phone': msisdn },
    });
  },
  getOneTimePlans(token: string, msisdn: string) {
    return requestJson('/api/softclimbers/plans/one-time', {
      headers: { Authorization: `Bearer ${token}`, 'x-phone': msisdn },
    });
  },
  purchaseAttempts(token: string, msisdn: string, planId: string | number) {
    return requestJson('/api/softclimbers/attempts/purchase', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'x-phone': msisdn,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ planId }),
    });
  },
  subscribe(token: string, msisdn: string, planId: string | number) {
    return requestJson('/api/softclimbers/subscription/subscribe', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'x-phone': msisdn,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ planId }),
    });
  },
  startGame(token: string, msisdn: string, level = 1) {
    return requestJson('/api/softclimbers/game/start', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'x-phone': msisdn,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ level }),
    });
  },
  sendEvent(
    token: string,
    msisdn: string,
    params: {
      sessionId: string | number;
      level: number;
      score: number;
      coins: number;
      distance: number;
      eventType?: string;
    }
  ) {
    return requestJson('/api/softclimbers/game/event', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'x-phone': msisdn,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
  },
  endGame(
    token: string,
    msisdn: string,
    params: {
      sessionId: string | number;
      finalLevel: number;
      finalScore: number;
      distance: number;
      reason?: string;
    }
  ) {
    return requestJson('/api/softclimbers/game/end', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'x-phone': msisdn,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });
  },
};

export const myidGoApi = {
  login(params: {
    thirdPartyToken: string;
    mcuid: string;
    uuid?: string;
    phone: string;
    avatar?: string;
    fullName?: string;
  }) {
    return requestJson('/api/myidgo/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },
  getProfile(token: string) {
    return requestJson('/api/myidgo/user/profile', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  getDefaultAvatars(token: string) {
    return requestJson('/api/myidgo/user/avatar/default', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  startGame(token: string) {
    return requestJson('/api/myidgo/game/start', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  claimRewardStep(token: string, slotIndex: number) {
    return requestJson(`/api/myidgo/game/reward?slot_index=${slotIndex}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  stopGame(token: string) {
    return requestJson('/api/myidgo/game/stop', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  getLeaderboard(token: string) {
    return requestJson('/api/myidgo/game/leaderboard/current', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  getHistory(token: string, limit = 30) {
    return requestJson(`/api/myidgo/game/history?limit=${limit}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  getStoreCategories(token: string) {
    return requestJson('/api/myidgo/store/categories', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  getStoreItems(token: string, categoryId?: string | number) {
    const q = categoryId ? `?categoryId=${encodeURIComponent(String(categoryId))}` : '';
    return requestJson(`/api/myidgo/store/items${q}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },
  buyStoreItem(token: string, payload: Record<string, unknown>) {
    return requestJson('/api/myidgo/store/buy', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  },
};
