import type { SavedAccount } from '../types';

const ACCOUNTS_KEY = 'kongpulse_accounts_v1';
const CURRENT_PHONE_KEY = 'kongpulse_current_phone_v1';
const DEVICE_ID_KEY = 'kongpulse_device_id_v1';
const KEEP_SCREEN_KEY = 'kongpulse_keep_screen_v1';
const LOOP_PREFIX = 'kongpulse_always_loop_';

export function getDeviceId(): string {
  let id = localStorage.getItem(DEVICE_ID_KEY);
  if (!id) {
    id = `kp-${crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2, 14)}`;
    localStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}

export function decodeJwtSub(jwtToken: string): string {
  try {
    const parts = jwtToken.split('.');
    if (parts.length < 2) return '';
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64 + '==='.slice((base64.length + 3) % 4);
    const json = atob(padded);
    const parsed = JSON.parse(json);
    return String(parsed?.sub || '');
  } catch {
    return '';
  }
}

export function formatMytelPhone(raw: string): string {
  const s = raw.trim().replace(/\s+/g, '');
  if (!s) return '';
  if (s.startsWith('+95')) return `0${s.slice(3)}`;
  if (s.startsWith('95')) return `0${s.slice(2)}`;
  if (!s.startsWith('0')) return `0${s}`;
  return s;
}

export function getSavedAccounts(): SavedAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function saveAccountsList(list: SavedAccount[]): void {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
}

export function getCurrentPhone(): string {
  return localStorage.getItem(CURRENT_PHONE_KEY) || '';
}

export function setCurrentPhone(phone: string): void {
  if (phone) {
    localStorage.setItem(CURRENT_PHONE_KEY, phone);
  } else {
    localStorage.removeItem(CURRENT_PHONE_KEY);
  }
}

export function getActiveAccount(): SavedAccount | null {
  const accounts = getSavedAccounts();
  if (accounts.length === 0) return null;
  const currentPhone = getCurrentPhone();
  if (currentPhone) {
    const found = accounts.find((a) => a.phone === currentPhone);
    if (found) return found;
  }
  return accounts[0];
}

export function upsertAccount(account: SavedAccount): SavedAccount[] {
  const list = getSavedAccounts();
  const idx = list.findIndex((a) => a.phone === account.phone);
  if (idx >= 0) {
    list[idx] = { ...list[idx], ...account };
  } else {
    list.push(account);
  }
  saveAccountsList(list);
  setCurrentPhone(account.phone);
  return list;
}

export function updateActiveAccount(patch: Partial<SavedAccount>): SavedAccount | null {
  const active = getActiveAccount();
  if (!active) return null;
  const updated = { ...active, ...patch };
  upsertAccount(updated);
  return updated;
}

export function deleteAccount(phone: string): SavedAccount[] {
  const remaining = getSavedAccounts().filter((a) => a.phone !== phone);
  saveAccountsList(remaining);
  if (getCurrentPhone() === phone) {
    setCurrentPhone(remaining[0]?.phone || '');
  }
  return remaining;
}

export function logoutCurrentAccount(): SavedAccount[] {
  const active = getActiveAccount();
  if (!active) return getSavedAccounts();
  return deleteAccount(active.phone);
}

export function getAlwaysLoop(phone: string): boolean {
  return localStorage.getItem(`${LOOP_PREFIX}${phone}`) === '1';
}

export function setAlwaysLoop(phone: string, enabled: boolean): void {
  localStorage.setItem(`${LOOP_PREFIX}${phone}`, enabled ? '1' : '0');
}

export function getKeepScreenOn(): boolean {
  return localStorage.getItem(KEEP_SCREEN_KEY) === '1';
}

export function setKeepScreenOn(enabled: boolean): void {
  localStorage.setItem(KEEP_SCREEN_KEY, enabled ? '1' : '0');
}
