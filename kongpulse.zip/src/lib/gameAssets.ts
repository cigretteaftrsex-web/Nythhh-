import gameLogoBeatZoo from '../assets/games/game_logo_beat_zoo.png';
import gameLogoCarRacing from '../assets/games/game_logo_car_racing.png';
import gameLogoFightingFish from '../assets/games/game_logo_fighting_fish.png';
import kittyFallDashboard from '../assets/games/kitty_fall_dashboard.png';
import icScLogo from '../assets/games/ic_sc_logo.png';
import scBanner from '../assets/games/sc.png';
import icMyidGoLogo from '../assets/games/ic_myid_go_logo.png';

import icBeatZoo from '../assets/games/ic_beat_zoo.png';
import icBeatGem from '../assets/games/ic_beat_gem.png';
import icBeatHeart from '../assets/games/ic_beat_heart.png';
import icBeatTicket from '../assets/games/ic_beat_ticket.png';
import icMissionGem from '../assets/games/ic_mission_gem.png';
import icMissionHeart from '../assets/games/ic_mission_heart.png';
import icMissionTicket from '../assets/games/ic_mission_ticket.png';
import icShopGem from '../assets/games/ic_shop_gem.png';
import icShopGem1 from '../assets/games/ic_shop_gem_1.png';
import icShopGem2 from '../assets/games/ic_shop_gem_2.png';
import icShopGem3 from '../assets/games/ic_shop_gem_3.png';
import icShopGem4 from '../assets/games/ic_shop_gem_4.png';
import icShopHeart1 from '../assets/games/ic_shop_heart_1.png';
import icShopHeart2 from '../assets/games/ic_shop_heart_2.png';
import icShopHeart3 from '../assets/games/ic_shop_heart_3.png';
import icShopHeart4 from '../assets/games/ic_shop_heart_4.png';
import icShopMemberDaily from '../assets/games/ic_shop_member_daily.png';
import icShopMemberWeekly from '../assets/games/ic_shop_member_weekly.png';
import icShopTicket1 from '../assets/games/ic_shop_ticket_1.png';
import icShopTicket2 from '../assets/games/ic_shop_ticket_2.png';
import icShopTicket3 from '../assets/games/ic_shop_ticket_3.png';
import icSpinGem from '../assets/games/ic_spin_gem.png';
import icSpinHeart from '../assets/games/ic_spin_heart.png';
import icSpinTicket from '../assets/games/ic_spin_ticket.png';

import icCoin from '../assets/games/ic_coin.png';
import icGem from '../assets/games/ic_gem.png';
import icLicensePackC6 from '../assets/games/ic_license_pack_c6.png';
import icLicensePackC7 from '../assets/games/ic_license_pack_c7.png';
import icMonthPackage from '../assets/games/ic_month_package.png';
import icDataCustom from '../assets/games/ic_data_custom.png';

import icCoinFf from '../assets/games/ic_coin_ff.png';
import icGemFf from '../assets/games/ic_gem_ff.png';
import icTicketFf from '../assets/games/ic_ticket_ff.png';
import icFfBuyTickets from '../assets/games/ic_ff_buy_tickets.png';
import icFfMagnetism from '../assets/games/ic_ff_magnetism.png';
import icFfMultifood from '../assets/games/ic_ff_multifood.png';
import icFfRevive from '../assets/games/ic_ff_revive.png';
import icFfShield from '../assets/games/ic_ff_shield.png';
import icFfSpeedup from '../assets/games/ic_ff_speedup.png';
import icFfTreasure from '../assets/games/ic_ff_treasure.png';
import icFfViewport from '../assets/games/ic_ff_viewport.png';
import icProgressFish from '../assets/games/ic_progress_fish.png';

import kittyCoin from '../assets/games/kitty_coin.png';
import kittyTicket from '../assets/games/kitty_ticket.png';

import icStatDiamond from '../assets/games/ic_stat_diamond.png';
import icStatHammer from '../assets/games/ic_stat_hammer.png';
import icStatJackfruit from '../assets/games/ic_stat_jackfruit.png';
import icStatMix from '../assets/games/ic_stat_mix.png';
import icStatTurn from '../assets/games/ic_stat_turn.png';

import icRankData from '../assets/games/ic_rank_data.png';
import icRankDefaultAvatar from '../assets/games/ic_rank_default_avatar.png';
import icRankLp from '../assets/games/ic_rank_lp.png';
import icRankPoints from '../assets/games/ic_rank_points.png';
import icRankPts from '../assets/games/ic_rank_pts.png';
import icBananaSm from '../assets/games/ic_banana_sm.png';

import { KONG_ASSETS } from './kongAssets';

export const GAME_ASSETS = {
  // Logos
  kongLogo: KONG_ASSETS.icKongIsland,
  beatZooLogo: gameLogoBeatZoo,
  carRacingLogo: gameLogoCarRacing,
  fightingFishLogo: gameLogoFightingFish,
  kittyFallLogo: kittyFallDashboard,
  softClimbersLogo: icScLogo,
  softClimbersBanner: scBanner,
  myidGoLogo: icMyidGoLogo,

  // Beat Zoo
  icBeatZoo,
  icBeatGem,
  icBeatHeart,
  icBeatTicket,
  icMissionGem,
  icMissionHeart,
  icMissionTicket,
  icShopGem,
  icShopGem1,
  icShopGem2,
  icShopGem3,
  icShopGem4,
  icShopHeart1,
  icShopHeart2,
  icShopHeart3,
  icShopHeart4,
  icShopMemberDaily,
  icShopMemberWeekly,
  icShopTicket1,
  icShopTicket2,
  icShopTicket3,
  icSpinGem,
  icSpinHeart,
  icSpinTicket,

  // Car Racing
  icCoin,
  icGem,
  icLicensePackC6,
  icLicensePackC7,
  icMonthPackage,
  icDataCustom,

  // Fighting Fish
  icCoinFf,
  icGemFf,
  icTicketFf,
  icFfBuyTickets,
  icFfMagnetism,
  icFfMultifood,
  icFfRevive,
  icFfShield,
  icFfSpeedup,
  icFfTreasure,
  icFfViewport,
  icProgressFish,

  // Kitty Fall
  kittyCoin,
  kittyTicket,

  // MyID Go stats
  icStatDiamond,
  icStatHammer,
  icStatJackfruit,
  icStatMix,
  icStatTurn,

  // Shared rank & misc
  icRankData,
  icRankDefaultAvatar,
  icRankLp,
  icRankPoints,
  icRankPts,
  icBananaSm,
} as const;

export function getBeatZooIcon(typeOrCode: string): string {
  const s = (typeOrCode || '').toUpperCase();
  if (s.includes('HEART')) return icBeatHeart;
  if (s.includes('GEM') || s.includes('DIAMOND')) return icBeatGem;
  if (s.includes('TICKET')) return icBeatTicket;
  if (s.includes('DAILY')) return icShopMemberDaily;
  if (s.includes('WEEKLY')) return icShopMemberWeekly;
  if (s.includes('DATA') || s.includes('MB') || s.includes('GB')) return KONG_ASSETS.icPrizeMb;
  if (s.includes('POINT') || s.includes('LP')) return KONG_ASSETS.icPrizePoint;
  return icBeatZoo;
}

export function getBeatZooSpinIcon(typeOrName: string): string {
  const s = (typeOrName || '').toUpperCase();
  if (s.includes('HEART')) return icSpinHeart;
  if (s.includes('GEM') || s.includes('DIAMOND')) return icSpinGem;
  if (s.includes('TICKET')) return icSpinTicket;
  if (s.includes('DATA') || s.includes('MB') || s.includes('GB')) return KONG_ASSETS.icPrizeMb;
  if (s.includes('POINT')) return KONG_ASSETS.icPrizePoint;
  return KONG_ASSETS.icGoodLuck;
}

export function getFishPowerupIcon(codeOrType: string): string {
  const s = (codeOrType || '').toUpperCase();
  if (s.includes('MAGNET')) return icFfMagnetism;
  if (s.includes('FOOD') || s.includes('MULTI')) return icFfMultifood;
  if (s.includes('REVIVE')) return icFfRevive;
  if (s.includes('SHIELD')) return icFfShield;
  if (s.includes('SPEED')) return icFfSpeedup;
  if (s.includes('TREASURE')) return icFfTreasure;
  if (s.includes('VIEW')) return icFfViewport;
  if (s.includes('TICKET')) return icFfBuyTickets;
  if (s.includes('GEM')) return icGemFf;
  return icCoinFf;
}

export function getMyIdGoStatIcon(typeOrName: string): string {
  const s = (typeOrName || '').toUpperCase();
  if (s.includes('HAMMER')) return icStatHammer;
  if (s.includes('DIAMOND')) return icStatDiamond;
  if (s.includes('JACKFRUIT')) return icStatJackfruit;
  if (s.includes('MIX')) return icStatMix;
  if (s.includes('TURN')) return icStatTurn;
  if (s.includes('MB') || s.includes('DATA')) return KONG_ASSETS.icPrizeMb;
  return KONG_ASSETS.icPrizePoint;
}
