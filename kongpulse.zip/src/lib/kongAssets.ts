import brandMark from '../assets/images/kong_brand_mark_1795158631196.jpg';
import heroBanner from '../assets/images/kong_hero_banner_1795158631691.jpg';
import islandEmblem from '../assets/images/kong_island_emblem_1795158631153.jpg';

import icBanana from '../assets/kong/ic_banana.png';
import icTicket from '../assets/kong/ic_ticket.png';
import icBox from '../assets/kong/ic_box.png';
import freebox from '../assets/kong/freebox.png';
import icMagnet from '../assets/kong/ic_magnet.png';
import icProtect from '../assets/kong/ic_protect.png';
import icX2Banana from '../assets/kong/ic_x2banana.png';
import icReborn from '../assets/kong/ic_reborn.png';
import icTurn from '../assets/kong/ic_turn.png';
import icGoodLuck from '../assets/kong/ic_good_luck.png';
import icSpinCenter from '../assets/kong/ic_spin_center.png';
import icLuckySpin from '../assets/kong/ic_lucky_spin.png';
import icKongIsland from '../assets/kong/ic_kong_island.png';
import icKongRunner from '../assets/kong/ic_kong_runner.png';
import icLoyalPoint from '../assets/kong/ic_loyal_point.png';
import icPoint from '../assets/kong/point.png';
import icMmk from '../assets/kong/ic_mmk.png';
import icPrizeMb from '../assets/kong/ic_prize_mb.png';
import icPrizePoint from '../assets/kong/ic_prize_point.png';
import icRankGold from '../assets/kong/ic_rank_gold.png';
import icRankSilver from '../assets/kong/ic_rank_silver.png';
import icRankBronze from '../assets/kong/ic_rank_bronze.png';
import icSubDaily from '../assets/kong/ic_sub_pack_daily.png';
import icSubWeekly from '../assets/kong/ic_sub_pack_weekly.png';
import icSubMonthly from '../assets/kong/ic_sub_pack_monthly.png';

export const KONG_ASSETS = {
  brandMark,
  heroBanner,
  islandEmblem,
  icBanana,
  icTicket,
  icBox,
  freebox,
  icMagnet,
  icProtect,
  icX2Banana,
  icReborn,
  icTurn,
  icGoodLuck,
  icSpinCenter,
  icLuckySpin,
  icKongIsland,
  icKongRunner,
  icLoyalPoint,
  icPoint,
  icMmk,
  icPrizeMb,
  icPrizePoint,
  icRankGold,
  icRankSilver,
  icRankBronze,
  icSubDaily,
  icSubWeekly,
  icSubMonthly,
} as const;

export function getRewardAsset(typeItemOrDesc: string): string {
  const t = (typeItemOrDesc || '').toUpperCase();
  if (t.includes('X2')) return icX2Banana;
  if (t.includes('MAGNET')) return icMagnet;
  if (t.includes('PROTECT')) return icProtect;
  if (t.includes('REBORN')) return icReborn;
  if (t.includes('TURN') || t.includes('SPIN')) return icTurn;
  if (t.includes('GOOD_LUCK') || t.includes('LUCK')) return icGoodLuck;
  if (t.includes('TICKET')) return icTicket;
  if (t.includes('BOX')) return icBox;
  if (t.includes('BANANA')) return icBanana;
  return icPrizePoint;
}

export function getPackageAsset(codeOrName: string): string {
  const c = (codeOrName || '').toUpperCase();
  if (c.includes('DAILY')) return icSubDaily;
  if (c.includes('WEEKLY')) return icSubWeekly;
  if (c.includes('MONTHLY')) return icSubMonthly;
  if (c.includes('SUPER')) return icKongIsland;
  return icTicket;
}

export function getRankMedal(rank: number): string | null {
  if (rank === 1) return icRankGold;
  if (rank === 2) return icRankSilver;
  if (rank === 3) return icRankBronze;
  return null;
}
