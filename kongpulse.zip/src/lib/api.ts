import { getDeviceId } from './storage';

async function requestJson<T = any>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(url, options);
  const text = await res.text();
  let data: any = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (res.status === 401) {
    throw new Error(data?.message || 'Session expired (401). Please re-verify OTP.');
  }
  if (!res.ok && data?.errorCode === undefined && data?.success !== false) {
    throw new Error(data?.message || `Request failed (${res.status})`);
  }
  return data as T;
}

export const mytelApi = {
  checkAccount(phone: string) {
    return requestJson('/api/mytel/check-account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone }),
    });
  },

  getOtp(phone: string) {
    return requestJson('/api/mytel/get-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone }),
    });
  },

  registerRequest(phone: string) {
    return requestJson('/api/mytel/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone }),
    });
  },

  validateOtp(phone: string, otp: string) {
    return requestJson('/api/mytel/validate-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, otp, deviceId: getDeviceId() }),
    });
  },

  getAccountDetail(token: string, phone: string) {
    return requestJson(
      `/api/mytel/account-detail?phone=${encodeURIComponent(phone)}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  getCustomer(token: string) {
    return requestJson('/api/mytel/customer', {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  updateCustomer(token: string, fullName: string, birthDate = '', gender = 'male') {
    return requestJson('/api/mytel/customer', {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ fullName, birthDate, gender }),
    });
  },

  uploadAvatar(token: string, imageBase64: string, mimeType = 'image/jpeg') {
    return requestJson('/api/mytel/upload-avatar', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ imageBase64, mimeType }),
    });
  },

  getLoyaltyCsm(token: string, phone: string) {
    return requestJson(
      `/api/mytel/loyalty-csm?phone=${encodeURIComponent(phone)}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  getLoyaltyInquiry(token: string, phone: string) {
    return requestJson(
      `/api/mytel/loyalty-inquiry?phone=${encodeURIComponent(phone)}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  getLoyaltyPacks(token: string, phone: string) {
    return requestJson(
      `/api/mytel/loyalty-packs?phone=${encodeURIComponent(phone)}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  exchangePack(token: string, phone: string, rewardCode: string) {
    return requestJson('/api/mytel/loyalty-exchange', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone, rewardCode }),
    });
  },

  getLoyaltyHistory(token: string, phone: string, type: 'BURN' | 'EARN') {
    return requestJson(
      `/api/mytel/loyalty-history?phone=${encodeURIComponent(phone)}&type=${type}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  extendPoints(token: string, phone: string) {
    return requestJson('/api/mytel/loyalty-extend', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone }),
    });
  },

  getVasPacks(token: string, phone: string) {
    return requestJson(
      `/api/mytel/vas-packs?phone=${encodeURIComponent(phone)}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  getVasDetail(token: string, code: string, phone: string) {
    return requestJson(
      `/api/mytel/vas-detail/${encodeURIComponent(code)}?phone=${encodeURIComponent(phone)}&deviceId=${encodeURIComponent(getDeviceId())}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
  },

  registerVasPackage(token: string, code: string, phone: string) {
    return requestJson(`/api/mytel/vas-register/${encodeURIComponent(code)}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone }),
    });
  },

  getDailyQuest(token: string, phone: string) {
    return requestJson(`/api/mytel/daily-quest?phone=${encodeURIComponent(phone)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  },

  postDailyClaim(token: string, phone: string) {
    return requestJson('/api/mytel/daily-claim', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone }),
    });
  },

  claimMiniQuest(token: string, phone: string, urlCallBack: string) {
    return requestJson('/api/mytel/mini-quest-claim', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone, urlCallBack }),
    });
  },
};

export const kongApi = {
  loginViaGateway(params: {
    thirdPartyToken: string;
    mcuid: string;
    phone: string;
    avatar?: string;
    fullName?: string;
  }) {
    return requestJson('/api/kong/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  },

  getUserInfo(kongToken: string) {
    return requestJson('/api/kong/user/info', {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  updatePlayerName(kongToken: string, playerName: string) {
    return requestJson('/api/kong/user/player-name', {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${kongToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ playerName }),
    });
  },

  getAvatarList(kongToken: string) {
    return requestJson('/api/kong/avatar/list', {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  buyAvatar(kongToken: string, id: number) {
    return requestJson(`/api/kong/avatar/buy/${id}`, {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  openBox(kongToken: string, count: number) {
    return requestJson(`/api/kong/event/open/${count}`, {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  getLeaderboard(kongToken: string, period: 'week' | 'month') {
    return requestJson(`/api/kong/leaderboard/${period}`, {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  getPackages(kongToken: string, type: 'ALL' | 'RENEW' | 'RETAIL' = 'ALL') {
    return requestJson(`/api/kong/package/list?type=${type}`, {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  buyPackage(kongToken: string, code: string) {
    return requestJson('/api/kong/package/buy', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${kongToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code }),
    });
  },

  getShopItems(kongToken: string) {
    return requestJson('/api/kong/shop/item', {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  exchangeShopItem(kongToken: string, id: number, value = 1) {
    return requestJson('/api/kong/shop/item', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${kongToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id, value }),
    });
  },

  getSpinList(kongToken: string) {
    return requestJson('/api/kong/luckSpin/list', {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },

  spin(kongToken: string) {
    return requestJson('/api/kong/luckSpin/spin', {
      headers: { Authorization: `Bearer ${kongToken}` },
    });
  },
};
