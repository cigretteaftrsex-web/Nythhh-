import React, { useCallback, useEffect, useState } from 'react';
import { ArrowRight, Coins, History, Loader2, Sparkles, X } from 'lucide-react';
import { TopBar } from './components/TopBar';
import { KongRunnerProvider } from './context/KongRunnerContext';
import { mytelApi } from './lib/api';
import {
  getActiveAccount,
  logoutCurrentAccount,
  updateActiveAccount,
} from './lib/storage';
import type { AppRoute, KongUserInfo, LoyaltyExtendInfo, SavedAccount } from './types';
import { AccountsView } from './views/AccountsView';
import { BeatZooView } from './views/BeatZooView';
import { CarRacingView } from './views/CarRacingView';
import { DailyClaimView } from './views/DailyClaimView';
import { DashboardView } from './views/DashboardView';
import { DataPackagesView } from './views/DataPackagesView';
import { FightingFishView } from './views/FightingFishView';
import { KittyFallView } from './views/KittyFallView';
import { KongExchangeView } from './views/KongExchangeView';
import { KongIslandView } from './views/KongIslandView';
import { KongShopView } from './views/KongShopView';
import { KongSpinView } from './views/KongSpinView';
import { LoginView } from './views/LoginView';
import { MyIDGoView } from './views/MyIDGoView';
import { OtpView } from './views/OtpView';
import { PointsExchangeView } from './views/PointsExchangeView';
import { PointsHistoryView } from './views/PointsHistoryView';
import { SoftClimbersView } from './views/SoftClimbersView';

export default function App() {
  const [activeAccount, setActiveAccount] = useState<SavedAccount | null>(() =>
    getActiveAccount()
  );
  const [route, setRoute] = useState<AppRoute>(() =>
    getActiveAccount() ? 'dashboard' : 'login'
  );
  const [pendingOtp, setPendingOtp] = useState<{ phone: string; isRegister: boolean } | null>(
    null
  );
  const [isAddAccountFlow, setIsAddAccountFlow] = useState(false);

  // Points Bottom Sheet & Points Extend Modal (PointsExtendDialog$1.smali)
  const [pointsSheetOpen, setPointsSheetOpen] = useState(false);
  const [extendModalOpen, setExtendModalOpen] = useState(false);
  const [loadingExtendInfo, setLoadingExtendInfo] = useState(false);
  const [extendInfo, setExtendInfo] = useState<LoyaltyExtendInfo | null>(null);
  const [extending, setExtending] = useState(false);
  const [extendSuccess, setExtendSuccess] = useState(false);
  const [extendMessage, setExtendMessage] = useState('');

  const handleKongTokenUpdate = useCallback(
    (phone: string, kongToken: string, profile?: Partial<KongUserInfo>) => {
      if (activeAccount?.phone === phone) {
        const updated = updateActiveAccount({
          kongToken,
          kongPlayerName: profile?.playerName || activeAccount.kongPlayerName,
          kongPlayerAvatar: profile?.avatar || activeAccount.kongPlayerAvatar,
          kongPlayerPhone: profile?.msisdn || activeAccount.kongPlayerPhone,
        });
        if (updated) setActiveAccount(updated);
      }
    },
    [activeAccount]
  );

  const handleLogout = () => {
    const remaining = logoutCurrentAccount();
    const next = remaining[0] || null;
    setActiveAccount(next);
    setRoute(next ? 'dashboard' : 'login');
  };

  const openExtendModal = useCallback(async () => {
    if (!activeAccount) return;
    setPointsSheetOpen(false);
    setExtendMessage('');
    setExtendSuccess(false);
    setExtendInfo(null);
    setExtendModalOpen(true);
    setLoadingExtendInfo(true);
    try {
      const res = await mytelApi.getLoyaltyInquiry(activeAccount.accessToken, activeAccount.phone);
      const ex = res?.result?.extendInfo;
      if (ex && typeof ex === 'object') {
        setExtendInfo({
          monthlyLimit: Number(ex.monthlyLimit ?? ex.currentLimit ?? 0),
          currentLimit: Number(ex.currentLimit ?? ex.monthlyLimit ?? 0),
          afterLimit: Number(ex.afterLimit ?? 0),
          exchanged: Number(ex.exchanged ?? 0),
          mainBalanceSpend: Number(ex.mainBalanceSpend ?? 0),
          extendRemain: Number(ex.extendRemain ?? 0),
          canExtend: Boolean(ex.canExtend),
        });
      }
    } catch (err) {
      setExtendMessage(err instanceof Error ? err.message : 'Unable to fetch extend quota');
    } finally {
      setLoadingExtendInfo(false);
    }
  }, [activeAccount]);

  const handleExtendPoints = async () => {
    if (!activeAccount) return;
    setExtending(true);
    setExtendMessage('');
    setExtendSuccess(false);
    try {
      const res = await mytelApi.extendPoints(activeAccount.accessToken, activeAccount.phone);
      const ec = res?.errorCode;
      const ok = ec === '00000' || ec === '00' || Number(ec) === 0 || Number(ec) === 200;
      if (!ok) {
        throw new Error(res?.message || 'Points limit extension failed');
      }
      setExtendSuccess(true);
      setExtendMessage(res?.message || 'လစဉ် Point လဲလှယ်ခွင့် ကန့်သတ်ချက် ထပ်တိုးပြီးပါပြီ!');
      // Refresh extend quota after extension
      const refreshRes = await mytelApi.getLoyaltyInquiry(activeAccount.accessToken, activeAccount.phone);
      const ex = refreshRes?.result?.extendInfo;
      if (ex && typeof ex === 'object') {
        setExtendInfo({
          monthlyLimit: Number(ex.monthlyLimit ?? ex.currentLimit ?? 0),
          currentLimit: Number(ex.currentLimit ?? ex.monthlyLimit ?? 0),
          afterLimit: Number(ex.afterLimit ?? 0),
          exchanged: Number(ex.exchanged ?? 0),
          mainBalanceSpend: Number(ex.mainBalanceSpend ?? 0),
          extendRemain: Number(ex.extendRemain ?? 0),
          canExtend: Boolean(ex.canExtend),
        });
      }
    } catch (err) {
      setExtendSuccess(false);
      setExtendMessage(err instanceof Error ? err.message : 'Unable to extend points limit');
    } finally {
      setExtending(false);
    }
  };

  // Keep Screen On WakeLock preference restoration on mount
  useEffect(() => {
    const keepOn = window.localStorage.getItem('kp_keep_screen_on') === 'true';
    if (keepOn && 'wakeLock' in navigator) {
      (navigator as any).wakeLock.request('screen').catch(() => {});
    }
  }, []);

  const navigate = (nextRoute: AppRoute) => {
    setRoute(nextRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderContent = () => {
    if (route === 'login' || (!activeAccount && route !== 'otp')) {
      return (
        <LoginView
          isAddAccount={isAddAccountFlow}
          onBackToAccounts={
            isAddAccountFlow && activeAccount
              ? () => {
                  setIsAddAccountFlow(false);
                  navigate('accounts');
                }
              : undefined
          }
          onOtpSent={(params) => {
            setPendingOtp(params);
            navigate('otp');
          }}
        />
      );
    }

    if (route === 'otp' && pendingOtp) {
      return (
        <OtpView
          phone={pendingOtp.phone}
          isRegister={pendingOtp.isRegister}
          onBack={() => navigate('login')}
          onSuccess={(acc) => {
            setActiveAccount(acc);
            setIsAddAccountFlow(false);
            setPendingOtp(null);
            navigate('dashboard');
          }}
        />
      );
    }

    if (!activeAccount) {
      return null;
    }

    switch (route) {
      case 'accounts':
        return (
          <AccountsView
            activeAccount={activeAccount}
            onBack={() => navigate('dashboard')}
            onAccountSwitched={(next) => {
              setActiveAccount(next);
              if (!next) {
                navigate('login');
              } else {
                navigate('dashboard');
              }
            }}
            onAddAccount={() => {
              setIsAddAccountFlow(true);
              navigate('login');
            }}
          />
        );
      case 'daily-claim':
        return <DailyClaimView account={activeAccount} onBack={() => navigate('dashboard')} />;
      case 'points-exchange':
        return <PointsExchangeView account={activeAccount} onBack={() => navigate('dashboard')} />;
      case 'points-history':
        return <PointsHistoryView account={activeAccount} onBack={() => navigate('dashboard')} />;
      case 'data-packages':
        return <DataPackagesView account={activeAccount} onBack={() => navigate('dashboard')} />;
      case 'kong-island':
        return (
          <KongIslandView
            account={activeAccount}
            onBack={() => navigate('dashboard')}
            onNavigate={navigate}
          />
        );
      case 'kong-shop':
        return <KongShopView account={activeAccount} onBack={() => navigate('kong-island')} />;
      case 'kong-exchange':
        return <KongExchangeView account={activeAccount} onBack={() => navigate('kong-island')} />;
      case 'kong-spin':
        return <KongSpinView account={activeAccount} onBack={() => navigate('kong-island')} />;
      case 'beat-zoo':
        return (
          <BeatZooView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onBack={() => navigate('dashboard')}
          />
        );
      case 'car-racing':
        return (
          <CarRacingView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onBack={() => navigate('dashboard')}
          />
        );
      case 'fighting-fish':
        return (
          <FightingFishView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onBack={() => navigate('dashboard')}
          />
        );
      case 'kitty-fall':
        return (
          <KittyFallView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onBack={() => navigate('dashboard')}
          />
        );
      case 'soft-climbers':
        return (
          <SoftClimbersView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onBack={() => navigate('dashboard')}
          />
        );
      case 'myid-go':
        return (
          <MyIDGoView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onBack={() => navigate('dashboard')}
          />
        );
      case 'dashboard':
      default:
        return (
          <DashboardView
            account={activeAccount}
            onAccountUpdated={setActiveAccount}
            onNavigate={navigate}
            onOpenPointsSheet={() => setPointsSheetOpen(true)}
            onOpenExtendModal={openExtendModal}
            onLogout={handleLogout}
          />
        );
    }
  };

  const showTopBar = Boolean(activeAccount) && route !== 'login' && route !== 'otp';

  return (
    <KongRunnerProvider onTokenUpdate={handleKongTokenUpdate}>
      <div className="min-h-screen bg-[#0C0F14] text-slate-100">
        {showTopBar && (
          <TopBar
            currentRoute={route}
            activeAccount={activeAccount}
            onNavigate={navigate}
            onOpenPointsSheet={() => setPointsSheetOpen(true)}
          />
        )}

        <main>{renderContent()}</main>

        {/* Points Hub Bottom Sheet */}
        {pointsSheetOpen && (
          <div
            onClick={() => setPointsSheetOpen(false)}
            className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-5 pt-3 pb-6 safe-pb space-y-3 animate-sheet-in"
            >
              <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
              <div className="flex items-center justify-between pb-1">
                <h3 className="font-display text-lg font-bold text-white">Points</h3>
                <button
                  type="button"
                  onClick={() => setPointsSheetOpen(false)}
                  aria-label="Close"
                  className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/5"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPointsSheetOpen(false);
                  navigate('points-exchange');
                }}
                className="w-full min-h-[64px] rounded-2xl border border-white/[0.08] bg-[#1C212C] p-4 flex items-center justify-between gap-4 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="h-11 w-11 rounded-xl bg-[#C8942A]/15 text-[#E8B040] flex items-center justify-center shrink-0">
                    <Coins className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white">Point Exchange</p>
                    <p className="text-xs text-slate-400 truncate">
                      Points ကို Data / Voice / SMS ပြောင်းမည်
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setPointsSheetOpen(false);
                  navigate('points-history');
                }}
                className="w-full min-h-[64px] rounded-2xl border border-white/[0.08] bg-[#1C212C] p-4 flex items-center justify-between gap-4 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="h-11 w-11 rounded-xl bg-[#C8942A]/15 text-[#E8B040] flex items-center justify-center shrink-0">
                    <History className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white">Points History</p>
                    <p className="text-xs text-slate-400 truncate">
                      သုံးစွဲ / ရရှိသော Points မှတ်တမ်း
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
              </button>

              <button
                type="button"
                onClick={openExtendModal}
                className="w-full min-h-[64px] rounded-2xl border border-white/[0.08] bg-[#1C212C] p-4 flex items-center justify-between gap-4 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="h-11 w-11 rounded-xl bg-[#C8942A]/15 text-[#E8B040] flex items-center justify-center shrink-0">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white">Points Extend</p>
                    <p className="text-xs text-slate-400 truncate">
                      လစဉ်လဲလှယ်ခွင့် ကန့်သတ်ချက် ထပ်တိုးမည်
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
              </button>
            </div>
          </div>
        )}

        {/* Points Extend Confirmation Bottom Sheet / Dialog */}
        {extendModalOpen && (
          <div
            onClick={() => setExtendModalOpen(false)}
            className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
            >
              <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-bold text-white">Points Extend</h3>
                <button
                  type="button"
                  onClick={() => setExtendModalOpen(false)}
                  aria-label="Close"
                  className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {loadingExtendInfo ? (
                <div className="py-6 flex items-center justify-center gap-2 text-xs text-slate-400">
                  <Loader2 className="h-4 w-4 animate-spin text-[#E8B040]" />
                  <span>Loading quota details...</span>
                </div>
              ) : extendInfo ? (
                <div className="rounded-xl border border-white/[0.08] bg-[#1C212C] divide-y divide-white/[0.06] text-xs">
                  <div className="px-4 py-3 flex items-center justify-between gap-3">
                    <span className="text-slate-400">Monthly Limit</span>
                    <span className="font-mono-num font-bold text-white">
                      {extendInfo.currentLimit.toLocaleString()} → {extendInfo.afterLimit.toLocaleString()} pts
                    </span>
                  </div>
                  <div className="px-4 py-3 flex items-center justify-between gap-3">
                    <span className="text-slate-400">Used This Month</span>
                    <span className="font-mono-num font-semibold text-slate-200">
                      {extendInfo.exchanged.toLocaleString()} pts
                    </span>
                  </div>
                  <div className="px-4 py-3 flex items-center justify-between gap-3">
                    <span className="text-slate-400">Cost (Main Balance)</span>
                    <span className="font-mono-num font-bold text-[#E8B040]">
                      {extendInfo.mainBalanceSpend.toLocaleString()} Ks ဖြင့်ထပ်တိုးမည်
                    </span>
                  </div>
                  <div className="px-4 py-3 flex items-center justify-between gap-3">
                    <span className="text-slate-400">Extensions Remaining</span>
                    <span className="font-mono-num font-semibold text-slate-200">
                      {extendInfo.extendRemain}
                    </span>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-slate-300">
                  လစဉ် Point လဲလှယ်ခွင့် ကန့်သတ်ချက်ကို ထပ်တိုးလိုပါသလား?
                </p>
              )}

              {extendInfo && !extendInfo.canExtend && !extendSuccess && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-xs text-amber-200">
                  လက်ရှိတွင် ထပ်တိုး၍ မရသေးပါ (Quota cannot be extended right now)
                </div>
              )}

              {extendMessage && (
                <div
                  className={`rounded-xl border px-4 py-2.5 text-xs ${
                    extendSuccess
                      ? 'border-[#4CAF50]/30 bg-[#4CAF50]/10 text-[#81C784]'
                      : 'border-red-500/30 bg-red-500/10 text-red-300'
                  }`}
                >
                  {extendMessage}
                </div>
              )}

              <div className="flex items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setExtendModalOpen(false)}
                  className="flex-1 min-h-[46px] rounded-xl border border-white/10 text-xs font-semibold text-slate-300 hover:bg-white/5 active:scale-[0.98] transition-all"
                >
                  မလုပ်တော့
                </button>
                <button
                  type="button"
                  disabled={extending || loadingExtendInfo || (extendInfo !== null && !extendInfo.canExtend)}
                  onClick={handleExtendPoints}
                  className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14] disabled:opacity-50 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  {extending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                  <span>အတည်ပြုပါ</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </KongRunnerProvider>
  );
}
