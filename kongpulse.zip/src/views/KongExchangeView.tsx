import React, { useCallback, useEffect, useState } from 'react';
import { Loader2, RefreshCw, X } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { useKongRunner } from '../context/KongRunnerContext';
import { kongApi } from '../lib/api';
import { KONG_ASSETS, getRewardAsset } from '../lib/kongAssets';
import type { KongExchangeItem, KongUserInfo, SavedAccount } from '../types';

interface KongExchangeViewProps {
  account: SavedAccount;
  onBack: () => void;
}

const QUANTITIES = [1, 5, 10] as const;

function getOwnedCount(typeItem: string, userInfo: KongUserInfo | null): number {
  if (!userInfo) return 0;
  const t = typeItem.toUpperCase();
  if (t.includes('X2')) return userInfo.total2xBanana ?? 0;
  if (t.includes('MAGNET')) return userInfo.totalMagnet ?? 0;
  if (t.includes('PROTECT')) return userInfo.totalProtect ?? 0;
  if (t.includes('REBORN')) return userInfo.totalReborn ?? 0;
  return 0;
}

export function KongExchangeView({ account, onBack }: KongExchangeViewProps) {
  const kong = useKongRunner();
  const [items, setItems] = useState<KongExchangeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState<KongExchangeItem | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [exchangingId, setExchangingId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadItems = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      let tok = kong.kongToken;
      if (!tok) {
        const resolved = await kong.ensureKongSession(account);
        if (!resolved) {
          setLoading(false);
          return;
        }
        tok = resolved;
      }
      const res = await kongApi.getShopItems(tok);
      const list = Array.isArray(res?.data) ? res.data : [];
      setItems(
        list.map((it: any) => ({
          id: Number(it.id),
          name: String(it.name || it.typeItem || 'Item'),
          typeItem: String(it.typeItem || ''),
          price: Number(it.price || 0),
          description: it.description ? String(it.description) : undefined,
        }))
      );
      await kong.refreshUserInfo(tok);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Item list ယူ၍ မရပါ။');
    } finally {
      setLoading(false);
    }
  }, [account, kong]);

  useEffect(() => {
    loadItems();
  }, [account.phone]);

  const handleConfirmExchange = async () => {
    if (!selectedItem || !kong.kongToken) return;
    setExchangingId(selectedItem.id);
    setFeedback('');
    setErrorMsg('');
    try {
      const res = await kongApi.exchangeShopItem(kong.kongToken, selectedItem.id, quantity);
      if (res?.success === false) {
        throw new Error(res?.message || 'လဲလှယ်၍ မရပါ။');
      }
      const totalSpent = selectedItem.price * quantity;
      setFeedback(
        `${selectedItem.name} × ${quantity} ရပါပြီ (${totalSpent.toLocaleString()} Banana သုံးသည်)`
      );
      setSelectedItem(null);
      await kong.refreshUserInfo();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'လဲလှယ်၍ မရပါ။');
      setSelectedItem(null);
    } finally {
      setExchangingId(null);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Banana Exchange"
        subtitle="Banana သုံးပြီး Power-up Item များ လဲလှယ်ပါ"
        onBack={onBack}
        rightSlot={
          <div className="flex items-center gap-2">
            <div className="rounded-xl border border-white/10 bg-[#141820] px-3 py-2 text-xs font-bold font-mono-num text-[#E8B040] flex items-center gap-1.5">
              <img src={KONG_ASSETS.icBanana} alt="" className="h-4 w-4 object-contain" />
              <span>{(kong.userInfo?.totalBanana ?? 0).toLocaleString()}</span>
            </div>
            <button
              type="button"
              onClick={loadItems}
              disabled={loading}
              aria-label="Refresh items"
              className="h-10 w-10 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        }
      />

      {feedback && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784]">
          {feedback}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300">
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-24 rounded-2xl border border-white/[0.06] bg-[#161920] animate-pulse"
            />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-10 text-center text-sm text-slate-400">
          Item မရှိသေးပါ။
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {items.map((item, idx) => {
            const owned = getOwnedCount(item.typeItem, kong.userInfo);
            const assetSrc = getRewardAsset(item.typeItem);
            return (
              <div
                key={`${item.id}-${item.typeItem}-${idx}`}
                className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="h-12 w-12 rounded-xl bg-[#12151B] border border-white/[0.06] flex items-center justify-center shrink-0">
                    <img src={assetSrc} alt={item.name} className="h-8 w-8 object-contain" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold text-white truncate">{item.name}</h3>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono-num mt-0.5">
                      <img src={KONG_ASSETS.icBanana} alt="" className="h-3.5 w-3.5 object-contain" />
                      <span className="text-[#E8B040] font-semibold">
                        {item.price.toLocaleString()}
                      </span>
                      <span>·</span>
                      <span>Owned: {owned}</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setQuantity(1);
                    setSelectedItem(item);
                  }}
                  className="min-h-[44px] shrink-0 rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] hover:brightness-105 active:scale-95 transition-all"
                >
                  လဲမည်
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Quantity & Confirm Bottom Sheet */}
      {selectedItem && (
        <div
          onClick={() => setSelectedItem(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={getRewardAsset(selectedItem.typeItem)}
                  alt={selectedItem.name}
                  className="h-9 w-9 object-contain shrink-0"
                />
                <h3 className="font-display text-lg font-bold text-white truncate">
                  {selectedItem.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-400">
                အရေအတွက် ရွေးပါ (Owned: {getOwnedCount(selectedItem.typeItem, kong.userInfo)})
              </p>
              <div className="grid grid-cols-3 gap-2.5">
                {QUANTITIES.map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setQuantity(q)}
                    className={`min-h-[44px] rounded-xl border text-sm font-bold font-mono-num active:scale-95 transition-all ${
                      quantity === q
                        ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                        : 'border-white/10 bg-[#1C212C] text-slate-200'
                    }`}
                  >
                    ×{q}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-white/[0.08] bg-[#1C212C] px-4 py-3 flex items-center justify-between text-xs">
              <span className="text-slate-400">စုစုပေါင်း ကုန်ကျမည်</span>
              <span className="font-mono-num text-sm font-bold text-[#E8B040] flex items-center gap-1.5">
                <img src={KONG_ASSETS.icBanana} alt="" className="h-4 w-4 object-contain" />
                <span>{(selectedItem.price * quantity).toLocaleString()} Banana</span>
              </span>
            </div>

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 text-xs font-semibold text-slate-300"
              >
                မလုပ်တော့
              </button>
              <button
                type="button"
                disabled={
                  exchangingId === selectedItem.id ||
                  (kong.userInfo?.totalBanana ?? 0) < selectedItem.price * quantity
                }
                onClick={handleConfirmExchange}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {exchangingId === selectedItem.id && (
                  <Loader2 className="h-4 w-4 animate-spin" />
                )}
                <span>လဲလှယ်မည်</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
