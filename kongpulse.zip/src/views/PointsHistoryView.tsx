import React, { useCallback, useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { mytelApi } from '../lib/api';
import type { LoyaltyHistoryItem, SavedAccount } from '../types';

interface PointsHistoryViewProps {
  account: SavedAccount;
  onBack: () => void;
}

function formatHistoryDate(raw: string): string {
  if (!raw) return '';
  const num = Number(raw);
  if (!Number.isNaN(num) && num > 1_000_000_000) {
    const d = new Date(num > 1_000_000_000_000 ? num : num * 1000);
    return d.toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  const parsed = Date.parse(raw);
  if (!Number.isNaN(parsed)) {
    return new Date(parsed).toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  return raw;
}

export function PointsHistoryView({ account, onBack }: PointsHistoryViewProps) {
  const [tab, setTab] = useState<'BURN' | 'EARN'>('BURN');
  const [items, setItems] = useState<LoyaltyHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  const loadHistory = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await mytelApi.getLoyaltyHistory(account.accessToken, account.phone, tab);
      const list = res?.result?.content || res?.result || res?.data || [];
      const mapped: LoyaltyHistoryItem[] = Array.isArray(list)
        ? list.map((it: any, idx: number) => ({
            id: String(it.id || idx),
            title: String(
              it.reason ||
                it.title ||
                it.actionName ||
                it.description ||
                it.rewardName ||
                'Points Transaction'
            ),
            points: Number(it.amount ?? it.pointAmount ?? it.points ?? it.point ?? 0),
            date: formatHistoryDate(
              String(it.updateTime ?? it.createdDate ?? it.transactionDate ?? it.date ?? '')
            ),
            type: it.type ? String(it.type) : tab,
          }))
        : [];
      setItems(mapped);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load history');
    } finally {
      setLoading(false);
    }
  }, [account.accessToken, account.phone, tab]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Points History"
        subtitle={tab === 'BURN' ? 'သုံးစွဲခဲ့သော Points မှတ်တမ်း' : 'ရရှိခဲ့သော Points မှတ်တမ်း'}
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={loadHistory}
            disabled={loading}
            aria-label="Refresh history"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      <div className="inline-flex items-center gap-1 rounded-xl border border-white/[0.08] bg-[#141820] p-1">
        <button
          type="button"
          onClick={() => setTab('BURN')}
          className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
            tab === 'BURN' ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400 hover:text-white'
          }`}
        >
          သုံးစွဲသောပွိုင့် (Burn)
        </button>
        <button
          type="button"
          onClick={() => setTab('EARN')}
          className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
            tab === 'EARN' ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400 hover:text-white'
          }`}
        >
          ရရှိသောပွိုင့် (Earn)
        </button>
      </div>

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300">
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className="h-16 rounded-2xl border border-white/[0.06] bg-[#141820] animate-pulse"
            />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-10 text-center text-sm text-slate-400">
          No {tab.toLowerCase()} records found.
        </div>
      ) : (
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] divide-y divide-white/[0.06]">
          {items.map((item, idx) => (
            <div
              key={`${item.id}-${idx}`}
              className="px-4 py-4 sm:px-6 flex items-center justify-between gap-4"
            >
              <div className="min-w-0">
                <p className="text-sm font-medium text-white truncate">{item.title}</p>
                {item.date && (
                  <p className="text-xs text-slate-400 font-mono-num mt-0.5">{item.date}</p>
                )}
              </div>
              <span
                className={`font-mono-num text-sm font-bold shrink-0 ${
                  tab === 'EARN' ? 'text-[#4CAF50]' : 'text-[#E8B040]'
                }`}
              >
                {tab === 'EARN' ? '+' : '-'}
                {Math.abs(item.points).toLocaleString()} pts
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
