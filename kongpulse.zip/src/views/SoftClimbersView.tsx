import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  History,
  Mountain,
  Play,
  RefreshCw,
  ShoppingBag,
  Square,
  Trophy,
} from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { GAME_ASSETS } from '../lib/gameAssets';
import { softClimbersApi } from '../lib/gamesApi';
import { getRankMedal } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface SoftClimbersViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onBack: () => void;
}

type ScTab = 'play' | 'shop' | 'history' | 'rank';

export function SoftClimbersView({ account, onAccountUpdated, onBack }: SoftClimbersViewProps) {
  const [token, setToken] = useState(account.softClimbersToken || '');
  const [tab, setTab] = useState<ScTab>('play');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const [subStatus, setSubStatus] = useState<any | null>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [historyRows, setHistoryRows] = useState<any[]>([]);
  const [rankRows, setRankRows] = useState<any[]>([]);
  const [buyingPlanId, setBuyingPlanId] = useState<string | null>(null);

  // Climb Bot State
  const [startLevel, setStartLevel] = useState(1);
  const [isClimbing, setIsClimbing] = useState(false);
  const [autoLoop, setAutoLoop] = useState(false);
  const [climbProgress, setClimbProgress] = useState(0);
  const [liveScore, setLiveScore] = useState(0);
  const stopRef = useRef(false);

  const ensureSession = useCallback(
    async (force = false): Promise<string> => {
      if (!force && token) return token;
      const res = await softClimbersApi.login({
        msisdn: account.phone,
        accessToken: account.thirdPartyToken,
        avatar: account.avatarUrl,
        username: account.fullName || account.phone,
        lang: 'mu',
      });
      const tok = res?.data?.token || res?.token || '';
      if (!tok) throw new Error(res?.message || 'Soft Climbers login failed');
      setToken(tok);
      const updated = updateActiveAccount({ softClimbersToken: tok });
      if (updated) onAccountUpdated(updated);
      return tok;
    },
    [account.avatarUrl, account.fullName, account.phone, account.thirdPartyToken, onAccountUpdated, token]
  );

  const loadStatus = useCallback(
    async (tok: string) => {
      const [stRes, planRes] = await Promise.allSettled([
        softClimbersApi.getStatus(tok, account.phone),
        softClimbersApi.getOneTimePlans(tok, account.phone),
      ]);
      if (stRes.status === 'fulfilled') {
        setSubStatus(stRes.value?.data || stRes.value);
      }
      if (planRes.status === 'fulfilled') {
        const d = planRes.value?.data || planRes.value;
        setPlans(Array.isArray(d) ? d : d?.plans || d?.items || []);
      }
    },
    [account.phone]
  );

  const bootstrap = useCallback(
    async (forceLogin = false) => {
      setLoading(true);
      setErrorMsg('');
      try {
        let tok = await ensureSession(forceLogin);
        try {
          await loadStatus(tok);
        } catch (err) {
          if (err instanceof Error && (err.message.includes('401') || err.message.includes('403'))) {
            tok = await ensureSession(true);
            await loadStatus(tok);
          } else {
            throw err;
          }
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to connect to Soft Climbers');
      } finally {
        setLoading(false);
      }
    },
    [ensureSession, loadStatus]
  );

  useEffect(() => {
    bootstrap(false);
    return () => {
      stopRef.current = true;
    };
  }, [account.phone]);

  useEffect(() => {
    if (!token) return;
    if (tab === 'history') {
      softClimbersApi
        .getPrizeHistory(token, account.phone, 1, 20)
        .then((res) => {
          const d = res?.data || res;
          setHistoryRows(Array.isArray(d) ? d : d?.items || d?.content || []);
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load history'));
    } else if (tab === 'rank') {
      softClimbersApi
        .getLeaderboard(token, account.phone, 'WEEK')
        .then((res) => {
          const d = res?.data || res;
          setRankRows(Array.isArray(d) ? d : d?.ranks || d?.items || []);
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load leaderboard'));
    }
  }, [tab, token, account.phone]);

  const stopClimb = () => {
    stopRef.current = true;
    setIsClimbing(false);
    setClimbProgress(0);
  };

  const handleStartClimb = async () => {
    if (!token || isClimbing) return;
    stopRef.current = false;
    setIsClimbing(true);
    setErrorMsg('');
    setStatusMsg('');

    try {
      do {
        setClimbProgress(10);
        setLiveScore(0);
        const startRes = await softClimbersApi.startGame(token, account.phone, startLevel);
        if (startRes?.success === false) {
          throw new Error(startRes?.message || 'Unable to start Soft Climbers run');
        }
        const sessionId =
          startRes?.data?.sessionId || startRes?.sessionId || `sc_${Date.now()}`;
        let score = 0;
        let coins = 0;
        let distance = 0;

        for (let lvl = startLevel; lvl < startLevel + 5; lvl++) {
          if (stopRef.current) break;
          await new Promise((r) => window.setTimeout(r, 900));
          score += 650;
          coins += 12;
          distance += 240;
          setLiveScore(score);
          setClimbProgress(Math.round(((lvl - startLevel + 1) / 5) * 90));
          await softClimbersApi.sendEvent(token, account.phone, {
            sessionId,
            level: lvl,
            score,
            coins,
            distance,
            eventType: 'LEVEL_CLEAR',
          });
        }

        if (!stopRef.current) {
          await softClimbersApi.endGame(token, account.phone, {
            sessionId,
            finalLevel: startLevel + 4,
            finalScore: score,
            distance,
            reason: 'GAME_OVER',
          });
          setClimbProgress(100);
          setStatusMsg(`Climb complete! Score ${score.toLocaleString()} synced.`);
          await loadStatus(token);
        }
        if (stopRef.current || !autoLoop) break;
        await new Promise((r) => window.setTimeout(r, 600));
      } while (!stopRef.current && autoLoop);
    } catch (err) {
      if (!stopRef.current) {
        setErrorMsg(err instanceof Error ? err.message : 'Soft Climbers run failed');
      }
    } finally {
      setIsClimbing(false);
      setClimbProgress(0);
    }
  };

  const attempts = Number(subStatus?.attempts ?? subStatus?.remainingAttempts ?? subStatus?.turns ?? 0);
  const subActive = Boolean(subStatus?.isSubscribed || subStatus?.active || subStatus?.status === 'ACTIVE');

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Soft Climbers"
        subtitle="Auto-Climb Runner · One-Time Attempts & Subscriptions · Rank"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => bootstrap(true)}
            disabled={loading}
            aria-label="Sync Soft Climbers"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Hero Banner Card */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] overflow-hidden">
        <div className="relative h-32 sm:h-40 w-full">
          <img
            src={GAME_ASSETS.softClimbersBanner}
            alt="Soft Climbers"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#161920] via-[#161920]/40 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <img
                src={GAME_ASSETS.softClimbersLogo}
                alt=""
                className="h-12 w-12 rounded-2xl border border-[#C8942A]/50 bg-[#0C0F14] object-cover"
              />
              <div>
                <h2 className="font-display text-lg font-bold text-white">Soft Climbers</h2>
                <p className="text-xs font-mono-num text-slate-300">
                  {subActive ? 'Subscription Active' : 'Free / Pay-per-Run'} · {account.phone}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[11px] text-slate-400">Attempts</p>
              <p className="font-mono-num text-lg font-bold text-[#E8B040]">
                {loading ? '--' : attempts}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Android Tab Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'play', label: 'Climb Bot', icon: Mountain },
          { id: 'shop', label: 'Plans', icon: ShoppingBag },
          { id: 'history', label: 'Prizes', icon: History },
          { id: 'rank', label: 'Rank', icon: Trophy },
        ].map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as ScTab)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 flex items-center gap-2 border transition-all ${
                active
                  ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                  : 'border-white/10 bg-[#161920] text-slate-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusMsg}</span>
          <button type="button" onClick={() => setStatusMsg('')} className="text-xs underline">
            OK
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button type="button" onClick={() => setErrorMsg('')} className="text-xs underline">
            Close
          </button>
        </div>
      )}

      {tab === 'play' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-display text-lg font-bold text-white">Climb Event Runner</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Start → Level Clear Events → Game End Sync
              </p>
            </div>
            <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <span>Auto Loop</span>
              <button
                type="button"
                role="switch"
                aria-checked={autoLoop}
                onClick={() => setAutoLoop((v) => !v)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoLoop ? 'bg-[#4CAF50]' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    autoLoop ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </label>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1.5">Start Level</label>
            <input
              type="number"
              min={1}
              value={startLevel}
              onChange={(e) => setStartLevel(Math.max(1, Number(e.target.value) || 1))}
              className="w-full min-h-[46px] rounded-xl border border-white/10 bg-[#12151B] px-4 text-sm font-mono-num text-white"
            />
          </div>

          {isClimbing && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-mono-num">
                <span className="text-[#E8B040]">Score: {liveScore.toLocaleString()}</span>
                <span className="text-slate-400">{climbProgress}%</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#12151B] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all"
                  style={{ width: `${climbProgress}%` }}
                />
              </div>
            </div>
          )}

          {!isClimbing ? (
            <button
              type="button"
              disabled={loading || !token}
              onClick={handleStartClimb}
              className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Play className="h-4 w-4 fill-current" />
              <span>Start Climbing</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={stopClimb}
              className="w-full min-h-[48px] rounded-xl bg-red-600 text-sm font-bold text-white flex items-center justify-center gap-2"
            >
              <Square className="h-4 w-4 fill-current" />
              <span>Stop</span>
            </button>
          )}
        </div>
      )}

      {tab === 'shop' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {plans.length === 0 ? (
            <div className="sm:col-span-2 rounded-2xl border border-white/[0.08] bg-[#161920] p-8 text-center text-sm text-slate-400">
              No Soft Climbers plans returned yet.
            </div>
          ) : (
            plans.map((p, idx) => {
              const pid = String(p.id ?? p.planId ?? idx);
              const isSub = String(p.type || '').toUpperCase().includes('SUB');
              return (
                <div
                  key={`sc-plan-${pid}-${idx}`}
                  className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{p.name || `Plan #${pid}`}</p>
                    <p className="text-xs font-mono-num text-[#E8B040]">
                      {Number(p.price ?? 0).toLocaleString()} Ks · {p.attempts || 1} Runs
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={buyingPlanId === pid}
                    onClick={async () => {
                      if (!token) return;
                      setBuyingPlanId(pid);
                      try {
                        const res = isSub
                          ? await softClimbersApi.subscribe(token, account.phone, pid)
                          : await softClimbersApi.purchaseAttempts(token, account.phone, pid);
                        if (res?.success === false) throw new Error(res?.message || 'Purchase failed');
                        setStatusMsg(`Activated ${p.name || pid}`);
                        await loadStatus(token);
                      } catch (err) {
                        setErrorMsg(err instanceof Error ? err.message : 'Purchase failed');
                      } finally {
                        setBuyingPlanId(null);
                      }
                    }}
                    className="min-h-[42px] shrink-0 rounded-xl bg-[#C8942A] px-4 text-xs font-bold text-[#0C0F14]"
                  >
                    {buyingPlanId === pid ? '...' : 'Buy'}
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}

      {tab === 'history' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
          {historyRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No prize history yet.</div>
          ) : (
            historyRows.map((h, idx) => (
              <div key={`sc-hist-${h.id ?? idx}-${idx}`} className="p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{h.prizeName || h.title || 'Prize'}</p>
                  <p className="text-xs text-slate-400">{h.createdAt || h.date || ''}</p>
                </div>
                <span className="font-mono-num text-xs font-bold text-[#E8B040]">
                  {h.status || 'CLAIMED'}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'rank' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
          {rankRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No leaderboard entries yet.</div>
          ) : (
            rankRows.map((r, idx) => {
              const rank = Number(r.rank ?? idx + 1);
              const medal = getRankMedal(rank);
              return (
                <div key={`sc-rank-${rank}-${idx}`} className="px-4 py-3.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {medal ? (
                      <img src={medal} alt="" className="h-6 w-6 object-contain shrink-0" />
                    ) : (
                      <span className="w-6 text-center font-mono-num text-xs font-bold text-slate-400">
                        #{rank}
                      </span>
                    )}
                    <p className="text-sm font-semibold text-white truncate">
                      {r.username || r.msisdn || 'Climber'}
                    </p>
                  </div>
                  <span className="font-mono-num text-sm font-bold text-[#E8B040]">
                    {Number(r.score ?? r.highScore ?? 0).toLocaleString()}
                  </span>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
