import React, { useCallback, useEffect, useState } from 'react';
import { Loader2, RefreshCw, X } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { mytelApi } from '../lib/api';
import { KONG_ASSETS } from '../lib/kongAssets';
import type { SavedAccount, VasPackage } from '../types';

interface DataPackagesViewProps {
  account: SavedAccount;
  onBack: () => void;
}

function parseVasDescriptions(raw: any): { shortDesc?: string; fullDesc?: string } {
  if (Array.isArray(raw)) {
    const shortParts: string[] = [];
    const fullParts: string[] = [];
    raw.forEach((d: any) => {
      const s = d?.shortDesCription || d?.shortDescription;
      const f = d?.description;
      if (s) shortParts.push(String(s));
      if (f) fullParts.push(String(f));
    });
    return {
      shortDesc: shortParts.join(' · ') || undefined,
      fullDesc: fullParts.join('\n') || undefined,
    };
  }
  if (typeof raw === 'string' && raw.trim()) {
    return { fullDesc: raw.trim() };
  }
  return {};
}

export function DataPackagesView({ account, onBack }: DataPackagesViewProps) {
  const [packs, setPacks] = useState<VasPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<VasPackage | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [detailDesc, setDetailDesc] = useState('');
  const [purchasing, setPurchasing] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadPacks = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await mytelApi.getVasPacks(account.accessToken, account.phone);
      const list = res?.result || res?.data || [];
      const mapped: VasPackage[] = Array.isArray(list)
        ? list.map((p: any, idx: number) => {
            const parsedDesc = parseVasDescriptions(p.vasDescriptions);
            const days = Number(p.validity ?? p.validityDays ?? 0);
            return {
              id: String(p.id || p.code || idx),
              code: String(p.code || p.id || ''),
              name: String(p.name || 'Package'),
              price: Number(p.price || 0),
              validityDays: days,
              validity: days > 0 ? `${days} ရက်` : '24 နာရီ',
              shortDescription:
                p.shortDesCription || p.shortDescription
                  ? String(p.shortDesCription || p.shortDescription)
                  : parsedDesc.shortDesc,
              description: parsedDesc.fullDesc,
            };
          })
        : [];
      setPacks(mapped);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load packages');
    } finally {
      setLoading(false);
    }
  }, [account.accessToken, account.phone]);

  useEffect(() => {
    loadPacks();
  }, [loadPacks]);

  const handleOpenPack = async (pack: VasPackage) => {
    setSelected(pack);
    setDetailDesc(pack.description || pack.shortDescription || '');
    setLoadingDetail(true);
    try {
      const res = await mytelApi.getVasDetail(
        account.accessToken,
        pack.code || pack.id,
        account.phone
      );
      const r = res?.result || res?.data;
      if (r && typeof r === 'object') {
        const parsed = parseVasDescriptions(r.vasDescriptions);
        const days = Number(r.validity ?? r.validityDays ?? pack.validityDays);
        setSelected((prev) =>
          prev
            ? {
                ...prev,
                name: String(r.name || prev.name),
                price: Number(r.price ?? prev.price),
                validityDays: days,
                validity: days > 0 ? `${days} ရက်` : prev.validity,
              }
            : prev
        );
        const descText =
          parsed.fullDesc ||
          r.description ||
          parsed.shortDesc ||
          r.shortDesCription ||
          pack.shortDescription ||
          '';
        if (descText) setDetailDesc(String(descText));
      }
    } catch {
      // Keep list fallback description if detail request fails
    } finally {
      setLoadingDetail(false);
    }
  };

  const handleConfirmPurchase = async () => {
    if (!selected) return;
    setPurchasing(true);
    setFeedback('');
    setErrorMsg('');
    try {
      const res = await mytelApi.registerVasPackage(
        account.accessToken,
        selected.code || selected.id,
        account.phone
      );
      const ec = res?.errorCode;
      const ok = Number(ec) === 0 || Number(ec) === 200 || res?.success === true;
      if (!ok) {
        throw new Error(res?.message || 'Purchase failed');
      }
      setFeedback(res?.message || `${selected.name} ဝယ်ယူပြီးပါပြီ!`);
      setSelected(null);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Purchase failed');
      setSelected(null);
    } finally {
      setPurchasing(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Data Packages"
        subtitle="Special VAS & Data Packs"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={loadPacks}
            disabled={loading}
            aria-label="Refresh packages"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {feedback && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs font-medium text-[#81C784]">
          {feedback}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-28 rounded-2xl border border-white/[0.06] bg-[#141820] animate-pulse"
            />
          ))}
        </div>
      ) : packs.length === 0 ? (
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-10 text-center text-sm text-slate-400">
          No special data packages available.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {packs.map((pack, idx) => (
            <div
              key={`${pack.id}-${pack.code}-${idx}`}
              className="rounded-2xl border border-white/[0.08] bg-[#141820] p-5 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="h-10 w-10 rounded-xl bg-[#1A1F2A] border border-white/[0.06] flex items-center justify-center shrink-0">
                      <img src={KONG_ASSETS.icPrizeMb} alt="" className="h-6 w-6 object-contain" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-base font-semibold text-white truncate">{pack.name}</h3>
                      <p className="text-xs text-slate-400 mt-0.5">{pack.validity}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 font-mono-num text-sm font-bold text-[#E8B040] shrink-0">
                    <img src={KONG_ASSETS.icMmk} alt="" className="h-4 w-4 object-contain" />
                    <span>{pack.price.toLocaleString()} Ks</span>
                  </div>
                </div>
                {(pack.shortDescription || pack.description) && (
                  <p className="text-xs text-slate-300 line-clamp-2">
                    {pack.shortDescription || pack.description}
                  </p>
                )}
              </div>

              <button
                type="button"
                onClick={() => handleOpenPack(pack)}
                className="w-full min-h-[44px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] hover:brightness-105 active:scale-[0.98] transition-all"
              >
                ဝယ်မည်
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Purchase Confirmation Bottom Sheet */}
      {selected && (
        <div
          onClick={() => setSelected(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="font-display text-lg font-bold text-white truncate">
                  {selected.name}
                </h3>
                <p className="text-xs text-slate-400 font-mono-num mt-0.5">
                  {account.phone} နံပါတ်အတွက် ဝယ်ယူမည်
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="rounded-xl border border-white/[0.08] bg-[#1C212C] divide-y divide-white/[0.06] text-sm">
              <div className="px-4 py-3 flex items-center justify-between">
                <span className="text-slate-400">တန်ဖိုး</span>
                <span className="font-mono-num font-bold text-[#E8B040]">
                  {selected.price.toLocaleString()} Ks
                </span>
              </div>
              <div className="px-4 py-3 flex items-center justify-between">
                <span className="text-slate-400">သက်တမ်း</span>
                <span className="text-white">{selected.validity}</span>
              </div>
            </div>

            {loadingDetail ? (
              <div className="py-2 flex items-center gap-2 text-xs text-slate-400">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-[#E8B040]" />
                <span>Loading details...</span>
              </div>
            ) : detailDesc ? (
              <p className="text-xs text-slate-300 whitespace-pre-line leading-relaxed max-h-36 overflow-y-auto">
                {detailDesc}
              </p>
            ) : null}

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 text-sm font-semibold text-slate-300"
              >
                မဝယ်တော့
              </button>
              <button
                type="button"
                disabled={purchasing}
                onClick={handleConfirmPurchase}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
              >
                {purchasing && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>အတည်ပြုမည်</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
