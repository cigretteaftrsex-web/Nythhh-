import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Car,
  Check,
  Loader2,
  Pencil,
  Play,
  RefreshCw,
  ShoppingBag,
  Sparkles,
  Square,
  Trophy,
  X,
} from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { GAME_ASSETS } from '../lib/gameAssets';
import { carRacingApi } from '../lib/gamesApi';
import { KONG_ASSETS, getPackageAsset, getRankMedal } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface CarRacingViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onBack: () => void;
}

type CarTab = 'race' | 'shop' | 'tasks' | 'spin' | 'rank';

const STOMP_JOIN_DATA =
  'IJsBm8s6uMgYmXqXk06m7RD4EFkvG5rwQP+o6yfl7uHF2Kl/4m8kk/XwwEAdz9FI7CVEG5v6dfc52IgVLHvofYSQyAWQVhjzGf0k5R1mTd6LCohT70WWbO0ScdCT+33zfs5n+VehrRY1YdR+N1HfXA==';
const STOMP_START_DATA = 's4XbEyqBZKUcMSxCNZdD2J5XkXfvW1u50AiY/wyNvA8=';
const STOMP_END_DATA = 'dCkgKGd8D0MwZJQfL5HjV47U64XTwmaO50vBxRyAS2mSi1qUjUltpjpus5cC/782';

export function CarRacingView({ account, onAccountUpdated, onBack }: CarRacingViewProps) {
  const [jwt, setJwt] = useState(account.carRacingToken || '');
  const [tab, setTab] = useState<CarTab>('race');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  // Player Info
  const [userInfo, setUserInfo] = useState<any | null>(null);
  const [cars, setCars] = useState<any[]>([]);

  // STOMP Live Race State
  const [isRacing, setIsRacing] = useState(false);
  const [raceLoop, setRaceLoop] = useState(false);
  const [raceElapsed, setRaceElapsed] = useState(0);
  const [raceStatus, setRaceStatus] = useState('Idle');
  const [raceCount, setRaceCount] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const stopRaceRef = useRef(false);

  // Shop & Packages
  const [gemItems, setGemItems] = useState<any[]>([]);
  const [packages, setPackages] = useState<any[]>([]);
  const [buyingId, setBuyingId] = useState<string | null>(null);

  // Tasks & Achievements
  const [achievements, setAchievements] = useState<any[]>([]);
  const [dailyTasks, setDailyTasks] = useState<any[]>([]);
  const [userTasks, setUserTasks] = useState<any[]>([]);
  const [claimingId, setClaimingId] = useState<string | null>(null);

  // Spin
  const [spinData, setSpinData] = useState<any | null>(null);
  const [spinning, setSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<any | null>(null);

  // Rank
  const [rankConfig, setRankConfig] = useState<'RANK_MONTH' | 'RANK_WEEK'>('RANK_MONTH');
  const [rankRows, setRankRows] = useState<any[]>([]);

  // Name & Avatar modals
  const [editNameOpen, setEditNameOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [avatarOpen, setAvatarOpen] = useState(false);
  const [avatars, setAvatars] = useState<any[]>([]);

  const ensureSession = useCallback(
    async (force = false): Promise<string> => {
      if (!force && jwt) return jwt;
      const res = await carRacingApi.login({
        thirdPartyToken: account.thirdPartyToken,
        mcuid: account.mcuid || account.phone,
        uuid: account.mcuid || account.phone,
        phone: account.phone,
        avatar: account.avatarUrl,
        fullName: account.fullName,
      });
      const tok =
        res?.data?.accessToken || res?.data?.token || res?.accessToken || res?.token || '';
      if (!tok) throw new Error(res?.message || 'Car Racing login failed');
      setJwt(tok);
      const updated = updateActiveAccount({ carRacingToken: tok });
      if (updated) onAccountUpdated(updated);
      return tok;
    },
    [account.avatarUrl, account.fullName, account.mcuid, account.phone, account.thirdPartyToken, jwt, onAccountUpdated]
  );

  const loadInfo = useCallback(async (token: string) => {
    const res = await carRacingApi.getUserInfo(token);
    const info = res?.data || res;
    setUserInfo(info);
    const carList =
      info?.listCar || info?.cars || info?.userCars || [];
    if (Array.isArray(carList)) setCars(carList);
  }, []);

  const bootstrap = useCallback(
    async (forceLogin = false) => {
      setLoading(true);
      setErrorMsg('');
      try {
        let tok = await ensureSession(forceLogin);
        try {
          await loadInfo(tok);
        } catch (err) {
          if (err instanceof Error && err.message.includes('401')) {
            tok = await ensureSession(true);
            await loadInfo(tok);
          } else {
            throw err;
          }
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to connect to Car Racing');
      } finally {
        setLoading(false);
      }
    },
    [ensureSession, loadInfo]
  );

  useEffect(() => {
    bootstrap(false);
    return () => {
      stopRaceRef.current = true;
      wsRef.current?.close();
    };
  }, [account.phone]);

  useEffect(() => {
    if (!jwt) return;
    if (tab === 'shop') {
      Promise.allSettled([
        carRacingApi.getGemShop(jwt),
        carRacingApi.getPackages(jwt, 'ALL'),
      ]).then(([gRes, pRes]) => {
        if (gRes.status === 'fulfilled') {
          const d = gRes.value?.data || gRes.value;
          setGemItems(Array.isArray(d) ? d : d?.items || d?.listShop || []);
        }
        if (pRes.status === 'fulfilled') {
          const d = pRes.value?.data || pRes.value;
          setPackages(Array.isArray(d) ? d : d?.listPackage || []);
        }
      });
    } else if (tab === 'tasks') {
      Promise.allSettled([
        carRacingApi.getAchievements(jwt),
        carRacingApi.getDailyLoginTasks(jwt),
        carRacingApi.getUserTasks(jwt),
      ]).then(([aRes, dRes, uRes]) => {
        if (aRes.status === 'fulfilled') {
          const d = aRes.value?.data || aRes.value;
          setAchievements(Array.isArray(d) ? d : d?.list || []);
        }
        if (dRes.status === 'fulfilled') {
          const d = dRes.value?.data || dRes.value;
          setDailyTasks(Array.isArray(d) ? d : d?.list || []);
        }
        if (uRes.status === 'fulfilled') {
          const d = uRes.value?.data || uRes.value;
          setUserTasks(Array.isArray(d) ? d : d?.list || []);
        }
      });
    } else if (tab === 'spin') {
      carRacingApi
        .getSpinPrizes(jwt)
        .then((res) => setSpinData(res?.data || res))
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load spin'));
    } else if (tab === 'rank') {
      carRacingApi
        .getLeaderboard(jwt, rankConfig, 'DISTANCE')
        .then((res) => {
          const d = res?.data || res;
          setRankRows(Array.isArray(d) ? d : d?.ranks || d?.list || []);
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load rank'));
    }
  }, [tab, jwt, rankConfig]);

  const stopRace = () => {
    stopRaceRef.current = true;
    try {
      wsRef.current?.send('DISCONNECT\n\n\0');
    } catch {
      // ignore
    }
    wsRef.current?.close();
    wsRef.current = null;
    setIsRacing(false);
    setRaceStatus('Stopped');
  };

  const runSingleStompRace = async (token: string): Promise<void> => {
    return new Promise<void>((resolve, reject) => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws/carracing`);
      wsRef.current = ws;
      let startSent = false;
      let raceTimer: number | null = null;
      let elapsedTimer: number | null = null;

      const cleanup = () => {
        if (raceTimer) window.clearTimeout(raceTimer);
        if (elapsedTimer) window.clearInterval(elapsedTimer);
        try {
          ws.close();
        } catch {
          // ignore
        }
        if (wsRef.current === ws) wsRef.current = null;
      };

      ws.onmessage = (evt) => {
        const msg = String(evt.data || '');
        if (msg.includes('BRIDGE_OPEN')) {
          setRaceStatus('STOMP Connecting...');
          ws.send(
            'CONNECT\naccept-version:1.1,1.2\nhost:car-racing.mascom.vn\nheart-beat:10000,10000\n\n\0'
          );
          return;
        }
        if (msg.startsWith('CONNECTED')) {
          setRaceStatus('Joining Race Room...');
          ws.send('SUBSCRIBE\nid:room-state\ndestination:/user/topic/room/state\n\n\0');
          ws.send('SUBSCRIBE\nid:game-story\ndestination:/user/topic/room/story\n\n\0');
          ws.send('SUBSCRIBE\nid:error\ndestination:/user/topic/error\n\n\0');
          ws.send(
            `SEND\ndestination:/app/room/join\nAccept-Language:en\n\n${JSON.stringify({
              accessToken: token,
              data: STOMP_JOIN_DATA,
            })}\0`
          );
          return;
        }
        if (msg.includes('WAITING') && !startSent) {
          startSent = true;
          setRaceStatus('Racing Live (35s)...');
          ws.send(
            `SEND\ndestination:/app/room/start\n\n${JSON.stringify({
              accessToken: token,
              data: STOMP_START_DATA,
            })}\0`
          );
          const startedAt = Date.now();
          elapsedTimer = window.setInterval(() => {
            setRaceElapsed(Math.round((Date.now() - startedAt) / 1000));
          }, 500);

          raceTimer = window.setTimeout(() => {
            setRaceStatus('Finishing Race...');
            ws.send(
              `SEND\ndestination:/app/room/end\n\n${JSON.stringify({
                accessToken: token,
                data: STOMP_END_DATA,
              })}\0`
            );
            window.setTimeout(() => {
              ws.send('DISCONNECT\n\n\0');
              cleanup();
              resolve();
            }, 900);
          }, 35000);
        } else if (msg.includes('BRIDGE_ERROR') || msg.startsWith('ERROR')) {
          cleanup();
          reject(new Error('Car Racing WebSocket error'));
        }
      };

      ws.onerror = () => {
        cleanup();
        reject(new Error('WebSocket connection error'));
      };

      ws.onclose = () => {
        if (raceTimer) window.clearTimeout(raceTimer);
        if (elapsedTimer) window.clearInterval(elapsedTimer);
      };
    });
  };

  const handleStartRace = async () => {
    if (!jwt || isRacing) return;
    stopRaceRef.current = false;
    setIsRacing(true);
    setErrorMsg('');
    setRaceCount(0);

    try {
      do {
        setRaceElapsed(0);
        await runSingleStompRace(jwt);
        setRaceCount((c) => c + 1);
        await loadInfo(jwt);
        setStatusMsg('Race completed & rewards synced!');
        if (stopRaceRef.current || !raceLoop) break;
        await new Promise((r) => window.setTimeout(r, 800));
      } while (!stopRaceRef.current && raceLoop);
    } catch (err) {
      if (!stopRaceRef.current) {
        setErrorMsg(err instanceof Error ? err.message : 'Race failed');
      }
    } finally {
      setIsRacing(false);
      setRaceStatus('Idle');
    }
  };

  const handleCarAction = async (carId: number | string) => {
    if (!jwt) return;
    setErrorMsg('');
    try {
      const res = await carRacingApi.buyOrUseCar(jwt, carId);
      if (res?.success === false) throw new Error(res?.message || 'Car action failed');
      setStatusMsg('Car equipped / updated!');
      await loadInfo(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Car action failed');
    }
  };

  const handleSpin = async () => {
    if (!jwt || spinning) return;
    setSpinning(true);
    setErrorMsg('');
    try {
      const res = await carRacingApi.spinWheel(jwt);
      if (res?.success === false) throw new Error(res?.message || 'Spin failed');
      setSpinResult(res?.data || res);
      await loadInfo(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Spin failed');
    } finally {
      setSpinning(false);
    }
  };

  const handleBuyPackage = async (code: string) => {
    if (!jwt) return;
    setBuyingId(code);
    setErrorMsg('');
    try {
      const res = await carRacingApi.buyPackage(jwt, code);
      if (res?.success === false) throw new Error(res?.message || 'Package purchase failed');
      setStatusMsg(`Purchased package ${code}`);
      await loadInfo(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Purchase failed');
    } finally {
      setBuyingId(null);
    }
  };

  const handleBuyShopItem = async (item: any) => {
    if (!jwt) return;
    const id = String(item.id);
    setBuyingId(id);
    setErrorMsg('');
    try {
      const res = await carRacingApi.buyShopItem(jwt, item.id, 'GEM');
      if (res?.success === false) throw new Error(res?.message || 'Item purchase failed');
      setStatusMsg(`Purchased ${item.name || 'Item'}`);
      await loadInfo(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Purchase failed');
    } finally {
      setBuyingId(null);
    }
  };

  const coins = Number(userInfo?.totalCoin ?? userInfo?.coin ?? 0);
  const gems = Number(userInfo?.totalGem ?? userInfo?.gem ?? 0);
  const tickets = Number(userInfo?.totalTicket ?? userInfo?.ticket ?? 0);

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Car Racing"
        subtitle="STOMP Auto-Race · Garage · Shop · Lucky Spin"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => bootstrap(true)}
            disabled={loading}
            aria-label="Sync Car Racing"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Profile + Currency Strip */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <button
              type="button"
              onClick={async () => {
                if (!jwt) return;
                setAvatarOpen(true);
                const r = await carRacingApi.getAvatarList(jwt).catch(() => null);
                setAvatars(Array.isArray(r?.data) ? r.data : []);
              }}
              className="h-12 w-12 rounded-2xl border border-[#C8942A]/40 overflow-hidden shrink-0"
            >
              <img
                src={userInfo?.avatar || GAME_ASSETS.carRacingLogo}
                alt="Car Racing"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
                  {userInfo?.playerName || account.fullName || account.phone}
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    setNameDraft(userInfo?.playerName || '');
                    setEditNameOpen(true);
                  }}
                  aria-label="Edit driver name"
                  className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-[#E8B040]"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="text-xs font-mono-num text-slate-400">{userInfo?.msisdn || account.phone}</p>
            </div>
          </div>
          <span className="text-xs font-semibold text-slate-400 font-mono-num">
            {isRacing ? `${raceElapsed}s` : `Races: ${raceCount}`}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2.5 sm:gap-3 pt-2 border-t border-white/[0.06]">
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icCoin} alt="Coins" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Coins</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-[#E8B040] truncate">
                {loading ? '--' : coins.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icGem} alt="Gems" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Gems</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-sky-400 truncate">
                {loading ? '--' : gems.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icLicensePackC6} alt="Ticket" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Fuel / Tkt</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-white truncate">
                {loading ? '--' : tickets.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Android Tab Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'race', label: 'Race', icon: Car },
          { id: 'shop', label: 'Shop', icon: ShoppingBag },
          { id: 'tasks', label: 'Tasks', icon: Check },
          { id: 'spin', label: 'Lucky Spin', icon: Sparkles },
          { id: 'rank', label: 'Rank', icon: Trophy },
        ].map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as CarTab)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 flex items-center gap-2 border transition-all ${
                active
                  ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                  : 'border-white/10 bg-[#161920] text-slate-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusMsg}</span>
          <button type="button" onClick={() => setStatusMsg('')} className="text-xs underline">
            OK
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button type="button" onClick={() => setErrorMsg('')} className="text-xs underline">
            Close
          </button>
        </div>
      )}

      {/* TAB: RACE & GARAGE */}
      {tab === 'race' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-bold text-white">STOMP Auto-Race</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Status: <span className="text-[#E8B040] font-semibold">{raceStatus}</span>
                </p>
              </div>
              <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                <span>Auto Loop</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={raceLoop}
                  onClick={() => setRaceLoop((v) => !v)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    raceLoop ? 'bg-[#4CAF50]' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      raceLoop ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </label>
            </div>

            {isRacing && (
              <div className="space-y-1.5">
                <div className="h-2.5 w-full rounded-full bg-[#12151B] overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all"
                    style={{ width: `${Math.min(100, Math.round((raceElapsed / 35) * 100))}%` }}
                  />
                </div>
                <p className="text-xs font-mono-num text-slate-400 text-right">{raceElapsed}s / 35s</p>
              </div>
            )}

            {!isRacing ? (
              <button
                type="button"
                disabled={loading || !jwt}
                onClick={handleStartRace}
                className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>Start Auto Race</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={stopRace}
                className="w-full min-h-[48px] rounded-xl bg-red-600 text-sm font-bold text-white flex items-center justify-center gap-2"
              >
                <Square className="h-4 w-4 fill-current" />
                <span>Stop Race</span>
              </button>
            )}
          </div>

          {cars.length > 0 && (
            <div className="space-y-2.5">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Garage ({cars.length})</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {cars.map((car, idx) => (
                  <div
                    key={`car-${car.id ?? idx}-${idx}`}
                    className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">
                        {car.name || car.carName || `Car #${car.id}`}
                      </p>
                      <p className="text-xs text-slate-400 font-mono-num">
                        {car.status || 'AVAILABLE'} · {car.price ? `${Number(car.price).toLocaleString()} Coins` : 'Ready'}
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={car.status === 'USING'}
                      onClick={() => handleCarAction(car.id)}
                      className={`min-h-[42px] px-4 rounded-xl text-xs font-bold ${
                        car.status === 'USING'
                          ? 'border border-[#4CAF50]/40 bg-[#4CAF50]/10 text-[#81C784]'
                          : 'bg-[#C8942A] text-[#0C0F14]'
                      }`}
                    >
                      {car.status === 'USING' ? 'Using' : 'Use / Buy'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB: SHOP & PACKAGES */}
      {tab === 'shop' && (
        <div className="space-y-5">
          {packages.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Telecom Packages</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {packages.map((pkg, idx) => (
                  <div
                    key={`car-pkg-${pkg.code ?? idx}-${idx}`}
                    className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={getPackageAsset(pkg.code || pkg.name || '')}
                        alt=""
                        className="h-10 w-10 object-contain shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{pkg.name || pkg.code}</p>
                        <p className="text-xs font-mono-num text-[#E8B040]">
                          {Number(pkg.price ?? 0).toLocaleString()} Ks
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={buyingId === pkg.code}
                      onClick={() => handleBuyPackage(pkg.code)}
                      className="min-h-[42px] shrink-0 rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 text-xs font-bold text-[#0C0F14]"
                    >
                      {buyingId === pkg.code ? '...' : 'Buy'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Gem Shop</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {gemItems.map((item, idx) => (
                <div
                  key={`car-gem-${item.id ?? idx}-${idx}`}
                  className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img src={GAME_ASSETS.icGem} alt="" className="h-8 w-8 object-contain shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{item.name || item.typeItem}</p>
                      <p className="text-xs font-mono-num text-[#E8B040]">
                        {Number(item.price ?? 0).toLocaleString()} Gems
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={buyingId === String(item.id)}
                    onClick={() => handleBuyShopItem(item)}
                    className="min-h-[42px] rounded-xl border border-[#C8942A]/40 bg-[#C8942A]/15 px-3.5 text-xs font-bold text-[#E8B040]"
                  >
                    {buyingId === String(item.id) ? '...' : 'Buy'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB: TASKS & ACHIEVEMENTS */}
      {tab === 'tasks' && (
        <div className="space-y-4">
          {[
            { label: 'Daily Login', rows: dailyTasks, kind: 'daily' },
            { label: 'User Tasks', rows: userTasks, kind: 'user' },
            { label: 'Achievements', rows: achievements, kind: 'ach' },
          ].map((sec) => (
            <div key={sec.kind} className="space-y-2.5">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                {sec.label} ({sec.rows.length})
              </h3>
              <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
                {sec.rows.length === 0 ? (
                  <p className="p-4 text-xs text-slate-400">No items in this category.</p>
                ) : (
                  sec.rows.map((r, idx) => {
                    const id = String(r.id ?? idx);
                    const claimed = r.claimed === true || r.status === 'CLAIMED';
                    return (
                      <div key={`${sec.kind}-${id}-${idx}`} className="p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-white truncate">
                            {r.name || r.title || r.description || `Task #${id}`}
                          </p>
                          <p className="text-xs font-mono-num text-slate-400">
                            Reward: {r.reward || r.value || 1} {r.typeItem || ''}
                          </p>
                        </div>
                        <button
                          type="button"
                          disabled={claimed || claimingId === `${sec.kind}-${id}`}
                          onClick={async () => {
                            if (!jwt) return;
                            setClaimingId(`${sec.kind}-${id}`);
                            try {
                              if (sec.kind === 'daily') await carRacingApi.claimDailyLoginTask(jwt, r.id);
                              else if (sec.kind === 'user') await carRacingApi.claimUserTask(jwt, r.id);
                              else await carRacingApi.claimAchievement(jwt, r.id);
                              setStatusMsg('Reward claimed!');
                              await loadInfo(jwt);
                            } catch (err) {
                              setErrorMsg(err instanceof Error ? err.message : 'Claim failed');
                            } finally {
                              setClaimingId(null);
                            }
                          }}
                          className="min-h-[40px] shrink-0 rounded-xl bg-[#C8942A] px-3.5 text-xs font-bold text-[#0C0F14] disabled:opacity-45"
                        >
                          {claimingId === `${sec.kind}-${id}` ? '...' : claimed ? 'Done' : 'Claim'}
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB: SPIN */}
      {tab === 'spin' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-6 text-center space-y-5">
          <img src={KONG_ASSETS.icLuckySpin} alt="Lucky Spin" className="h-20 w-20 object-contain mx-auto" />
          <div>
            <h3 className="font-display text-lg font-bold text-white">Car Racing Lucky Spin</h3>
            <p className="text-xs text-slate-400 mt-1 font-mono-num">
              Free Spins: {spinData?.turnFree ?? 0} · Cost: {Number(spinData?.price ?? 0).toLocaleString()}
            </p>
          </div>
          <button
            type="button"
            disabled={spinning}
            onClick={handleSpin}
            className="w-full max-w-xs min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] mx-auto flex items-center justify-center gap-2"
          >
            {spinning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            <span>{spinning ? 'Spinning...' : 'SPIN NOW'}</span>
          </button>
          {spinResult && (
            <div className="rounded-xl border border-[#C8942A]/40 bg-[#12151B] p-4 text-sm font-bold text-[#E8B040]">
              Won: {spinResult.name || spinResult.description || spinResult.typeItem || 'Prize!'}
            </div>
          )}
        </div>
      )}

      {/* TAB: RANK */}
      {tab === 'rank' && (
        <div className="space-y-3">
          <div className="inline-flex rounded-xl border border-white/10 bg-[#141820] p-1">
            {([
              { id: 'RANK_MONTH', label: 'Monthly' },
              { id: 'RANK_WEEK', label: 'Weekly' },
            ] as const).map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setRankConfig(r.id)}
                className={`min-h-[40px] px-4 rounded-lg text-xs font-semibold ${
                  rankConfig === r.id ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
            {rankRows.length === 0 ? (
              <p className="p-8 text-center text-sm text-slate-400">No leaderboard rows yet.</p>
            ) : (
              rankRows.map((row, idx) => {
                const rank = Number(row.order ?? row.rank ?? idx + 1);
                const medal = getRankMedal(rank);
                return (
                  <div key={`car-rank-${rank}-${idx}`} className="px-4 py-3.5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {medal ? (
                        <img src={medal} alt="" className="h-6 w-6 object-contain shrink-0" />
                      ) : (
                        <span className="w-6 text-center font-mono-num text-xs font-bold text-slate-400">
                          #{rank}
                        </span>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {row.playerName || row.msisdn || 'Driver'}
                        </p>
                        <p className="text-xs font-mono-num text-slate-400">{row.msisdn || ''}</p>
                      </div>
                    </div>
                    <span className="font-mono-num text-sm font-bold text-[#E8B040]">
                      {Number(row.distance ?? row.score ?? row.coin ?? 0).toLocaleString()}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {editNameOpen && (
        <div
          onClick={() => setEditNameOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={async (e) => {
              e.preventDefault();
              if (!jwt || !nameDraft.trim()) return;
              await carRacingApi.updatePlayerName(jwt, nameDraft.trim());
              setEditNameOpen(false);
              await loadInfo(jwt);
            }}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Driver Name</h3>
              <button type="button" onClick={() => setEditNameOpen(false)} className="h-9 w-9 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>
            <input
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              className="w-full min-h-[48px] rounded-xl border border-white/10 bg-[#12151B] px-4 text-sm text-white"
            />
            <button
              type="submit"
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14]"
            >
              Save
            </button>
          </form>
        </div>
      )}

      {/* Avatar Sheet */}
      {avatarOpen && (
        <div
          onClick={() => setAvatarOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 max-h-[80vh] overflow-y-auto animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Avatars</h3>
              <button type="button" onClick={() => setAvatarOpen(false)} className="h-9 w-9 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {avatars.map((av, idx) => (
                <button
                  key={`car-av-${av.id ?? idx}-${idx}`}
                  type="button"
                  onClick={async () => {
                    if (!jwt) return;
                    await carRacingApi.buyAvatar(jwt, av.id);
                    setAvatarOpen(false);
                    await loadInfo(jwt);
                  }}
                  className="rounded-xl border border-white/10 bg-[#12151B] p-2.5 flex flex-col items-center gap-2"
                >
                  <img src={av.url} alt="" className="h-14 w-14 rounded-full object-cover" />
                  <span className="text-[11px] font-bold text-[#E8B040]">{av.status || 'Select'}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
