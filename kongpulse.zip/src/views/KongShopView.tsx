import React, { useCallback, useEffect, useState } from 'react';
import { Loader2, RefreshCw, X } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { useKongRunner } from '../context/KongRunnerContext';
import { kongApi } from '../lib/api';
import { KONG_ASSETS, getPackageAsset } from '../lib/kongAssets';
import type { KongPackage, SavedAccount } from '../types';

interface KongShopViewProps {
  account: SavedAccount;
  onBack: () => void;
}

function PackageIcon({ pkg }: { pkg: KongPackage }) {
  const [failed, setFailed] = useState(false);
  const src = !failed && pkg.icon ? pkg.icon : getPackageAsset(pkg.code || pkg.name);
  return (
    <img
      src={src}
      alt={pkg.name}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className="h-12 w-12 rounded-xl object-contain bg-[#12151B] p-1 shrink-0 border border-white/10"
    />
  );
}

export function KongShopView({ account, onBack }: KongShopViewProps) {
  const kong = useKongRunner();
  const [tab, setTab] = useState<'ALL' | 'RENEW' | 'RETAIL'>('ALL');
  const [packages, setPackages] = useState<KongPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmPkg, setConfirmPkg] = useState<KongPackage | null>(null);
  const [buyingCode, setBuyingCode] = useState<string | null>(null);
  const [feedback, setFeedback] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadPackages = useCallback(
    async (type: 'ALL' | 'RENEW' | 'RETAIL') => {
      setLoading(true);
      setErrorMsg('');
      try {
        let tok = kong.kongToken;
        if (!tok) {
          const resolved = await kong.ensureKongSession(account);
          if (!resolved) {
            setLoading(false);
            return;
          }
          tok = resolved;
        }
        const res = await kongApi.getPackages(tok, type);
        const list = res?.data?.listPackage || res?.data || [];
        const mapped: KongPackage[] = Array.isArray(list)
          ? list.map((p: any) => ({
              code: String(p.code || ''),
              name: String(p.name || 'Package'),
              icon: p.icon ? String(p.icon) : undefined,
              price: Number(p.price || 0),
              typePrice: p.typePrice ? String(p.typePrice) : 'MMK',
              typePackage: p.typePackage ? String(p.typePackage) : undefined,
              ticket: Number(p.ticket || 0),
              banana: Number(p.banana || 0),
              magnet: Number(p.magnet || 0),
              protect: Number(p.protect || 0),
              reborn: Number(p.reborn || 0),
              x2banana: Number(p.x2banana || 0),
              autoRenew: Boolean(p.autoRenew),
              vipRequire: Boolean(p.vipRequire),
            }))
          : [];
        setPackages(mapped);
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Package list ယူ၍ မရပါ။');
      } finally {
        setLoading(false);
      }
    },
    [account, kong]
  );

  useEffect(() => {
    loadPackages(tab);
  }, [account.phone, tab]);

  const handleConfirmBuy = async () => {
    if (!confirmPkg || !kong.kongToken) return;
    setBuyingCode(confirmPkg.code);
    setFeedback('');
    setErrorMsg('');
    try {
      const res = await kongApi.buyPackage(kong.kongToken, confirmPkg.code);
      if (res?.success === false) {
        throw new Error(res?.message || 'ဝယ်ယူ၍ မရပါ။');
      }
      setFeedback(`${confirmPkg.name} ဝယ်ယူပြီးပါပြီ!`);
      setConfirmPkg(null);
      await kong.refreshUserInfo();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'ဝယ်ယူ၍ မရပါ။');
      setConfirmPkg(null);
    } finally {
      setBuyingCode(null);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Kong Island Shop"
        subtitle="Play Tickets & Power-up Bundles"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => loadPackages(tab)}
            disabled={loading}
            aria-label="Refresh packages"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      <div className="inline-flex items-center gap-1 rounded-xl border border-white/[0.08] bg-[#141820] p-1">
        {(
          [
            { key: 'ALL', label: 'All Packs' },
            { key: 'RENEW', label: 'Subscription' },
            { key: 'RETAIL', label: 'Retail' },
          ] as const
        ).map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setTab(item.key)}
            className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
              tab === item.key ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400 hover:text-white'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {feedback && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784]">
          {feedback}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300">
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-32 rounded-2xl border border-white/[0.06] bg-[#161920] animate-pulse"
            />
          ))}
        </div>
      ) : packages.length === 0 ? (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-10 text-center text-sm text-slate-400">
          Package မရှိသေးပါ။
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {packages.map((pkg, idx) => {
            const perkIcons = [
              pkg.ticket > 0 ? { icon: KONG_ASSETS.icTicket, text: `${pkg.ticket}` } : null,
              pkg.banana > 0 ? { icon: KONG_ASSETS.icBanana, text: pkg.banana.toLocaleString() } : null,
              pkg.x2banana > 0 ? { icon: KONG_ASSETS.icX2Banana, text: `×${pkg.x2banana}` } : null,
              pkg.protect > 0 ? { icon: KONG_ASSETS.icProtect, text: `×${pkg.protect}` } : null,
              pkg.magnet > 0 ? { icon: KONG_ASSETS.icMagnet, text: `×${pkg.magnet}` } : null,
              pkg.reborn > 0 ? { icon: KONG_ASSETS.icReborn, text: `×${pkg.reborn}` } : null,
            ].filter(Boolean) as Array<{ icon: string; text: string }>;

            return (
              <div
                key={`${pkg.code}-${idx}`}
                className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 flex flex-col justify-between gap-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <PackageIcon pkg={pkg} />
                    <div className="min-w-0">
                      <h3 className="text-base font-semibold text-white truncate">{pkg.name}</h3>
                      {perkIcons.length > 0 ? (
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 mt-1.5">
                          {perkIcons.map((p, pIdx) => (
                            <span
                              key={pIdx}
                              className="inline-flex items-center gap-1 text-xs text-slate-300 font-mono-num"
                            >
                              <img src={p.icon} alt="" className="h-4 w-4 object-contain" />
                              <span>{p.text}</span>
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-400 mt-1">{pkg.code}</p>
                      )}
                      {(pkg.autoRenew || pkg.vipRequire) && (
                        <p className="text-[11px] text-[#E8B040] mt-1 font-medium">
                          {[pkg.autoRenew ? 'AUTO RENEW' : '', pkg.vipRequire ? 'VIP' : '']
                            .filter(Boolean)
                            .join(' · ')}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 font-mono-num text-sm font-bold text-[#E8B040] shrink-0">
                    <img src={KONG_ASSETS.icMmk} alt="" className="h-4 w-4 object-contain" />
                    <span>
                      {pkg.price.toLocaleString()} {pkg.typePrice || 'MMK'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={buyingCode === pkg.code}
                  onClick={() => setConfirmPkg(pkg)}
                  className="w-full min-h-[44px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14] flex items-center justify-center gap-2 hover:brightness-105 active:scale-[0.98] transition-all disabled:opacity-60"
                >
                  <span>ဝယ်မည်</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Purchase Confirmation Bottom Sheet */}
      {confirmPkg && (
        <div
          onClick={() => setConfirmPkg(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <PackageIcon pkg={confirmPkg} />
                <h3 className="font-display text-lg font-bold text-white truncate">
                  {confirmPkg.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setConfirmPkg(null)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white shrink-0"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="rounded-xl border border-white/[0.08] bg-[#1C212C] divide-y divide-white/[0.06] text-xs">
              <div className="px-4 py-3 flex items-center justify-between">
                <span className="text-slate-400">Price</span>
                <span className="font-mono-num font-bold text-[#E8B040]">
                  {confirmPkg.price.toLocaleString()} {confirmPkg.typePrice || 'MMK'}
                </span>
              </div>
              {confirmPkg.ticket > 0 && (
                <div className="px-4 py-3 flex items-center justify-between">
                  <span className="text-slate-400">Tickets</span>
                  <span className="font-mono-num text-white">+{confirmPkg.ticket}</span>
                </div>
              )}
              {confirmPkg.banana > 0 && (
                <div className="px-4 py-3 flex items-center justify-between">
                  <span className="text-slate-400">Banana Bonus</span>
                  <span className="font-mono-num text-white">
                    +{confirmPkg.banana.toLocaleString()}
                  </span>
                </div>
              )}
              {confirmPkg.x2banana > 0 && (
                <div className="px-4 py-3 flex items-center justify-between">
                  <span className="text-slate-400">x2 Banana</span>
                  <span className="font-mono-num text-white">+{confirmPkg.x2banana}</span>
                </div>
              )}
              {confirmPkg.protect > 0 && (
                <div className="px-4 py-3 flex items-center justify-between">
                  <span className="text-slate-400">Shield Protect</span>
                  <span className="font-mono-num text-white">+{confirmPkg.protect}</span>
                </div>
              )}
              {confirmPkg.magnet > 0 && (
                <div className="px-4 py-3 flex items-center justify-between">
                  <span className="text-slate-400">Magnet</span>
                  <span className="font-mono-num text-white">+{confirmPkg.magnet}</span>
                </div>
              )}
              {confirmPkg.reborn > 0 && (
                <div className="px-4 py-3 flex items-center justify-between">
                  <span className="text-slate-400">Reborn Heart</span>
                  <span className="font-mono-num text-white">+{confirmPkg.reborn}</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setConfirmPkg(null)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 text-xs font-semibold text-slate-300"
              >
                မဝယ်တော့
              </button>
              <button
                type="button"
                disabled={buyingCode === confirmPkg.code}
                onClick={handleConfirmBuy}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14] flex items-center justify-center gap-2"
              >
                {buyingCode === confirmPkg.code && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>အတည်ပြုမည်</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
