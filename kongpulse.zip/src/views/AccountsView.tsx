import React, { useEffect, useState } from 'react';
import { CheckCircle2, Plus, Trash2, User } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import {
  deleteAccount,
  getKeepScreenOn,
  getSavedAccounts,
  setCurrentPhone,
  setKeepScreenOn,
} from '../lib/storage';
import type { SavedAccount } from '../types';

interface AccountsViewProps {
  activeAccount: SavedAccount | null;
  onBack: () => void;
  onAccountSwitched: (account: SavedAccount | null) => void;
  onAddAccount: () => void;
}

export function AccountsView({
  activeAccount,
  onBack,
  onAccountSwitched,
  onAddAccount,
}: AccountsViewProps) {
  const [tab, setTab] = useState<'account' | 'custom'>('account');
  const [accounts, setAccounts] = useState<SavedAccount[]>(() => getSavedAccounts());
  const [confirmDeletePhone, setConfirmDeletePhone] = useState<string | null>(null);
  const [keepScreen, setKeepScreen] = useState(() => getKeepScreenOn());
  const [wakeStatus, setWakeStatus] = useState('');

  useEffect(() => {
    setAccounts(getSavedAccounts());
  }, [activeAccount]);

  const handleSwitch = (acc: SavedAccount) => {
    setCurrentPhone(acc.phone);
    onAccountSwitched(acc);
  };

  const handleDeleteConfirm = (phone: string) => {
    const remaining = deleteAccount(phone);
    setAccounts(remaining);
    setConfirmDeletePhone(null);
    const nextActive = remaining.find((a) => a.phone === activeAccount?.phone) || remaining[0] || null;
    onAccountSwitched(nextActive);
  };

  const handleToggleKeepScreen = async () => {
    const next = !keepScreen;
    setKeepScreen(next);
    setKeepScreenOn(next);
    if (next && 'wakeLock' in navigator) {
      try {
        await (navigator as any).wakeLock.request('screen');
        setWakeStatus('Wake Lock active while tab stays open.');
      } catch {
        setWakeStatus('Preference saved (browser restricted automatic wake lock).');
      }
    } else {
      setWakeStatus(next ? 'Preference saved.' : 'Wake Lock disabled.');
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-6 pb-24 md:pb-10">
      <PageBackHeader title="Accounts & Preferences" onBack={onBack} />

      {/* Segmented Tabs: Account | Custom */}
      <div className="inline-flex items-center gap-1 rounded-xl border border-white/[0.08] bg-[#141820] p-1 mb-6">
        <button
          type="button"
          onClick={() => setTab('account')}
          className={`min-h-[40px] px-5 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
            tab === 'account'
              ? 'bg-[#C8942A] text-[#0C0F14] font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Account
        </button>
        <button
          type="button"
          onClick={() => setTab('custom')}
          className={`min-h-[40px] px-5 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
            tab === 'custom'
              ? 'bg-[#C8942A] text-[#0C0F14] font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Custom
        </button>
      </div>

      {tab === 'account' ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-medium text-slate-300">Saved accounts</h2>
            <button
              type="button"
              onClick={onAddAccount}
              className="inline-flex items-center gap-2 min-h-[40px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] hover:brightness-105 transition-all whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" />
              Add Account
            </button>
          </div>

          {accounts.length === 0 ? (
            <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-10 text-center">
              <p className="text-sm text-slate-400 mb-4">No saved accounts yet</p>
              <button
                type="button"
                onClick={onAddAccount}
                className="inline-flex items-center gap-2 rounded-xl bg-[#C8942A] px-5 py-2.5 text-sm font-bold text-[#0C0F14]"
              >
                <Plus className="h-4 w-4" />
                Add Account
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {accounts.map((acc, idx) => {
                const isActive = activeAccount?.phone === acc.phone;
                return (
                  <div
                    key={`${acc.phone}-${idx}`}
                    className={`rounded-2xl border p-4 flex items-center justify-between gap-4 transition-colors ${
                      isActive
                        ? 'border-[#C8942A]/60 bg-[#1B1E24]'
                        : 'border-white/[0.08] bg-[#141820] hover:border-white/20'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => handleSwitch(acc)}
                      className="flex items-center gap-3.5 text-left min-w-0 flex-1"
                    >
                      <div className="h-12 w-12 rounded-full border border-white/10 bg-[#202530] overflow-hidden shrink-0 flex items-center justify-center">
                        {acc.avatarUrl ? (
                          <img
                            src={acc.avatarUrl}
                            alt={acc.fullName}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <User className="h-5 w-5 text-slate-400" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-white truncate">
                            {acc.fullName || acc.phone}
                          </span>
                          {isActive && (
                            <CheckCircle2 className="h-4 w-4 text-[#4CAF50] shrink-0" />
                          )}
                        </div>
                        <p className="text-xs font-mono-num text-slate-400 mt-0.5">
                          {acc.phone}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfirmDeletePhone(acc.phone)}
                      aria-label={`Remove ${acc.phone}`}
                      className="h-10 w-10 rounded-xl border border-white/10 bg-[#181C24] text-slate-400 hover:text-red-400 hover:border-red-500/40 flex items-center justify-center shrink-0 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-6">
          <div className="flex items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-white">
                Screen ဖွင့်ထားမည်
              </h2>
              <p className="text-sm text-slate-400">
                App သုံးနေစဉ် ဖုန်း screen အလိုအလျောက် မပိတ်အောင် ထားမည်
              </p>
              {wakeStatus && (
                <p className="text-xs text-[#E8B040] pt-1">{wakeStatus}</p>
              )}
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={keepScreen}
              onClick={handleToggleKeepScreen}
              className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors ${
                keepScreen ? 'bg-[#4CAF50]' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                  keepScreen ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      )}

      {/* Delete confirmation bottom sheet */}
      {confirmDeletePhone && (
        <div
          onClick={() => setConfirmDeletePhone(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <h3 className="font-display text-lg font-bold text-white">Remove Account</h3>
            <p className="text-sm text-slate-300">
              Remove <span className="font-mono-num text-white">{confirmDeletePhone}</span> from saved accounts?
            </p>
            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setConfirmDeletePhone(null)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/5"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteConfirm(confirmDeletePhone)}
                className="flex-1 min-h-[46px] rounded-xl bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-500"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
