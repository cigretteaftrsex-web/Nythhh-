import React, { useCallback, useEffect, useState } from 'react';
import { ArrowRight, Loader2, RefreshCw } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { mytelApi } from '../lib/api';
import { KONG_ASSETS } from '../lib/kongAssets';
import type { LoyaltyPack, SavedAccount } from '../types';

interface PointsExchangeViewProps {
  account: SavedAccount;
  onBack: () => void;
}

const CATEGORIES = ['DATA', 'VOICE', 'SMS', 'SUPER'] as const;
type Category = (typeof CATEGORIES)[number];

export function PointsExchangeView({ account, onBack }: PointsExchangeViewProps) {
  const [category, setCategory] = useState<Category>('DATA');
  const [packs, setPacks] = useState<LoyaltyPack[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPack, setSelectedPack] = useState<LoyaltyPack | null>(null);
  const [exchanging, setExchanging] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadPacks = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await mytelApi.getLoyaltyPacks(account.accessToken, account.phone);
      const rawList = res?.result || res?.data || [];
      const mapped: LoyaltyPack[] = [];

      if (Array.isArray(rawList)) {
        rawList.forEach((entry: any) => {
          // APK PointsExchangeActivity$1: res.result is an array of { categoryCode, rewards: [...] }
          if (Array.isArray(entry?.rewards)) {
            const groupCat = String(entry.categoryCode || entry.category || 'DATA').toUpperCase();
            entry.rewards.forEach((rw: any) => {
              mapped.push({
                rewardCode: String(rw.rewardCode || rw.code || ''),
                rewardName: String(rw.rewardName || rw.name || ''),
                pointAmount: Number(rw.pointAmount ?? rw.points ?? 0),
                validityDayText: rw.validityDayText ? String(rw.validityDayText) : undefined,
                category: groupCat,
              });
            });
          } else {
            // Flat fallback if API returns ungrouped items
            mapped.push({
              rewardCode: String(entry.rewardCode || entry.code || ''),
              rewardName: String(entry.rewardName || entry.name || ''),
              pointAmount: Number(entry.pointAmount ?? entry.points ?? 0),
              validityDayText: entry.validityDayText ? String(entry.validityDayText) : undefined,
              category: String(
                entry.categoryCode || entry.type || entry.category || entry.group || 'DATA'
              ).toUpperCase(),
            });
          }
        });
      }

      setPacks(mapped);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to fetch exchange packs');
    } finally {
      setLoading(false);
    }
  }, [account.accessToken, account.phone]);

  useEffect(() => {
    loadPacks();
  }, [loadPacks]);

  const filtered = packs.filter((p) => {
    const c = (p.category || '').toUpperCase();
    if (category === 'SUPER') return c.includes('SUPER') || c.includes('COMBO');
    return c.includes(category) || (category === 'DATA' && !c);
  });

  const handleConfirmExchange = async () => {
    if (!selectedPack) return;
    setExchanging(true);
    setFeedback('');
    setErrorMsg('');
    try {
      const res = await mytelApi.exchangePack(
        account.accessToken,
        account.phone,
        selectedPack.rewardCode
      );
      // APK PointsExchangeActivity$2: success requires errorCode === "00000"
      if (String(res?.errorCode) !== '00000') {
        throw new Error(res?.message || 'Exchange failed');
      }
      setFeedback(
        res?.message ||
          `${selectedPack.pointAmount.toLocaleString()} pts ဖြင့် ${selectedPack.rewardName} လဲလှယ်ပြီးပါပြီ!`
      );
      setSelectedPack(null);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Exchange failed');
      setSelectedPack(null);
    } finally {
      setExchanging(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Points Exchange"
        subtitle="Mytel Loyalty Rewards"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={loadPacks}
            disabled={loading}
            aria-label="Refresh reward packs"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Category Segmented Tabs (Scrollable on narrow Android screens) */}
      <div className="overflow-x-auto no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
        <div className="inline-flex items-center gap-1 rounded-xl border border-white/[0.08] bg-[#141820] p-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategory(cat)}
              className={`min-h-[42px] px-4 sm:px-5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 active:scale-95 ${
                category === cat
                  ? 'bg-[#C8942A] text-[#0C0F14]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {feedback && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs font-medium text-[#81C784]">
          {feedback}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-24 rounded-2xl border border-white/[0.06] bg-[#141820] animate-pulse"
            />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-10 text-center text-sm text-slate-400">
          {category} အမျိုးအစားအတွက် Pack မရှိသေးပါ။
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filtered.map((pack, idx) => (
            <div
              key={`${pack.category}-${pack.rewardCode}-${idx}`}
              className="rounded-2xl border border-white/[0.08] bg-[#141820] p-4 sm:p-5 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <div className="h-11 w-11 rounded-xl bg-[#1A1F2A] border border-white/[0.06] flex items-center justify-center shrink-0">
                  <img
                    src={category === 'DATA' ? KONG_ASSETS.icPrizeMb : KONG_ASSETS.icLoyalPoint}
                    alt=""
                    className="h-7 w-7 object-contain"
                  />
                </div>
                <div className="min-w-0 space-y-1">
                  <p className="text-base font-semibold text-white truncate">{pack.rewardName}</p>
                  <p className="text-xs text-slate-400 font-mono-num">
                    <span className="text-[#E8B040] font-semibold">
                      {pack.pointAmount.toLocaleString()} pts
                    </span>
                    {pack.validityDayText ? ` · ${pack.validityDayText}` : ''}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPack(pack)}
                className="min-h-[44px] shrink-0 rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] hover:brightness-105 active:scale-95 transition-all whitespace-nowrap"
              >
                Exchange
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Confirm Exchange Bottom Sheet / Modal */}
      {selectedPack && (
        <div
          onClick={() => setSelectedPack(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-5 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <h3 className="font-display text-lg font-bold text-white">Confirm Exchange</h3>

            <div className="rounded-xl border border-white/[0.08] bg-[#1C212C] p-4 flex items-center justify-between gap-4">
              <div>
                <p className="text-xs text-slate-400">Points</p>
                <p className="font-mono-num text-lg font-bold text-[#E8B040]">
                  {selectedPack.pointAmount.toLocaleString()} pts
                </p>
              </div>
              <ArrowRight className="h-5 w-5 text-slate-500 shrink-0" />
              <div className="text-right min-w-0">
                <p className="text-xs text-slate-400">Receive</p>
                <p className="text-lg font-bold text-white truncate">{selectedPack.rewardName}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setSelectedPack(null)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 text-sm font-semibold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={exchanging}
                onClick={handleConfirmExchange}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
              >
                {exchanging && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>Exchange</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
