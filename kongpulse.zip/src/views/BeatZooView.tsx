import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  Loader2,
  Music,
  Pencil,
  Play,
  RefreshCw,
  ShoppingBag,
  Sparkles,
  Square,
  Trophy,
  Volume2,
  X,
} from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { GAME_ASSETS, getBeatZooIcon, getBeatZooSpinIcon } from '../lib/gameAssets';
import { beatzooApi } from '../lib/gamesApi';
import { KONG_ASSETS, getRankMedal } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface BeatZooViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onBack: () => void;
}

type BeatTab = 'play' | 'missions' | 'spin' | 'shop' | 'rank';

const WHEEL_COLORS = ['#B88422', '#1A1F29', '#8E5C15', '#232A36', '#C8942A', '#151A22'];

function extractArray(res: any, keys: string[]): any[] {
  const candidates = [res?.data, res?.result, res];
  for (const c of candidates) {
    if (Array.isArray(c)) return c;
    if (c && typeof c === 'object') {
      for (const k of keys) {
        if (Array.isArray(c[k])) return c[k];
      }
    }
  }
  return [];
}

function flattenBeatZooShop(res: any): any[] {
  const groups = extractArray(res, ['items', 'packages', 'list']);
  const out: any[] = [];
  for (const g of groups) {
    if (Array.isArray(g?.items)) {
      for (const it of g.items) {
        out.push({ ...it, groupName: g.name || g.id || '' });
      }
    } else if (g && typeof g === 'object') {
      out.push(g);
    }
  }
  return out;
}

export function BeatZooView({ account, onAccountUpdated, onBack }: BeatZooViewProps) {
  const [jwt, setJwt] = useState(account.beatzooToken || '');
  const [tab, setTab] = useState<BeatTab>('play');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  // Profile & Balances
  const [playerName, setPlayerName] = useState(account.fullName || account.phone);
  const [tickets, setTickets] = useState(0);
  const [hearts, setHearts] = useState(0);
  const [gems, setGems] = useState(0);

  // Songs & Gameplay
  const [songs, setSongs] = useState<any[]>([]);
  const [mode, setMode] = useState<'easy' | 'hard'>('easy');
  const [targetScore, setTargetScore] = useState(12500);
  const [playingSong, setPlayingSong] = useState<any | null>(null);
  const [playProgress, setPlayProgress] = useState(0);
  const [autoLoop, setAutoLoop] = useState(false);
  const [buyingSongId, setBuyingSongId] = useState<string | number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const autoStopRef = useRef(false);

  // Missions
  const [missions, setMissions] = useState<any[]>([]);
  const [claimingMissionId, setClaimingMissionId] = useState<string | number | null>(null);

  // Shop
  const [shopKind, setShopKind] = useState<'internal' | 'external'>('internal');
  const [shopItems, setShopItems] = useState<any[]>([]);
  const [buyingShopCode, setBuyingShopCode] = useState<string | null>(null);

  // Lucky Wheel
  const [wheelPrizes, setWheelPrizes] = useState<any[]>([]);
  const [spinning, setSpinning] = useState(false);
  const [wheelDeg, setWheelDeg] = useState(0);
  const [spinResult, setSpinResult] = useState<any | null>(null);
  const wheelDegRef = useRef(0);

  // Leaderboard
  const [rankPeriod, setRankPeriod] = useState<'weekly' | 'monthly' | 'overall'>('weekly');
  const [rankRows, setRankRows] = useState<any[]>([]);

  // Rename Modal
  const [editNameOpen, setEditNameOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [savingName, setSavingName] = useState(false);

  const ensureSession = useCallback(
    async (force = false): Promise<string> => {
      if (!force && jwt) return jwt;
      const res = await beatzooApi.login({
        thirdPartyToken: account.thirdPartyToken,
        mcuid: account.mcuid || account.phone,
        phone: account.phone,
        avatar: account.avatarUrl,
        fullName: account.fullName,
      });
      const tok =
        res?.data?.token ||
        res?.data?.accessToken ||
        res?.token ||
        res?.accessToken ||
        '';
      if (!tok) {
        throw new Error(res?.message || 'Beat Zoo login did not return token');
      }
      setJwt(tok);
      const updated = updateActiveAccount({ beatzooToken: tok });
      if (updated) onAccountUpdated(updated);
      return tok;
    },
    [account.avatarUrl, account.fullName, account.mcuid, account.phone, account.thirdPartyToken, jwt, onAccountUpdated]
  );

  const loadBalancesAndSongs = useCallback(
    async (token: string) => {
      const [balRes, songsRes, ticketRes, heartRes, gemRes] = await Promise.allSettled([
        beatzooApi.getBalance(token),
        beatzooApi.getTopSongs(token),
        beatzooApi.getCurrency(token, 'ticket'),
        beatzooApi.getCurrency(token, 'heart'),
        beatzooApi.getCurrency(token, 'gem'),
      ]);

      let nextTicket = 0;
      let nextHeart = 0;
      let nextGem = 0;

      if (balRes.status === 'fulfilled') {
        const b = balRes.value?.data || balRes.value;
        if (b?.name || b?.player_name || b?.username) {
          setPlayerName(String(b.name || b.player_name || b.username));
        }
        nextTicket = Number(b?.ticket ?? b?.tickets ?? 0);
        nextHeart = Number(b?.heart ?? b?.hearts ?? 0);
        nextGem = Number(b?.gem ?? b?.gems ?? 0);
      }
      if (ticketRes.status === 'fulfilled') {
        const v = ticketRes.value?.data?.balance ?? ticketRes.value?.data?.amount ?? ticketRes.value?.balance;
        if (v !== undefined) nextTicket = Number(v);
      }
      if (heartRes.status === 'fulfilled') {
        const v = heartRes.value?.data?.balance ?? heartRes.value?.data?.amount ?? heartRes.value?.balance;
        if (v !== undefined) nextHeart = Number(v);
      }
      if (gemRes.status === 'fulfilled') {
        const v = gemRes.value?.data?.balance ?? gemRes.value?.data?.amount ?? gemRes.value?.balance;
        if (v !== undefined) nextGem = Number(v);
      }

      setTickets(nextTicket);
      setHearts(nextHeart);
      setGems(nextGem);

      if (songsRes.status === 'fulfilled') {
        setSongs(extractArray(songsRes.value, ['songs', 'list', 'items']));
      }
    },
    []
  );

  const bootstrap = useCallback(
    async (forceLogin = false) => {
      setLoading(true);
      setErrorMsg('');
      try {
        let tok = await ensureSession(forceLogin);
        try {
          await loadBalancesAndSongs(tok);
        } catch (err) {
          if (err instanceof Error && err.message.includes('401')) {
            tok = await ensureSession(true);
            await loadBalancesAndSongs(tok);
          } else {
            throw err;
          }
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to connect to Beat Zoo');
      } finally {
        setLoading(false);
      }
    },
    [ensureSession, loadBalancesAndSongs]
  );

  useEffect(() => {
    bootstrap(false);
    return () => {
      autoStopRef.current = true;
      audioRef.current?.pause();
    };
  }, [account.phone]);

  useEffect(() => {
    if (!jwt) return;
    if (tab === 'missions') {
      beatzooApi
        .getMissions(jwt)
        .then((res) => setMissions(extractArray(res, ['missions', 'list', 'items'])))
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load missions'));
    } else if (tab === 'spin') {
      beatzooApi
        .getSpinPrizes(jwt)
        .then((res) => setWheelPrizes(extractArray(res, ['prizes', 'luckySpin', 'items', 'list'])))
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load wheel'));
    } else if (tab === 'shop') {
      beatzooApi
        .getShopItems(jwt, shopKind)
        .then((res) => setShopItems(flattenBeatZooShop(res)))
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load shop'));
    } else if (tab === 'rank') {
      beatzooApi
        .getLeaderboard(jwt, rankPeriod)
        .then((res) => setRankRows(extractArray(res, ['ranks', 'leaderboard', 'list', 'users'])))
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load leaderboard'));
    }
  }, [tab, jwt, shopKind, rankPeriod]);

  const stopSongPlay = () => {
    autoStopRef.current = true;
    audioRef.current?.pause();
    setPlayingSong(null);
    setPlayProgress(0);
  };

  const playSongRound = async (song: any) => {
    if (!jwt) return;
    autoStopRef.current = false;
    setErrorMsg('');
    setStatusMsg('');

    const runOne = async (): Promise<boolean> => {
      const startRes = await beatzooApi.startGamePlay(jwt, song.id);
      if (startRes?.success === false) {
        throw new Error(startRes?.message || 'Unable to start song');
      }
      setPlayingSong(song);
      setPlayProgress(0);

      const audioPath = song.audio || song.file || song.url || '';
      if (audioPath && audioRef.current) {
        const fullAudio = String(audioPath).startsWith('http')
          ? String(audioPath)
          : `https://beatzoo.mascom.vn/songs/${String(audioPath).replace(/^\/+/, '')}`;
        audioRef.current.src = fullAudio;
        audioRef.current.play().catch(() => {});
      }

      const steps = 12;
      for (let i = 1; i <= steps; i++) {
        if (autoStopRef.current) {
          audioRef.current?.pause();
          setPlayingSong(null);
          return false;
        }
        setPlayProgress(Math.round((i / steps) * 100));
        await new Promise((r) => window.setTimeout(r, 800));
      }
      audioRef.current?.pause();

      const scoreRes = await beatzooApi.saveScore(jwt, song.id, targetScore, mode);
      if (scoreRes?.success === false) {
        throw new Error(scoreRes?.message || 'Failed to save Beat Zoo score');
      }
      setStatusMsg(`${song.name || song.title} — Score ${targetScore.toLocaleString()} saved!`);
      await loadBalancesAndSongs(jwt);
      return true;
    };

    try {
      do {
        const ok = await runOne();
        if (!ok || !autoLoop) break;
        await new Promise((r) => window.setTimeout(r, 400));
      } while (!autoStopRef.current && autoLoop);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Song playback failed');
    } finally {
      setPlayingSong(null);
      setPlayProgress(0);
    }
  };

  const handleBuySong = async (song: any) => {
    if (!jwt) return;
    setBuyingSongId(song.id);
    setErrorMsg('');
    try {
      const res = await beatzooApi.buySong(jwt, song.id);
      if (res?.success === false) throw new Error(res?.message || 'Unlock failed');
      setStatusMsg(`Unlocked "${song.name || song.title}"`);
      await loadBalancesAndSongs(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Song unlock failed');
    } finally {
      setBuyingSongId(null);
    }
  };

  const handleClaimMission = async (mission: any) => {
    if (!jwt) return;
    const id = mission.id ?? mission.mission_id;
    setClaimingMissionId(id);
    setErrorMsg('');
    try {
      const res = await beatzooApi.claimMission(jwt, id);
      if (res?.success === false) throw new Error(res?.message || 'Claim failed');
      setStatusMsg(res?.message || 'Mission reward claimed!');
      const [mRes] = await Promise.all([
        beatzooApi.getMissions(jwt),
        loadBalancesAndSongs(jwt),
      ]);
      setMissions(extractArray(mRes, ['missions', 'list', 'items']));
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Mission claim failed');
    } finally {
      setClaimingMissionId(null);
    }
  };

  const handleSpinWheel = async () => {
    if (!jwt || spinning) return;
    setSpinning(true);
    setErrorMsg('');
    try {
      const res = await beatzooApi.spinWheel(jwt);
      if (res?.success === false) throw new Error(res?.message || 'Spin failed');
      const prize = res?.data || res?.prize || res;
      const prizeId = prize?.id ?? prize?.prize_id;
      let idx = wheelPrizes.findIndex((p) => (p.id ?? p.prize_id) === prizeId);
      if (idx < 0) idx = 0;

      const count = Math.max(1, wheelPrizes.length);
      const sliceDeg = 360 / count;
      const center = idx * sliceDeg + sliceDeg / 2;
      const base = wheelDegRef.current - (wheelDegRef.current % 360);
      const nextAngle = base + 360 * 5 + (360 - center);
      wheelDegRef.current = nextAngle;
      setWheelDeg(nextAngle);

      await new Promise((r) => window.setTimeout(r, 2500));
      setSpinResult(prize);
      await loadBalancesAndSongs(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Spin failed');
    } finally {
      setSpinning(false);
    }
  };

  const handleBuyShop = async (item: any) => {
    if (!jwt) return;
    const code = String(item.code || item.item_code || item.id);
    setBuyingShopCode(code);
    setErrorMsg('');
    try {
      const res =
        shopKind === 'internal'
          ? await beatzooApi.buyInternalItem(jwt, code)
          : await beatzooApi.buyPaymentPackage(jwt, code);
      if (res?.success === false) throw new Error(res?.message || 'Purchase failed');
      setStatusMsg(res?.message || `Purchased ${item.name || code}`);
      await loadBalancesAndSongs(jwt);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Purchase failed');
    } finally {
      setBuyingShopCode(null);
    }
  };

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!jwt || !nameDraft.trim()) return;
    setSavingName(true);
    setErrorMsg('');
    try {
      const res = await beatzooApi.updateName(jwt, nameDraft.trim());
      if (res?.success === false) throw new Error(res?.message || 'Rename failed');
      setPlayerName(nameDraft.trim());
      setEditNameOpen(false);
      setStatusMsg('Player name updated');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Rename failed');
    } finally {
      setSavingName(false);
    }
  };

  const wheelCount = Math.max(1, wheelPrizes.length);
  const wheelSlice = 360 / wheelCount;

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <audio ref={audioRef} className="hidden" />
      <PageBackHeader
        title="Beat Zoo"
        subtitle="Rhythm Auto-Player · Missions · Lucky Wheel · Shop"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => bootstrap(true)}
            disabled={loading}
            aria-label="Sync Beat Zoo"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Profile + 3-Currency Strip */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <img
              src={GAME_ASSETS.beatZooLogo}
              alt="Beat Zoo"
              className="h-12 w-12 rounded-2xl border border-[#C8942A]/40 object-cover shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
                  {playerName}
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    setNameDraft(playerName);
                    setEditNameOpen(true);
                  }}
                  aria-label="Edit Beat Zoo player name"
                  className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-[#E8B040]"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="text-xs font-mono-num text-slate-400">{account.phone}</p>
            </div>
          </div>
          {playingSong && (
            <button
              type="button"
              onClick={stopSongPlay}
              className="min-h-[40px] rounded-xl bg-red-600 px-3.5 py-2 text-xs font-bold text-white flex items-center gap-1.5"
            >
              <Square className="h-3.5 w-3.5 fill-current" />
              <span>Stop</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2.5 sm:gap-3 pt-2 border-t border-white/[0.06]">
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icBeatTicket} alt="Ticket" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Tickets</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-white truncate">
                {loading ? '--' : tickets.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icBeatHeart} alt="Heart" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Hearts</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-rose-400 truncate">
                {loading ? '--' : hearts.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icBeatGem} alt="Gem" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Gems</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-[#E8B040] truncate">
                {loading ? '--' : gems.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Android Tab Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {[
          { id: 'play', label: 'Songs', icon: Music },
          { id: 'missions', label: 'Missions', icon: Check },
          { id: 'spin', label: 'Lucky Wheel', icon: Sparkles },
          { id: 'shop', label: 'Shop', icon: ShoppingBag },
          { id: 'rank', label: 'Rank', icon: Trophy },
        ].map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as BeatTab)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 flex items-center gap-2 border transition-all ${
                active
                  ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                  : 'border-white/10 bg-[#161920] text-slate-300 hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusMsg}</span>
          <button type="button" onClick={() => setStatusMsg('')} className="text-xs underline">
            OK
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button type="button" onClick={() => setErrorMsg('')} className="text-xs underline">
            Close
          </button>
        </div>
      )}

      {/* TAB 1: SONGS & AUTO PLAY */}
      {tab === 'play' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-400">Difficulty</span>
              <div className="inline-flex rounded-xl border border-white/10 bg-[#12151B] p-1">
                {(['easy', 'hard'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={`min-h-[36px] px-3.5 rounded-lg text-xs font-bold uppercase ${
                      mode === m ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Score:</span>
                <input
                  type="number"
                  value={targetScore}
                  onChange={(e) => setTargetScore(Math.max(100, Number(e.target.value) || 0))}
                  className="w-24 min-h-[38px] rounded-xl border border-white/10 bg-[#12151B] px-3 text-xs font-mono-num text-white focus:border-[#C8942A] focus:outline-none"
                />
              </div>

              <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                <span>Loop</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={autoLoop}
                  onClick={() => setAutoLoop((v) => !v)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    autoLoop ? 'bg-[#4CAF50]' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      autoLoop ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </label>
            </div>
          </div>

          {playingSong && (
            <div className="rounded-2xl border border-[#C8942A]/40 bg-[#1A1812] p-4 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[#E8B040] flex items-center gap-2">
                  <Volume2 className="h-4 w-4 animate-pulse" />
                  Playing: {playingSong.name || playingSong.title}
                </span>
                <span className="font-mono-num font-bold text-white">{playProgress}%</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#12151B] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all"
                  style={{ width: `${playProgress}%` }}
                />
              </div>
            </div>
          )}

          {loading ? (
            <div className="py-12 flex justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-[#E8B040]" />
            </div>
          ) : songs.length === 0 ? (
            <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-8 text-center text-sm text-slate-400">
              No Beat Zoo songs returned for this session.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {songs.map((song, idx) => {
                const owned =
                  song.is_owned === true ||
                  song.owned === true ||
                  Number(song.price ?? 0) === 0 ||
                  song.status === 'OWNED';
                const songKey = song.id ?? idx;
                return (
                  <div
                    key={`song-${songKey}-${idx}`}
                    className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-12 w-12 rounded-xl bg-[#12151B] border border-white/[0.06] flex items-center justify-center shrink-0">
                        <img
                          src={GAME_ASSETS.icBeatZoo}
                          alt=""
                          className="h-8 w-8 object-contain"
                        />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {song.name || song.title || `Track #${idx + 1}`}
                        </p>
                        <p className="text-xs text-slate-400 truncate mt-0.5">
                          {song.artist || 'Beat Zoo Artist'} ·{' '}
                          <span className="font-mono-num">
                            {song.bpm ? `${song.bpm} BPM` : mode.toUpperCase()}
                          </span>
                        </p>
                      </div>
                    </div>

                    {owned ? (
                      <button
                        type="button"
                        disabled={Boolean(playingSong)}
                        onClick={() => playSongRound(song)}
                        className="min-h-[44px] shrink-0 rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] disabled:opacity-50 active:scale-95 transition-all flex items-center gap-1.5"
                      >
                        <Play className="h-3.5 w-3.5 fill-current" />
                        <span>Play</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={buyingSongId === song.id}
                        onClick={() => handleBuySong(song)}
                        className="min-h-[44px] shrink-0 rounded-xl border border-[#C8942A]/40 bg-[#C8942A]/15 px-3.5 py-2 text-xs font-bold text-[#E8B040] active:scale-95 transition-all font-mono-num"
                      >
                        {buyingSongId === song.id
                          ? '...'
                          : `Unlock ${Number(song.price || 0).toLocaleString()}`}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MISSIONS */}
      {tab === 'missions' && (
        <div className="space-y-3">
          {missions.length === 0 ? (
            <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-8 text-center text-sm text-slate-400">
              No missions available.
            </div>
          ) : (
            missions.map((m, idx) => {
              const id = m.id ?? m.mission_id ?? idx;
              const rewardType = String(m.reward_type || m.rewardType || 'GEM');
              const claimed = m.is_claimed === true || m.status === 'CLAIMED';
              const ready = m.can_claim === true || m.status === 'READY' || (!claimed && Number(m.progress ?? 0) >= Number(m.target ?? 1));
              return (
                <div
                  key={`bz-mission-${id}-${idx}`}
                  className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <img
                      src={getBeatZooIcon(rewardType)}
                      alt={rewardType}
                      className="h-10 w-10 object-contain shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">
                        {m.title || m.name || 'Beat Mission'}
                      </p>
                      <p className="text-xs text-slate-400 font-mono-num mt-0.5">
                        +{Number(m.reward_value ?? m.reward ?? 1).toLocaleString()} {rewardType} ·{' '}
                        {Number(m.progress ?? 0)}/{Number(m.target ?? 1)}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={claimed || !ready || claimingMissionId === id}
                    onClick={() => handleClaimMission(m)}
                    className={`min-h-[44px] shrink-0 rounded-xl px-4 text-xs font-bold ${
                      claimed
                        ? 'border border-white/10 bg-[#12151B] text-slate-500'
                        : ready
                        ? 'bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-[#0C0F14]'
                        : 'border border-white/10 bg-[#12151B] text-slate-400'
                    }`}
                  >
                    {claimingMissionId === id ? '...' : claimed ? 'Claimed' : 'Claim'}
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 3: LUCKY WHEEL */}
      {tab === 'spin' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 sm:p-7 flex flex-col items-center gap-6">
          <div className="relative flex flex-col items-center">
            <div className="z-20 -mb-3 h-0 w-0 border-x-[12px] border-x-transparent border-t-[20px] border-t-[#E8B040]" />
            <div className="p-2 rounded-full bg-gradient-to-b from-[#E8B040] to-[#7A5410]">
              <div
                className="relative h-68 w-68 sm:h-80 sm:w-80 rounded-full bg-[#0C0F14] overflow-hidden transition-transform duration-[2500ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
                style={{ transform: `rotate(${wheelDeg}deg)` }}
              >
                <svg viewBox="0 0 200 200" className="h-full w-full">
                  <circle cx="100" cy="100" r="98" fill="#12161E" stroke="#C8942A" strokeWidth="2" />
                  {wheelPrizes.map((p, i) => {
                    const start = (i * wheelSlice - 90) * (Math.PI / 180);
                    const end = ((i + 1) * wheelSlice - 90) * (Math.PI / 180);
                    const r = 90;
                    const x1 = 100 + r * Math.cos(start);
                    const y1 = 100 + r * Math.sin(start);
                    const x2 = 100 + r * Math.cos(end);
                    const y2 = 100 + r * Math.sin(end);
                    const largeArc = wheelSlice > 180 ? 1 : 0;
                    const mid = ((i + 0.5) * wheelSlice - 90) * (Math.PI / 180);
                    const rotDeg = (i + 0.5) * wheelSlice;
                    const ix = 100 + 62 * Math.cos(mid);
                    const iy = 100 + 62 * Math.sin(mid);
                    const iconKey =
                      p.rewards?.[0]?.currency_code || p.type || p.code || p.name || '';
                    const icon = getBeatZooSpinIcon(String(iconKey));
                    return (
                      <g key={`bz-seg-${p.id ?? i}-${i}`}>
                        <path
                          d={`M100,100 L${x1},${y1} A${r},${r} 0 ${largeArc},1 ${x2},${y2} Z`}
                          fill={WHEEL_COLORS[i % WHEEL_COLORS.length]}
                          stroke="#0B0E14"
                          strokeWidth="1.2"
                        />
                        <g transform={`rotate(${rotDeg}, ${ix}, ${iy})`}>
                          <image
                            href={icon}
                            x={ix - 10}
                            y={iy - 10}
                            width="20"
                            height="20"
                            preserveAspectRatio="xMidYMid meet"
                          />
                        </g>
                      </g>
                    );
                  })}
                  <circle cx="100" cy="100" r="18" fill="#0C0F14" stroke="#E8B040" strokeWidth="2.5" />
                  <image href={GAME_ASSETS.icBeatZoo} x="87" y="87" width="26" height="26" />
                </svg>
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={spinning}
            onClick={handleSpinWheel}
            className="w-full max-w-xs min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {spinning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            <span>{spinning ? 'Spinning...' : 'SPIN BEAT WHEEL'}</span>
          </button>

          {wheelPrizes.length > 0 && (
            <div className="w-full grid grid-cols-2 sm:grid-cols-3 gap-2 pt-3 border-t border-white/[0.06]">
              {wheelPrizes.map((p, i) => {
                const iconKey =
                  p.rewards?.[0]?.currency_code || p.type || p.code || p.name || '';
                return (
                  <div
                    key={`bz-prize-${p.id ?? i}-${i}`}
                    className="rounded-xl border border-white/[0.06] bg-[#12151B] px-3 py-2 flex items-center gap-2.5"
                  >
                    <img
                      src={getBeatZooSpinIcon(String(iconKey))}
                      alt=""
                      className="h-6 w-6 object-contain shrink-0"
                    />
                    <span className="text-xs text-slate-200 truncate">
                      {p.name || p.description || `${p.value ?? ''} ${p.type ?? ''}`}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SHOP */}
      {tab === 'shop' && (
        <div className="space-y-4">
          <div className="inline-flex rounded-xl border border-white/10 bg-[#141820] p-1">
            {(['internal', 'external'] as const).map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => setShopKind(k)}
                className={`min-h-[40px] px-4 rounded-lg text-xs font-semibold capitalize ${
                  shopKind === k ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                }`}
              >
                {k === 'internal' ? 'In-Game Shop' : 'Telecom Packages'}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {shopItems.map((item, idx) => {
              const code = String(item.code || item.item_code || item.id || idx);
              return (
                <div
                  key={`bz-shop-${code}-${idx}`}
                  className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex flex-col justify-between gap-4"
                >
                  <div className="flex items-start gap-3">
                    <img
                      src={getBeatZooIcon(item.name || code)}
                      alt={item.name || code}
                      className="h-11 w-11 object-contain shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">
                        {item.name || code}
                      </p>
                      <p className="text-xs text-[#E8B040] font-mono-num font-bold mt-1">
                        {Number(item.price ?? 0).toLocaleString()} {item.currency || (shopKind === 'external' ? 'Ks' : 'Gems')}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={buyingShopCode === code}
                    onClick={() => handleBuyShop(item)}
                    className="w-full min-h-[44px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14] disabled:opacity-50"
                  >
                    {buyingShopCode === code ? 'Processing...' : 'Buy Now'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 5: LEADERBOARD */}
      {tab === 'rank' && (
        <div className="space-y-3">
          <div className="inline-flex rounded-xl border border-white/10 bg-[#141820] p-1">
            {(['weekly', 'monthly', 'overall'] as const).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setRankPeriod(p)}
                className={`min-h-[40px] px-4 rounded-lg text-xs font-semibold capitalize ${
                  rankPeriod === p ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
            {rankRows.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-400">No ranking entries yet.</div>
            ) : (
              rankRows.map((row, idx) => {
                const rankNum = Number(row.rank ?? row.order ?? idx + 1);
                const medal = getRankMedal(rankNum);
                return (
                  <div
                    key={`bz-rank-${rankNum}-${idx}`}
                    className="px-4 py-3.5 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {medal ? (
                        <img src={medal} alt={`#${rankNum}`} className="h-6 w-6 object-contain shrink-0" />
                      ) : (
                        <span className="w-6 text-center font-mono-num text-xs font-bold text-slate-400">
                          #{rankNum}
                        </span>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {row.name || row.player_name || row.msisdn || 'Player'}
                        </p>
                        {row.msisdn && (
                          <p className="text-xs font-mono-num text-slate-400">{row.msisdn}</p>
                        )}
                      </div>
                    </div>
                    <span className="font-mono-num text-sm font-bold text-[#E8B040]">
                      {Number(row.score ?? row.total_score ?? 0).toLocaleString()}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Spin Result Sheet */}
      {spinResult && (
        <div
          onClick={() => setSpinResult(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb text-center space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto" />
            <img
              src={getBeatZooSpinIcon(String(spinResult.type || spinResult.name || ''))}
              alt=""
              className="h-16 w-16 object-contain mx-auto"
            />
            <h3 className="font-display text-lg font-bold text-white">Wheel Prize</h3>
            <p className="font-mono-num text-base font-bold text-[#E8B040]">
              {spinResult.name || spinResult.description || 'Reward Claimed'}
            </p>
            <button
              type="button"
              onClick={() => setSpinResult(null)}
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14]"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {editNameOpen && (
        <div
          onClick={() => setEditNameOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={handleSaveName}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Beat Zoo Name</h3>
              <button
                type="button"
                onClick={() => setEditNameOpen(false)}
                className="h-9 w-9 rounded-lg flex items-center justify-center text-slate-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <input
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              className="w-full min-h-[48px] rounded-xl border border-white/10 bg-[#12151B] px-4 text-sm text-white focus:border-[#C8942A] focus:outline-none"
            />
            <button
              type="submit"
              disabled={savingName}
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14]"
            >
              {savingName ? 'Saving...' : 'Save Name'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
