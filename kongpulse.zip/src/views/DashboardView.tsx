import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Camera,
  Check,
  ChevronRight,
  Coins,
  Copy,
  Gift,
  LogOut,
  Package,
  Pencil,
  RefreshCw,
  Settings,
  Star,
  User,
  X,
} from 'lucide-react';
import { useKongRunner } from '../context/KongRunnerContext';
import { mytelApi } from '../lib/api';
import { GAME_ASSETS } from '../lib/gameAssets';
import { KONG_ASSETS } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { AccountBalances, AppRoute, LoyaltyUsage, SavedAccount } from '../types';

interface DashboardViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onNavigate: (route: AppRoute) => void;
  onOpenPointsSheet: () => void;
  onOpenExtendModal: () => void;
  onLogout: () => void;
}

function rankStarColor(rank: string): string {
  const r = rank.toLowerCase();
  if (r.includes('diamond')) return 'text-sky-400';
  if (r.includes('platinum')) return 'text-slate-200';
  if (r.includes('ruby')) return 'text-rose-400';
  if (r.includes('gold')) return 'text-[#E8B040]';
  if (r.includes('silver')) return 'text-slate-400';
  if (r.includes('swarovski')) return 'text-purple-300';
  return 'text-[#C8942A]';
}

function formatDataBalance(rawAmount: number, unit?: string): string {
  const u = (unit || 'MB').toUpperCase();
  if (u === 'GB') return `${rawAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })} GB`;
  if (rawAmount >= 1024) return `${(rawAmount / 1024).toFixed(2)} GB`;
  return `${rawAmount.toLocaleString()} ${unit || 'MB'}`;
}

export function DashboardView({
  account,
  onAccountUpdated,
  onNavigate,
  onOpenPointsSheet,
  onOpenExtendModal,
  onLogout,
}: DashboardViewProps) {
  const kong = useKongRunner();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [balances, setBalances] = useState<AccountBalances>({
    mainBalance: '-- Ks',
    dataText: '-- MB',
    voiceText: '-- Min',
    points: 0,
    rawPoints: 0,
  });
  const [usage, setUsage] = useState<LoyaltyUsage>({
    rankName: 'Welcome',
    used: 0,
    limit: 10000,
    canExtend: false,
  });
  const [errorBanner, setErrorBanner] = useState('');
  const [statusBanner, setStatusBanner] = useState('');

  // Edit Name Modal
  const [editNameOpen, setEditNameOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState(account.fullName || '');
  const [savingName, setSavingName] = useState(false);

  // Logout Confirm Modal
  const [logoutOpen, setLogoutOpen] = useState(false);

  // Avatar Upload
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  const loadDashboard = useCallback(
    async (isManual = false) => {
      if (isManual) setRefreshing(true);
      else setLoading(true);
      setErrorBanner('');

      try {
        const [custRes, detailRes, loyaltyCsmRes, inquiryRes] = await Promise.allSettled([
          mytelApi.getCustomer(account.accessToken),
          mytelApi.getAccountDetail(account.accessToken, account.phone),
          mytelApi.getLoyaltyCsm(account.accessToken, account.phone),
          mytelApi.getLoyaltyInquiry(account.accessToken, account.phone),
        ]);

        // 1. Customer Profile
        if (custRes.status === 'fulfilled') {
          const cust = custRes.value?.result || custRes.value;
          const nextName = cust?.fullName ? String(cust.fullName) : account.fullName;
          let nextAvatar = account.avatarUrl;
          if (Array.isArray(cust?.externalRefs)) {
            const av = cust.externalRefs.find((r: any) => r?.type === 'avatar_img');
            if (av?.href) nextAvatar = String(av.href);
          }
          if (nextName !== account.fullName || nextAvatar !== account.avatarUrl) {
            const updated = updateActiveAccount({ fullName: nextName, avatarUrl: nextAvatar });
            if (updated) onAccountUpdated(updated);
          }
        }

        // 2. Account Detail (DashboardActivity$6: res.result is a JSONArray!)
        let mainBalance = '-- Ks';
        let dataText = '-- MB';
        let voiceText = '-- Min';
        let points = 0;

        if (detailRes.status === 'fulfilled') {
          const rawResult = detailRes.value?.result;
          const detailItem = Array.isArray(rawResult)
            ? rawResult.find((item: any) => item?.mytel === true) || rawResult[0]
            : rawResult || detailRes.value;

          if (detailItem) {
            const mbObj = detailItem.mainBalance;
            if (mbObj && typeof mbObj === 'object') {
              if (mbObj.main && typeof mbObj.main === 'object') {
                const amt = Number(mbObj.main.amount ?? 0);
                const unit = String(mbObj.main.unit || 'Ks');
                mainBalance = `${amt.toLocaleString()} ${unit}`;
              } else if (typeof mbObj.main === 'number' || typeof mbObj.main === 'string') {
                mainBalance = `${Number(mbObj.main).toLocaleString()} Ks`;
              }

              if (mbObj.data && typeof mbObj.data === 'object') {
                const amt = Number(mbObj.data.amount ?? 0);
                const unit = String(mbObj.data.unit || 'MB');
                dataText = formatDataBalance(amt, unit);
              } else if (typeof mbObj.data === 'number' || typeof mbObj.data === 'string') {
                dataText = formatDataBalance(Number(mbObj.data), 'MB');
              }

              if (mbObj.voice && typeof mbObj.voice === 'object') {
                const amt = Number(mbObj.voice.amount ?? 0);
                const unit = String(mbObj.voice.unit || 'Min');
                voiceText = `${amt.toLocaleString()} ${unit}`;
              } else if (typeof mbObj.voice === 'number' || typeof mbObj.voice === 'string') {
                voiceText = `${Number(mbObj.voice).toLocaleString()} Min`;
              }
            } else {
              if (detailItem.mainBalance !== undefined) {
                mainBalance = `${Number(detailItem.mainBalance).toLocaleString()} Ks`;
              } else if (detailItem.main !== undefined) {
                mainBalance = `${Number(detailItem.main).toLocaleString()} Ks`;
              }
              if (detailItem.data !== undefined) {
                dataText = formatDataBalance(Number(detailItem.data), 'MB');
              }
              if (detailItem.voice !== undefined) {
                voiceText = `${Number(detailItem.voice).toLocaleString()} Min`;
              }
            }
          }
        }

        // 3. Loyalty CSM (DashboardActivity$5: result.name + result.balances[].TELCO_EXCHANGEABLE_POINTS)
        let csmRank = '';
        if (loyaltyCsmRes.status === 'fulfilled') {
          const r = loyaltyCsmRes.value?.result || loyaltyCsmRes.value;
          if (r?.name || r?.rankName) {
            csmRank = String(r.rankName || r.name);
          }
          if (Array.isArray(r?.balances)) {
            for (const b of r.balances) {
              const code = String(b?.loyaltyBalanceCode || b?.name || '').toUpperCase();
              if (code === 'TELCO_EXCHANGEABLE_POINTS' || code.includes('TELCO_EXCHANGEABLE_POINTS')) {
                points = Number(b?.balance ?? 0);
              }
            }
          }
        }

        // 4. Loyalty Inquiry (DashboardActivity$4: result.rankName, exchangePoints, extendInfo)
        let rankName = csmRank || 'Welcome';
        let used = 0;
        let limit = 10000;
        let canExtend = false;
        let progressText = '';

        if (inquiryRes.status === 'fulfilled') {
          const r = inquiryRes.value?.result || inquiryRes.value;
          if (r?.rankName) rankName = String(r.rankName);
          if (r?.exchangePoints !== undefined && r?.exchangePoints !== null) {
            points = Number(r.exchangePoints);
          }
          if (Array.isArray(r?.balances)) {
            for (const b of r.balances) {
              if (String(b?.loyaltyBalanceCode || '').includes('TELCO_EXCHANGEABLE_POINTS')) {
                points = Number(b?.balance ?? points);
              }
            }
          }
          if (typeof r?.progress === 'string') {
            progressText = r.progress;
          }
          const ex = r?.extendInfo;
          if (ex && typeof ex === 'object') {
            used = Number(ex.exchanged ?? 0);
            limit = Number(ex.currentLimit ?? ex.monthlyLimit ?? 10000);
            canExtend = Boolean(ex.canExtend);
          }
        }

        setBalances({
          mainBalance,
          dataText,
          voiceText,
          points,
          rawPoints: points,
        });

        setUsage({
          rankName,
          used,
          limit: limit > 0 ? limit : 10000,
          canExtend,
          progressText,
        });

        // Surface auth errors if every request rejected
        const firstRejected = [detailRes, loyaltyCsmRes, inquiryRes].find(
          (p) => p.status === 'rejected'
        ) as PromiseRejectedResult | undefined;
        if (
          firstRejected &&
          detailRes.status === 'rejected' &&
          inquiryRes.status === 'rejected'
        ) {
          const msg =
            firstRejected.reason instanceof Error
              ? firstRejected.reason.message
              : 'Unable to sync Mytel session';
          setErrorBanner(msg);
        }
      } catch (err) {
        setErrorBanner(err instanceof Error ? err.message : 'Unable to refresh account data');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [account.accessToken, account.avatarUrl, account.fullName, account.phone, onAccountUpdated]
  );

  useEffect(() => {
    loadDashboard(false);
  }, [account.phone]);

  const handleCopyPhone = async () => {
    try {
      await navigator.clipboard.writeText(account.phone);
      setCopiedPhone(true);
      window.setTimeout(() => setCopiedPhone(false), 1800);
    } catch {
      // ignore clipboard restriction
    }
  };

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = nameDraft.trim();
    if (!trimmed) return;
    setSavingName(true);
    setErrorBanner('');
    try {
      const res = await mytelApi.updateCustomer(account.accessToken, trimmed);
      const ec = res?.errorCode;
      const ok =
        Number(ec) === 0 ||
        Number(ec) === 200 ||
        res?.result === 'SUCCESSFUL' ||
        res?.success === true;
      if (!ok && ec !== undefined) {
        throw new Error(res?.message || 'Failed to update name');
      }
      const updated = updateActiveAccount({ fullName: trimmed });
      if (updated) onAccountUpdated(updated);
      setEditNameOpen(false);
      setStatusBanner('နာမည် ပြောင်းလဲပြီးပါပြီ');
      window.setTimeout(() => setStatusBanner(''), 3000);
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Failed to update name');
    } finally {
      setSavingName(false);
    }
  };

  const handleAvatarSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    setErrorBanner('');
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await mytelApi.uploadAvatar(account.accessToken, dataUrl, file.type || 'image/jpeg');
      const ec = res?.errorCode;
      if (ec !== undefined && Number(ec) !== 0 && Number(ec) !== 200) {
        throw new Error(res?.message || 'Avatar upload failed');
      }
      const newAvatar =
        res?.result?.result || res?.result?.url || (typeof res?.result === 'string' ? res.result : '');
      if (newAvatar) {
        const updated = updateActiveAccount({ avatarUrl: String(newAvatar) });
        if (updated) onAccountUpdated(updated);
      }
      await loadDashboard(true);
      setStatusBanner('ပရိုဖိုင်ပုံ အပ်ဒိတ်လုပ်ပြီးပါပြီ');
      window.setTimeout(() => setStatusBanner(''), 3000);
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Avatar upload failed');
    } finally {
      setUploadingAvatar(false);
      e.target.value = '';
    }
  };

  const usagePct = Math.min(100, Math.round((usage.used / Math.max(1, usage.limit)) * 100));

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5 sm:space-y-6">
      {statusBanner && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs font-medium text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusBanner}</span>
        </div>
      )}

      {errorBanner && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 flex items-center justify-between gap-4">
          <span>{errorBanner}</span>
          <button
            type="button"
            onClick={() => setErrorBanner('')}
            className="text-amber-300 hover:text-white shrink-0 min-h-[32px] px-2"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Top Row: Profile Card + Monthly Point Usage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch">
        {/* Profile Card */}
        <div className="lg:col-span-7 rounded-2xl border border-white/[0.08] bg-[#141820] p-5 sm:p-6 flex flex-col justify-between gap-5">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
              <div className="relative shrink-0">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingAvatar}
                  aria-label="Upload avatar"
                  className="h-16 w-16 rounded-full border-2 border-[#C8942A]/50 bg-[#1E232E] overflow-hidden flex items-center justify-center active:scale-95 transition-transform"
                >
                  {account.avatarUrl ? (
                    <img
                      src={account.avatarUrl}
                      alt={account.fullName}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <User className="h-7 w-7 text-slate-400" />
                  )}
                  <span className="absolute -bottom-0.5 -right-0.5 h-6 w-6 rounded-full bg-[#C8942A] text-[#0C0F14] flex items-center justify-center border-2 border-[#141820]">
                    <Camera className="h-3 w-3" />
                  </span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarSelected}
                  className="hidden"
                />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h1 className="font-display text-lg sm:text-xl font-bold text-white truncate">
                    {account.fullName || account.phone}
                  </h1>
                  <button
                    type="button"
                    onClick={() => {
                      setNameDraft(account.fullName || '');
                      setEditNameOpen(true);
                    }}
                    aria-label="Edit profile name"
                    className="h-9 w-9 rounded-lg text-slate-400 hover:text-[#E8B040] hover:bg-white/5 flex items-center justify-center shrink-0 transition-colors"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono-num">
                  <button
                    type="button"
                    onClick={handleCopyPhone}
                    className="inline-flex items-center gap-1.5 hover:text-white transition-colors py-0.5"
                    aria-label="Copy phone number"
                  >
                    <span>{account.phone}</span>
                    {copiedPhone ? (
                      <Check className="h-3 w-3 text-[#4CAF50]" />
                    ) : (
                      <Copy className="h-3 w-3 text-slate-500" />
                    )}
                  </button>
                  <span aria-hidden="true">·</span>
                  <span className="text-slate-300">{usage.rankName}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              <button
                type="button"
                onClick={() => loadDashboard(true)}
                disabled={refreshing}
                aria-label="Refresh balances"
                className="h-11 w-11 rounded-xl border border-white/10 bg-[#181D27] text-slate-300 hover:text-white hover:border-white/25 active:scale-95 flex items-center justify-center transition-all"
              >
                <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
              </button>
              <button
                type="button"
                onClick={() => onNavigate('accounts')}
                aria-label="Accounts & Settings"
                className="h-11 w-11 rounded-xl border border-white/10 bg-[#181D27] text-slate-300 hover:text-white hover:border-white/25 active:scale-95 flex items-center justify-center transition-all"
              >
                <Settings className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setLogoutOpen(true)}
                aria-label="Logout"
                className="h-11 w-11 rounded-xl border border-white/10 bg-[#181D27] text-slate-300 hover:text-red-400 hover:border-red-500/40 active:scale-95 flex items-center justify-center transition-all"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-4 border-t border-white/[0.06]">
            <button
              type="button"
              onClick={() => onNavigate('daily-claim')}
              className="flex items-center justify-between gap-2 min-h-[46px] rounded-xl bg-[#1B202B] border border-white/10 px-3.5 py-2.5 text-xs font-semibold text-slate-100 hover:border-[#C8942A]/50 active:scale-[0.98] transition-all"
            >
              <span className="flex items-center gap-2 truncate">
                <Gift className="h-4 w-4 text-[#E8B040] shrink-0" />
                <span className="truncate">Daily Quest</span>
              </span>
              <ChevronRight className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            </button>

            <button
              type="button"
              onClick={onOpenPointsSheet}
              className="flex items-center justify-between gap-2 min-h-[46px] rounded-xl bg-[#1B202B] border border-white/10 px-3.5 py-2.5 text-xs font-semibold text-slate-100 hover:border-[#C8942A]/50 active:scale-[0.98] transition-all"
            >
              <span className="flex items-center gap-2 truncate">
                <Coins className="h-4 w-4 text-[#E8B040] shrink-0" />
                <span className="truncate">Points Hub</span>
              </span>
              <ChevronRight className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate('data-packages')}
              className="flex items-center justify-between gap-2 min-h-[46px] rounded-xl bg-[#1B202B] border border-white/10 px-3.5 py-2.5 text-xs font-semibold text-slate-100 hover:border-[#C8942A]/50 active:scale-[0.98] transition-all"
            >
              <span className="flex items-center gap-2 truncate">
                <Package className="h-4 w-4 text-[#E8B040] shrink-0" />
                <span className="truncate">Data Packs</span>
              </span>
              <ChevronRight className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            </button>
          </div>
        </div>

        {/* Monthly Point Usage Card */}
        <div className="lg:col-span-5 rounded-2xl border border-white/[0.08] bg-[#141820] p-5 sm:p-6 flex flex-col justify-between gap-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs font-medium text-slate-400">Monthly point usage</p>
              <p className="font-mono-num text-2xl font-bold text-white mt-1">
                {loading ? '---' : `${usage.used.toLocaleString()} used`}
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
              <Star className={`h-4 w-4 fill-current ${rankStarColor(usage.rankName)}`} />
              <span>{usage.rankName}</span>
            </div>
          </div>

          <div className="space-y-2.5">
            <div className="h-2.5 w-full rounded-full bg-[#1E2430] overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all duration-500"
                style={{ width: `${usagePct}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono-num">
              <span>{usagePct}% of monthly allowance</span>
              <div className="flex items-center gap-2.5">
                <span>{usage.limit.toLocaleString()} Total</span>
                <button
                  type="button"
                  onClick={onOpenExtendModal}
                  className="text-[#E8B040] font-semibold hover:underline"
                >
                  Extend
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4-Column Balance Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-slate-400">Main Balance</p>
            <img src={KONG_ASSETS.icMmk} alt="MMK" className="h-5 w-5 object-contain" />
          </div>
          <p className="font-mono-num text-lg sm:text-2xl font-bold text-white mt-2 truncate">
            {loading ? '-- Ks' : balances.mainBalance}
          </p>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('data-packages')}
          className="rounded-2xl border border-white/[0.08] bg-[#141820] p-4 sm:p-5 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all group"
        >
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-slate-400">Data</p>
            <div className="flex items-center gap-1">
              <img src={KONG_ASSETS.icPrizeMb} alt="Data" className="h-5 w-5 rounded object-cover" />
              <ChevronRight className="h-4 w-4 text-slate-500 group-hover:text-[#E8B040] transition-colors" />
            </div>
          </div>
          <p className="font-mono-num text-lg sm:text-2xl font-bold text-white mt-2 truncate">
            {loading ? '-- MB' : balances.dataText}
          </p>
        </button>

        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-400">Voice</p>
          <p className="font-mono-num text-lg sm:text-2xl font-bold text-white mt-2 truncate">
            {loading ? '-- Min' : balances.voiceText}
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenPointsSheet}
          className="rounded-2xl border border-white/[0.08] bg-[#141820] p-4 sm:p-5 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all group"
        >
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-slate-400">Points</p>
            <div className="flex items-center gap-1">
              <img src={KONG_ASSETS.icLoyalPoint} alt="Points" className="h-5 w-5 object-contain" />
              <ChevronRight className="h-4 w-4 text-slate-500 group-hover:text-[#E8B040] transition-colors" />
            </div>
          </div>
          <p className="font-mono-num text-lg sm:text-2xl font-bold text-[#E8B040] mt-2 truncate">
            {loading ? '--' : balances.points.toLocaleString()}
          </p>
        </button>
      </div>

      {/* Mini Games Hub — All 7 Official Mini-Games */}
      <section className="space-y-4 pt-1">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-white">Mini Games Hub</h2>
          <span className="text-xs text-slate-400 font-mono-num">7 Games Ready</span>
        </div>

        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-5 relative min-h-[190px]">
            <img
              src={KONG_ASSETS.heroBanner}
              alt="Kong Island"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/20 via-transparent to-[#141820]/90 hidden lg:block" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#141820] via-transparent to-transparent lg:hidden" />
          </div>

          <div className="lg:col-span-7 p-5 sm:p-8 flex flex-col justify-between gap-5">
            <div className="flex items-start gap-4">
              <img
                src={KONG_ASSETS.islandEmblem}
                alt="Kong Island Emblem"
                referrerPolicy="no-referrer"
                className="h-14 w-14 sm:h-16 sm:w-16 rounded-2xl border border-[#C8942A]/40 object-cover shrink-0"
              />
              <div className="space-y-1 min-w-0">
                <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
                  Kong Island
                </h3>
                <p className="text-xs sm:text-sm text-slate-400">
                  Kong Runner · Auto Play · Lucky Spin · Shop &amp; Exchange
                </p>
                {kong.isPlaying && (
                  <p className="text-xs font-semibold text-[#4CAF50] pt-1 font-mono-num">
                    Running Game {kong.currentGame}/{kong.alwaysLoop ? '∞' : kong.totalGames} ·{' '}
                    {kong.liveBananas.toLocaleString()} Bananas
                  </p>
                )}
              </div>
            </div>

            {kong.userInfo && (
              <div className="grid grid-cols-3 gap-3 border-t border-b border-white/[0.06] py-3.5">
                <div className="flex items-center gap-2.5">
                  <img src={KONG_ASSETS.icBanana} alt="Banana" className="h-7 w-7 object-contain shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[11px] text-slate-400">Banana</p>
                    <p className="font-mono-num text-sm sm:text-base font-bold text-[#E8B040] truncate">
                      {kong.userInfo.totalBanana.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <img src={KONG_ASSETS.icTicket} alt="Tickets" className="h-7 w-7 object-contain shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[11px] text-slate-400">Tickets</p>
                    <p className="font-mono-num text-sm sm:text-base font-bold text-white truncate">
                      {kong.userInfo.totalTicket.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <img src={KONG_ASSETS.icBox} alt="Boxes" className="h-7 w-7 object-contain shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[11px] text-slate-400">Boxes</p>
                    <p className="font-mono-num text-sm sm:text-base font-bold text-white truncate">
                      {kong.userInfo.totalBox.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2.5 sm:gap-3">
              <button
                type="button"
                onClick={() => onNavigate('kong-island')}
                className="col-span-2 sm:col-span-1 min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-6 py-2.5 text-sm font-bold text-[#0C0F14] hover:brightness-105 active:scale-[0.98] transition-all whitespace-nowrap flex items-center justify-center gap-2"
              >
                <img src={KONG_ASSETS.icKongRunner} alt="" className="h-5 w-5 rounded object-cover" />
                <span>Open Kong Island</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('kong-spin')}
                className="min-h-[46px] rounded-xl border border-white/10 bg-[#1B202B] px-5 py-2.5 text-sm font-medium text-slate-200 hover:border-[#C8942A]/50 active:scale-[0.98] transition-all whitespace-nowrap flex items-center justify-center gap-2"
              >
                <img src={KONG_ASSETS.icLuckySpin} alt="" className="h-5 w-5 object-contain" />
                <span>Lucky Spin</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('kong-shop')}
                className="min-h-[46px] rounded-xl border border-white/10 bg-[#1B202B] px-5 py-2.5 text-sm font-medium text-slate-200 hover:border-[#C8942A]/50 active:scale-[0.98] transition-all whitespace-nowrap"
              >
                Kong Shop
              </button>
            </div>
          </div>
        </div>

        {/* All Remaining 6 Mini-Games Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {[
            {
              route: 'beat-zoo' as AppRoute,
              name: 'Beat Zoo',
              subtitle: 'Songs · Missions · Lucky Wheel',
              icon: GAME_ASSETS.beatZooLogo,
              connected: Boolean(account.beatzooToken),
            },
            {
              route: 'car-racing' as AppRoute,
              name: 'Car Racing',
              subtitle: 'Auto-Race STOMP · Garage · Spin',
              icon: GAME_ASSETS.carRacingLogo,
              connected: Boolean(account.carRacingToken),
            },
            {
              route: 'fighting-fish' as AppRoute,
              name: 'Fighting Fish',
              subtitle: 'Story · Signed PvP · Power-Ups',
              icon: GAME_ASSETS.fightingFishLogo,
              connected: Boolean(account.fishioToken),
            },
            {
              route: 'kitty-fall' as AppRoute,
              name: 'Kitty Fall',
              subtitle: 'Cat Puzzle Bot · Turns · Rank',
              icon: GAME_ASSETS.kittyFallLogo,
              connected: Boolean(account.kittyCookie),
            },
            {
              route: 'soft-climbers' as AppRoute,
              name: 'Soft Climbers',
              subtitle: 'Climb Runner · Plans · Prizes',
              icon: GAME_ASSETS.softClimbersLogo,
              connected: Boolean(account.softClimbersToken),
            },
            {
              route: 'myid-go' as AppRoute,
              name: 'MyID Go',
              subtitle: '10-Step Adventure · Store · Rank',
              icon: GAME_ASSETS.myidGoLogo,
              connected: Boolean(account.myidGoToken),
            },
          ].map((g) => (
            <button
              key={g.route}
              type="button"
              onClick={() => onNavigate(g.route)}
              className="min-h-[82px] rounded-2xl border border-white/[0.08] bg-[#141820] p-4 flex items-center justify-between gap-3.5 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all group"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <img
                  src={g.icon}
                  alt={g.name}
                  className="h-12 w-12 rounded-xl border border-white/10 object-cover shrink-0 bg-[#0C0F14]"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-sm sm:text-base font-bold text-white truncate">
                      {g.name}
                    </h3>
                    {g.connected && (
                      <span className="text-[11px] font-medium text-[#4CAF50] shrink-0">
                        · Synced
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 truncate mt-0.5">{g.subtitle}</p>
                </div>
              </div>
              <ChevronRight className="h-4 w-4 text-slate-500 group-hover:text-[#E8B040] shrink-0 transition-colors" />
            </button>
          ))}
        </div>
      </section>

      {/* Edit Name Modal */}
      {editNameOpen && (
        <div
          onClick={() => setEditNameOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={handleSaveName}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Change Name</h3>
              <button
                type="button"
                onClick={() => setEditNameOpen(false)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <input
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              placeholder="နာမည် ထည့်ပါ"
              className="w-full min-h-[48px] rounded-xl border border-white/10 bg-[#1E232E] px-4 py-3 text-sm text-white focus:border-[#C8942A] focus:outline-none"
            />
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setEditNameOpen(false)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 px-4 py-2 text-xs font-semibold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingName}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-5 py-2 text-xs font-bold text-[#0C0F14]"
              >
                {savingName ? 'Saving...' : 'Save'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Logout Confirm Modal */}
      {logoutOpen && (
        <div
          onClick={() => setLogoutOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <h3 className="font-display text-lg font-bold text-white">Logout</h3>
            <p className="text-sm text-slate-300">
              လက်ရှိအကောင့် (<span className="font-mono-num text-white">{account.phone}</span>) မှ ထွက်လိုပါသလား?
            </p>
            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setLogoutOpen(false)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 px-4 py-2 text-xs font-semibold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setLogoutOpen(false);
                  onLogout();
                }}
                className="flex-1 min-h-[46px] rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white hover:bg-red-500"
              >
                LOGOUT
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
