import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  History,
  Loader2,
  Play,
  RefreshCw,
  ShoppingBag,
  Sparkles,
  Square,
  Trophy,
} from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { GAME_ASSETS } from '../lib/gameAssets';
import { kittyFallApi } from '../lib/gamesApi';
import { getRankMedal } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface KittyFallViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onBack: () => void;
}

type KittyTab = 'play' | 'shop' | 'history' | 'rank';

export function KittyFallView({ account, onAccountUpdated, onBack }: KittyFallViewProps) {
  const [cookie, setCookie] = useState(account.kittyCookie || '');
  const [tab, setTab] = useState<KittyTab>('play');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  // Profile & Shop data parsed from kittyfall.com.mm HTML
  const [profile, setProfile] = useState<{
    msisdn: string;
    points: number;
    turns: number;
    avatar: string;
    sessionToken: string;
    transId: string;
    buyTurnPackages: Array<{ code: string; name: string; price: string; turns: string; description: string }>;
    dailySubscription: { code: string; name: string; status: string; rawText: string } | null;
    needsRegistration: boolean;
  }>({
    msisdn: account.phone,
    points: 0,
    turns: 0,
    avatar: '',
    sessionToken: '',
    transId: '',
    buyTurnPackages: [],
    dailySubscription: null,
    needsRegistration: false,
  });

  // Gameplay Bot State
  const [level, setLevel] = useState(1);
  const [targetScore, setTargetScore] = useState(2500);
  const [isPlaying, setIsPlaying] = useState(false);
  const [autoLoop, setAutoLoop] = useState(false);
  const [playPct, setPlayPct] = useState(0);
  const stopRef = useRef(false);

  // History & Leaderboard
  const [historyRows, setHistoryRows] = useState<any[]>([]);
  const [rankRows, setRankRows] = useState<any[]>([]);
  const [myRankSummary, setMyRankSummary] = useState('');
  const [buyingCode, setBuyingCode] = useState<string | null>(null);

  const bootstrap = useCallback(
    async (existingCookie?: string) => {
      setLoading(true);
      setErrorMsg('');
      try {
        const res = await kittyFallApi.bootstrap({
          thirdPartyToken: account.thirdPartyToken,
          phone: account.phone,
          lang: 'mu',
          cookie: existingCookie ?? cookie,
        });
        if (res?.cookie) {
          setCookie(res.cookie);
          const updated = updateActiveAccount({ kittyCookie: res.cookie });
          if (updated) onAccountUpdated(updated);
        }
        if (res?.data) {
          setProfile((prev) => ({ ...prev, ...res.data }));
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to connect to Kitty Fall');
      } finally {
        setLoading(false);
      }
    },
    [account.phone, account.thirdPartyToken, cookie, onAccountUpdated]
  );

  useEffect(() => {
    bootstrap();
    return () => {
      stopRef.current = true;
    };
  }, [account.phone]);

  useEffect(() => {
    if (!cookie) return;
    if (tab === 'history') {
      kittyFallApi
        .getHistory(cookie)
        .then((res) => setHistoryRows(Array.isArray(res?.data) ? res.data : []))
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load history'));
    } else if (tab === 'rank') {
      kittyFallApi
        .getLeaderboard(cookie, 1)
        .then((res) => {
          setRankRows(Array.isArray(res?.data?.rows) ? res.data.rows : []);
          setMyRankSummary(res?.data?.myRankSummary || '');
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load leaderboard'));
    }
  }, [tab, cookie]);

  const stopAutoPlay = () => {
    stopRef.current = true;
    setIsPlaying(false);
    setPlayPct(0);
  };

  const handleStartAutoPlay = async () => {
    if (isPlaying) return;
    stopRef.current = false;
    setIsPlaying(true);
    setErrorMsg('');
    setStatusMsg('');

    try {
      let curLevel = level;
      do {
        setPlayPct(15);
        const startRes = await kittyFallApi.startSession({
          cookie,
          msisdn: profile.msisdn || account.phone,
          token: profile.sessionToken || account.thirdPartyToken,
          transId: profile.transId || `kf_${Date.now()}`,
          gameType: 'catpuzzle',
          level: curLevel,
          score: 0,
          gameOver: 0,
        });
        if (startRes?.success === false) {
          throw new Error(startRes?.message || 'Kitty Fall StartSession failed');
        }
        const activeTransId = startRes?.transId || startRes?.data?.transId || profile.transId || `kf_${Date.now()}`;
        const activeToken = startRes?.token || startRes?.data?.token || profile.sessionToken || account.thirdPartyToken;

        for (let step = 2; step <= 8; step++) {
          if (stopRef.current) break;
          setPlayPct(step * 10);
          await new Promise((r) => window.setTimeout(r, 700));
        }
        if (stopRef.current) break;

        setPlayPct(95);
        const saveRes = await kittyFallApi.saveResult({
          cookie,
          msisdn: profile.msisdn || account.phone,
          token: activeToken,
          transId: activeTransId,
          level: curLevel,
          score: targetScore,
          gameType: 'catpuzzle',
          gameOver: 1,
        });
        if (saveRes?.success === false) {
          throw new Error(saveRes?.message || 'SaveLevelResult failed');
        }
        setPlayPct(100);
        setStatusMsg(`Level ${curLevel} saved (${targetScore.toLocaleString()} pts)!`);
        curLevel += 1;
        setLevel(curLevel);
        await bootstrap(cookie);
        if (!autoLoop || stopRef.current) break;
        await new Promise((r) => window.setTimeout(r, 500));
      } while (!stopRef.current && autoLoop);
    } catch (err) {
      if (!stopRef.current) {
        setErrorMsg(err instanceof Error ? err.message : 'Kitty Fall play failed');
      }
    } finally {
      setIsPlaying(false);
      setPlayPct(0);
    }
  };

  const handleBuyTurn = async (code: string) => {
    setBuyingCode(code);
    setErrorMsg('');
    try {
      const res = await kittyFallApi.buyTurn(cookie, code);
      if (res?.success === false) throw new Error(res?.message || 'Buy turn failed');
      setStatusMsg(res?.message || `Purchased ${code}`);
      await bootstrap(cookie);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Buy turn failed');
    } finally {
      setBuyingCode(null);
    }
  };

  const handleRegisterSub = async (code: string) => {
    setBuyingCode(code);
    setErrorMsg('');
    try {
      const res = await kittyFallApi.registerSubscription(cookie, code);
      if (res?.success === false) throw new Error(res?.message || 'Subscription failed');
      setStatusMsg(res?.message || `Subscribed ${code}`);
      await bootstrap(cookie);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Subscription failed');
    } finally {
      setBuyingCode(null);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Kitty Fall"
        subtitle="Cat Puzzle Auto-Player · Turns & Daily Subscription · Rank"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => bootstrap()}
            disabled={loading}
            aria-label="Sync Kitty Fall"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Profile + Currency */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 space-y-4">
        <div className="flex items-center gap-3.5">
          <img
            src={profile.avatar || GAME_ASSETS.kittyFallLogo}
            alt="Kitty Fall"
            referrerPolicy="no-referrer"
            className="h-12 w-12 rounded-2xl border border-[#C8942A]/40 object-cover shrink-0"
          />
          <div className="min-w-0">
            <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
              {profile.msisdn || account.phone}
            </h2>
            <p className="text-xs text-slate-400">
              {profile.needsRegistration ? 'Subscription required before play' : 'Kitty Fall Active Session'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/[0.06]">
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3.5 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.kittyCoin} alt="Points" className="h-7 w-7 object-contain shrink-0" />
            <div>
              <p className="text-[11px] text-slate-400">Kitty Points</p>
              <p className="font-mono-num text-base font-bold text-[#E8B040]">
                {loading ? '--' : profile.points.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3.5 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.kittyTicket} alt="Turns" className="h-7 w-7 object-contain shrink-0" />
            <div>
              <p className="text-[11px] text-slate-400">Play Turns</p>
              <p className="font-mono-num text-base font-bold text-white">
                {loading ? '--' : profile.turns.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Android Tab Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'play', label: 'Puzzle Bot', icon: Play },
          { id: 'shop', label: 'Turns & Sub', icon: ShoppingBag },
          { id: 'history', label: 'History', icon: History },
          { id: 'rank', label: 'Rank', icon: Trophy },
        ].map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as KittyTab)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 flex items-center gap-2 border transition-all ${
                active
                  ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                  : 'border-white/10 bg-[#161920] text-slate-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusMsg}</span>
          <button type="button" onClick={() => setStatusMsg('')} className="text-xs underline">
            OK
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button type="button" onClick={() => setErrorMsg('')} className="text-xs underline">
            Close
          </button>
        </div>
      )}

      {/* TAB: PUZZLE BOT */}
      {tab === 'play' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-display text-lg font-bold text-white">Cat Puzzle Auto-Runner</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                StartSession → Level Solve → SaveLevelResult
              </p>
            </div>
            <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <span>Auto Loop</span>
              <button
                type="button"
                role="switch"
                aria-checked={autoLoop}
                onClick={() => setAutoLoop((v) => !v)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoLoop ? 'bg-[#4CAF50]' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    autoLoop ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Level</label>
              <input
                type="number"
                min={1}
                value={level}
                onChange={(e) => setLevel(Math.max(1, Number(e.target.value) || 1))}
                className="w-full min-h-[46px] rounded-xl border border-white/10 bg-[#12151B] px-4 text-sm font-mono-num text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Target Score</label>
              <input
                type="number"
                min={100}
                value={targetScore}
                onChange={(e) => setTargetScore(Math.max(100, Number(e.target.value) || 100))}
                className="w-full min-h-[46px] rounded-xl border border-white/10 bg-[#12151B] px-4 text-sm font-mono-num text-white"
              />
            </div>
          </div>

          {isPlaying && (
            <div className="space-y-1.5">
              <div className="h-2.5 w-full rounded-full bg-[#12151B] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all"
                  style={{ width: `${playPct}%` }}
                />
              </div>
              <p className="text-xs font-mono-num text-slate-400 text-right">{playPct}%</p>
            </div>
          )}

          {!isPlaying ? (
            <button
              type="button"
              disabled={loading}
              onClick={handleStartAutoPlay}
              className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] flex items-center justify-center gap-2"
            >
              <Play className="h-4 w-4 fill-current" />
              <span>Play Level {level}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={stopAutoPlay}
              className="w-full min-h-[48px] rounded-xl bg-red-600 text-sm font-bold text-white flex items-center justify-center gap-2"
            >
              <Square className="h-4 w-4 fill-current" />
              <span>Stop</span>
            </button>
          )}
        </div>
      )}

      {/* TAB: TURNS & SUBSCRIPTION */}
      {tab === 'shop' && (
        <div className="space-y-4">
          {profile.dailySubscription && (
            <div className="rounded-2xl border border-[#C8942A]/40 bg-[#1A1812] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-[#E8B040]" />
                  <h3 className="font-display text-base font-bold text-white">
                    {profile.dailySubscription.name}
                  </h3>
                </div>
                <p className="text-xs text-slate-300">
                  {profile.dailySubscription.rawText || 'Daily subscription turns'}
                </p>
              </div>
              <button
                type="button"
                disabled={buyingCode === profile.dailySubscription.code}
                onClick={() => handleRegisterSub(profile.dailySubscription!.code)}
                className="min-h-[46px] shrink-0 rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-5 text-xs font-bold text-[#0C0F14]"
              >
                {buyingCode === profile.dailySubscription.code ? 'Processing...' : 'Register Daily'}
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {profile.buyTurnPackages.length === 0 ? (
              <div className="sm:col-span-2 rounded-2xl border border-white/[0.08] bg-[#161920] p-6 text-center text-sm text-slate-400">
                {loading ? <Loader2 className="h-5 w-5 animate-spin mx-auto text-[#E8B040]" /> : 'No turn packages available on portal right now.'}
              </div>
            ) : (
              profile.buyTurnPackages.map((pkg, idx) => (
                <div
                  key={`kf-pkg-${pkg.code}-${idx}`}
                  className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img src={GAME_ASSETS.kittyTicket} alt="" className="h-10 w-10 object-contain shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{pkg.name}</p>
                      <p className="text-xs font-mono-num text-[#E8B040]">
                        {pkg.price ? `${pkg.price} Ks` : pkg.description}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={buyingCode === pkg.code}
                    onClick={() => handleBuyTurn(pkg.code)}
                    className="min-h-[42px] shrink-0 rounded-xl bg-[#C8942A] px-4 text-xs font-bold text-[#0C0F14]"
                  >
                    {buyingCode === pkg.code ? '...' : 'Buy'}
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB: HISTORY */}
      {tab === 'history' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
          {historyRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No prize or game history rows yet.</div>
          ) : (
            historyRows.map((h, idx) => (
              <div key={`kf-hist-${idx}`} className="p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{h.title || 'Kitty Fall Event'}</p>
                  <p className="text-xs text-slate-400">
                    {h.date} {h.detail ? `· ${h.detail}` : ''}
                  </p>
                </div>
                <span className="font-mono-num text-xs font-bold text-[#E8B040] shrink-0">
                  {h.pointsOrPrize || h.status}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB: RANK */}
      {tab === 'rank' && (
        <div className="space-y-3">
          {myRankSummary && (
            <div className="rounded-xl border border-[#C8942A]/40 bg-[#1D1A12] px-4 py-3 text-xs font-semibold text-[#E8B040]">
              {myRankSummary}
            </div>
          )}
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
            {rankRows.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-400">No ranking entries yet.</div>
            ) : (
              rankRows.map((r, idx) => {
                const medal = getRankMedal(r.rank);
                return (
                  <div key={`kf-rank-${r.rank}-${idx}`} className="px-4 py-3.5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {medal ? (
                        <img src={medal} alt="" className="h-6 w-6 object-contain shrink-0" />
                      ) : (
                        <span className="w-6 text-center font-mono-num text-xs font-bold text-slate-400">
                          #{r.rank}
                        </span>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {r.phone} {r.isMe ? '(You)' : ''}
                        </p>
                        {r.reward && <p className="text-xs text-[#81C784]">{r.reward}</p>}
                      </div>
                    </div>
                    <span className="font-mono-num text-sm font-bold text-[#E8B040]">{r.score}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
