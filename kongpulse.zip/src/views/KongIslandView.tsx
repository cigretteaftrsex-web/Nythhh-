import React, { useCallback, useEffect, useState } from 'react';
import { Check, Loader2, Pencil, Play, RefreshCw, Square, Trophy, X } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { useKongRunner } from '../context/KongRunnerContext';
import { kongApi } from '../lib/api';
import { KONG_ASSETS, getRankMedal, getRewardAsset } from '../lib/kongAssets';
import { getAlwaysLoop, setAlwaysLoop } from '../lib/storage';
import type {
  AppRoute,
  KongAvatar,
  KongLeaderboardRow,
  KongUserInfo,
  SavedAccount,
} from '../types';

interface KongIslandViewProps {
  account: SavedAccount;
  onBack: () => void;
  onNavigate: (route: AppRoute) => void;
}

const MATCH_COUNTS = [1, 3, 5, 10, 20, 30] as const;

function formatTime(ms: number | null): string {
  if (!ms) return '--';
  return new Date(ms).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

function formatDurationSec(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return m > 0 ? `${m}m ${rem}s` : `${rem}s`;
}

function formatRewardType(t: string): string {
  const up = t.toUpperCase();
  if (up.includes('X2')) return 'x2 Banana Boost';
  if (up === 'BANANA') return 'Banana';
  if (up === 'TICKET') return 'Play Ticket';
  if (up === 'PROTECT') return 'Shield Protect';
  if (up === 'REBORN') return 'Reborn Heart';
  if (up === 'MAGNET') return 'Banana Magnet';
  return t;
}

function formatRankReward(reward?: string, rewardType?: string): string {
  if (!reward) return '';
  const n = Number(reward);
  const formatted = Number.isFinite(n) && n > 0 ? n.toLocaleString() : reward;
  const rt = (rewardType || '').toUpperCase();
  if (rt.includes('LOYALTY')) return `${formatted} pts`;
  if (rt.includes('MMK')) return `${formatted} Ks`;
  if (rt.includes('BANANA')) return `${formatted} Banana`;
  return formatted;
}

function AvatarImage({
  src,
  alt,
  className,
}: {
  src?: string | null;
  alt: string;
  className: string;
}) {
  const [failed, setFailed] = useState(false);
  const resolved = !failed && src ? src : KONG_ASSETS.islandEmblem;
  return (
    <img
      src={resolved}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}

export function KongIslandView({ account, onBack, onNavigate }: KongIslandViewProps) {
  const kong = useKongRunner();
  const [activeTab, setActiveTab] = useState<'play' | 'rank'>('play');
  const [selectedCount, setSelectedCount] = useState<number>(1);
  const [loopChecked, setLoopChecked] = useState<boolean>(() => getAlwaysLoop(account.phone));
  const [autoX2Checked, setAutoX2Checked] = useState<boolean>(() => kong.autoX2);
  const [openingBox, setOpeningBox] = useState(false);
  const [boxResult, setBoxResult] = useState<Array<{ text: string; icon: string }> | null>(null);
  const [actionError, setActionError] = useState('');

  // Edit Player Name
  const [editNameOpen, setEditNameOpen] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [savingName, setSavingName] = useState(false);

  // Avatar Picker Modal
  const [avatarModalOpen, setAvatarModalOpen] = useState(false);
  const [avatars, setAvatars] = useState<KongAvatar[]>([]);
  const [loadingAvatars, setLoadingAvatars] = useState(false);
  const [buyingAvatarId, setBuyingAvatarId] = useState<number | null>(null);

  // Rank Tab State
  const [rankPeriod, setRankPeriod] = useState<'week' | 'month'>('week');
  const [rankRows, setRankRows] = useState<KongLeaderboardRow[]>([]);
  const [userRankRow, setUserRankRow] = useState<KongLeaderboardRow | null>(null);
  const [loadingRank, setLoadingRank] = useState(false);

  useEffect(() => {
    setLoopChecked(getAlwaysLoop(account.phone));
    kong.ensureKongSession(account);
  }, [account.phone]);

  const loadLeaderboard = useCallback(
    async (period: 'week' | 'month') => {
      if (!kong.kongToken) return;
      setLoadingRank(true);
      setActionError('');
      try {
        const res = await kongApi.getLeaderboard(kong.kongToken, period);
        const data = res?.data || res;
        const ranks = Array.isArray(data?.ranks) ? data.ranks : [];
        setRankRows(
          ranks.map((r: any, idx: number) => ({
            rank: Number(r.order ?? r.rank ?? idx + 1),
            playerName: String(r.playerName || r.msisdn || 'Player'),
            msisdn: String(r.msisdn || ''),
            avatar: r.avatar ? String(r.avatar) : '',
            totalBanana: Number(r.banana ?? r.totalBanana ?? r.score ?? 0),
            reward: r.rankReward?.reward
              ? String(r.rankReward.reward)
              : r.reward
              ? String(r.reward)
              : undefined,
            rewardType: r.rankReward?.rewardType ? String(r.rankReward.rewardType) : undefined,
          }))
        );
        if (data?.userRank) {
          const ur = data.userRank;
          setUserRankRow({
            rank: Number(ur.order ?? ur.rank ?? 0),
            playerName: String(ur.playerName || kong.userInfo?.playerName || account.phone),
            msisdn: String(ur.msisdn || account.phone),
            avatar: ur.avatar ? String(ur.avatar) : kong.userInfo?.avatar || '',
            totalBanana: Number(ur.banana ?? ur.totalBanana ?? ur.score ?? 0),
            reward: ur.rankReward?.reward ? String(ur.rankReward.reward) : undefined,
            rewardType: ur.rankReward?.rewardType ? String(ur.rankReward.rewardType) : undefined,
          });
        } else {
          setUserRankRow(null);
        }
      } catch (err) {
        setActionError(err instanceof Error ? err.message : 'Unable to load leaderboard');
      } finally {
        setLoadingRank(false);
      }
    },
    [account.phone, kong.kongToken, kong.userInfo?.avatar, kong.userInfo?.playerName]
  );

  useEffect(() => {
    if (activeTab === 'rank' && kong.kongToken) {
      loadLeaderboard(rankPeriod);
    }
  }, [activeTab, rankPeriod, kong.kongToken, loadLeaderboard]);

  const handleToggleLoop = () => {
    const next = !loopChecked;
    setLoopChecked(next);
    setAlwaysLoop(account.phone, next);
    kong.setAlwaysLoopState(next);
  };

  const handleToggleAutoX2 = () => {
    const next = !autoX2Checked;
    setAutoX2Checked(next);
    kong.setAutoX2State(next);
  };

  const handleStartAutoPlay = async () => {
    setActionError('');
    let tok = kong.kongToken;
    if (!tok) {
      const resolved = await kong.ensureKongSession(account, true);
      if (!resolved) return;
      tok = resolved;
    }
    kong.startGames(selectedCount, loopChecked, tok, autoX2Checked);
  };

  const handleOpenBox = async () => {
    if (!kong.kongToken || !kong.userInfo || kong.userInfo.totalBox <= 0) return;
    setOpeningBox(true);
    setActionError('');
    try {
      const res = await kongApi.openBox(kong.kongToken, kong.userInfo.totalBox);
      if (res?.success === false) {
        throw new Error(res?.message || 'Failed to open box');
      }
      const rewardsRaw = res?.data?.itemReward || res?.data?.rewards || res?.data;
      const lines: Array<{ text: string; icon: string }> = [];
      if (Array.isArray(rewardsRaw)) {
        rewardsRaw.forEach((it: any) => {
          const rawType = String(it.typeItem || it.type || 'Reward');
          const t = formatRewardType(rawType);
          const v = Number(it.value || it.amount || 1);
          lines.push({
            text: `${t}: +${v.toLocaleString()}`,
            icon: getRewardAsset(rawType),
          });
        });
      } else if (rewardsRaw && typeof rewardsRaw === 'object') {
        lines.push({
          text: rewardsRaw.description || rewardsRaw.message || 'Box opened!',
          icon: KONG_ASSETS.icBox,
        });
      } else {
        lines.push({ text: res?.message || 'Box opened!', icon: KONG_ASSETS.icBox });
      }
      setBoxResult(lines.length ? lines : [{ text: 'Box opened successfully!', icon: KONG_ASSETS.icBox }]);
      await kong.refreshUserInfo();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to open box');
    } finally {
      setOpeningBox(false);
    }
  };

  const handleSavePlayerName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!kong.kongToken || !nameInput.trim()) return;
    setSavingName(true);
    setActionError('');
    try {
      const res = await kongApi.updatePlayerName(kong.kongToken, nameInput.trim());
      if (res?.success === false) {
        throw new Error(res?.message || 'Failed to update player name');
      }
      await kong.refreshUserInfo();
      setEditNameOpen(false);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to update player name');
    } finally {
      setSavingName(false);
    }
  };

  const openAvatarModal = async () => {
    if (!kong.kongToken) return;
    setAvatarModalOpen(true);
    setLoadingAvatars(true);
    setActionError('');
    try {
      const res = await kongApi.getAvatarList(kong.kongToken);
      const list = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
      setAvatars(
        list.map((a: any) => ({
          id: Number(a.id),
          url: String(a.url || ''),
          status: String(a.status || 'INACTIVE').toUpperCase(),
          price: a.price !== undefined ? Number(a.price) : undefined,
          currency: a.currency ? String(a.currency) : 'BANANA',
          description: a.description ? String(a.description) : undefined,
        }))
      );
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to fetch avatars');
    } finally {
      setLoadingAvatars(false);
    }
  };

  const handleSelectOrBuyAvatar = async (av: KongAvatar) => {
    if (!kong.kongToken || av.status === 'USING') return;
    setBuyingAvatarId(av.id);
    setActionError('');
    try {
      const res = await kongApi.buyAvatar(kong.kongToken, av.id);
      const ok = res?.success === true || res?.error === '00000' || Boolean(res?.data);
      if (res?.success === false || (!ok && res?.message)) {
        throw new Error(res?.message || 'Unable to equip avatar');
      }
      await kong.refreshUserInfo();
      setAvatarModalOpen(false);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to equip avatar');
    } finally {
      setBuyingAvatarId(null);
    }
  };

  const info: KongUserInfo = kong.userInfo || {
    playerName: account.fullName || account.phone,
    msisdn: account.phone,
    avatar: account.avatarUrl || '',
    totalBanana: 0,
    totalTicket: 0,
    totalBox: 0,
    total2xBanana: 0,
    totalMagnet: 0,
    totalProtect: 0,
    totalReborn: 0,
    turnFree: 0,
  };

  const progressPct = Math.min(100, Math.round((kong.elapsedMs / kong.gameDurationMs) * 100));
  const remainingSec = Math.max(0, Math.ceil((kong.gameDurationMs - kong.elapsedMs) / 1000));
  const x2IsActive = Boolean(kong.x2ActiveUntil && kong.x2ActiveUntil > Date.now());
  const topThree = rankRows.slice(0, 3);
  const restRanks = rankRows.slice(3);

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Kong Island"
        subtitle="Runner · Shop · Leaderboard · Spin"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => kong.ensureKongSession(account, true)}
            disabled={kong.loadingInfo}
            aria-label="Sync Kong Island"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${kong.loadingInfo ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Play / Rank Segmented Tabs + Spin CTA */}
      <div className="flex items-center justify-between gap-3 border-b border-white/[0.08] pb-3">
        <div className="inline-flex items-center gap-1 rounded-xl border border-white/[0.08] bg-[#141820] p-1">
          <button
            type="button"
            onClick={() => setActiveTab('play')}
            className={`inline-flex items-center gap-2 min-h-[42px] px-4 sm:px-5 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'play'
                ? 'bg-[#C8942A] text-[#0C0F14]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Play className="h-4 w-4" />
            <span>Play</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('rank')}
            className={`inline-flex items-center gap-2 min-h-[42px] px-4 sm:px-5 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'rank'
                ? 'bg-[#C8942A] text-[#0C0F14]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Trophy className="h-4 w-4" />
            <span>Rank</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('kong-spin')}
          className="inline-flex items-center gap-2 min-h-[44px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] hover:brightness-105 active:scale-95 transition-all whitespace-nowrap"
        >
          <img src={KONG_ASSETS.icLuckySpin} alt="" className="h-5 w-5 object-contain" />
          <span>Lucky Spin</span>
        </button>
      </div>

      {(kong.authError || actionError || kong.statusMessage) && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 flex items-center justify-between gap-4">
          <span>{actionError || kong.authError || kong.statusMessage}</span>
          <button
            type="button"
            onClick={() => setActionError('')}
            className="text-amber-300 hover:text-white shrink-0 min-h-[32px] px-2"
          >
            Close
          </button>
        </div>
      )}

      {activeTab === 'play' ? (
        <div className="space-y-4 sm:space-y-5">
          {/* Player Profile + Shop / Exchange Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
            <div className="lg:col-span-5 rounded-2xl border border-white/[0.08] bg-[#161920] p-5 flex items-center gap-4">
              <button
                type="button"
                onClick={openAvatarModal}
                aria-label="Choose Kong avatar"
                className="h-16 w-16 rounded-2xl border-2 border-[#C8942A]/50 bg-[#141820] overflow-hidden shrink-0 flex items-center justify-center hover:border-[#E8B040] active:scale-95 transition-all"
              >
                <AvatarImage
                  src={info.avatar}
                  alt={info.playerName}
                  className="h-full w-full object-cover"
                />
              </button>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <h2 className="font-display text-lg font-bold text-white truncate">
                    {info.playerName}
                  </h2>
                  <button
                    type="button"
                    onClick={() => {
                      setNameInput(info.playerName);
                      setEditNameOpen(true);
                    }}
                    aria-label="Edit player name"
                    className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-[#E8B040] shrink-0"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                </div>
                <p className="text-xs font-mono-num text-slate-400 mt-0.5">
                  {info.msisdn || account.phone}
                </p>
                <button
                  type="button"
                  onClick={openAvatarModal}
                  className="text-xs font-semibold text-[#E8B040] hover:underline mt-1.5 inline-block"
                >
                  Change Avatar
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <button
                type="button"
                onClick={() => onNavigate('kong-shop')}
                className="min-h-[72px] rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all flex items-center gap-4"
              >
                <div className="h-12 w-12 rounded-xl bg-[#C8942A]/12 border border-[#C8942A]/25 flex items-center justify-center shrink-0">
                  <img src={KONG_ASSETS.icTicket} alt="Shop" className="h-7 w-7 object-contain" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white truncate">ကစားကြိမ် ဝယ်ယူမည်</p>
                  <p className="text-xs text-slate-400 mt-0.5 truncate">
                    Subscription &amp; Retail Shop
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('kong-exchange')}
                className="min-h-[72px] rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 text-left hover:border-[#C8942A]/50 active:scale-[0.98] transition-all flex items-center gap-4"
              >
                <div className="h-12 w-12 rounded-xl bg-[#C8942A]/12 border border-[#C8942A]/25 flex items-center justify-center shrink-0">
                  <img src={KONG_ASSETS.icBanana} alt="Exchange" className="h-7 w-7 object-contain" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white truncate">Banana ဖြင့်လဲလှယ်မည်</p>
                  <p className="text-xs text-slate-400 mt-0.5 truncate">Items &amp; Power-ups</p>
                </div>
              </button>
            </div>
          </div>

          {/* 3-Column Balances Strip */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4">
            <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Banana</span>
                <img src={KONG_ASSETS.icBanana} alt="" className="h-5 w-5 object-contain shrink-0" />
              </div>
              <p className="font-mono-num text-lg sm:text-2xl font-bold text-[#E8B040] mt-2 truncate">
                {kong.loadingInfo ? '---' : info.totalBanana.toLocaleString()}
              </p>
            </div>
            <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Tickets</span>
                <img src={KONG_ASSETS.icTicket} alt="" className="h-5 w-5 object-contain shrink-0" />
              </div>
              <p className="font-mono-num text-lg sm:text-2xl font-bold text-white mt-2 truncate">
                {kong.loadingInfo ? '---' : info.totalTicket.toLocaleString()}
              </p>
            </div>
            <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Boxes</span>
                <img src={KONG_ASSETS.icBox} alt="" className="h-5 w-5 object-contain shrink-0" />
              </div>
              <p className="font-mono-num text-lg sm:text-2xl font-bold text-white mt-2 truncate">
                {kong.loadingInfo ? '---' : info.totalBox.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Power-up Inventory Strip */}
          <div className="rounded-2xl border border-white/[0.08] bg-[#141820] px-4 py-3 grid grid-cols-5 gap-2">
            {[
              { label: 'x2', value: info.total2xBanana, icon: KONG_ASSETS.icX2Banana },
              { label: 'Magnet', value: info.totalMagnet ?? 0, icon: KONG_ASSETS.icMagnet },
              { label: 'Shield', value: info.totalProtect ?? 0, icon: KONG_ASSETS.icProtect },
              { label: 'Reborn', value: info.totalReborn ?? 0, icon: KONG_ASSETS.icReborn },
              { label: 'Spins', value: info.turnFree ?? 0, icon: KONG_ASSETS.icTurn },
            ].map((item) => (
              <div
                key={item.label}
                className="flex flex-col items-center text-center gap-1 py-1"
              >
                <img src={item.icon} alt={item.label} className="h-6 w-6 object-contain" />
                <span className="font-mono-num text-xs font-bold text-white">
                  {kong.loadingInfo ? '--' : item.value}
                </span>
                <span className="text-[10px] text-slate-400 truncate max-w-full">{item.label}</span>
              </div>
            ))}
          </div>

          {/* Game Picker / Live Playing Card */}
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 sm:p-6 space-y-5">
            {!kong.isPlaying ? (
              <>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={KONG_ASSETS.icKongRunner}
                      alt="Kong Runner"
                      className="h-10 w-10 rounded-xl object-contain shrink-0"
                    />
                    <div>
                      <h3 className="font-display text-lg font-bold text-white">How Many Matches</h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Select match batch or enable Always Loop / Auto x2
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4">
                    {/* Auto x2 Switch */}
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none min-h-[36px]">
                      <img src={KONG_ASSETS.icX2Banana} alt="" className="h-4 w-4 object-contain" />
                      <span className="text-xs font-medium text-slate-300">
                        Auto x2 ({info.total2xBanana})
                      </span>
                      <button
                        type="button"
                        role="switch"
                        aria-checked={autoX2Checked}
                        onClick={handleToggleAutoX2}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          autoX2Checked ? 'bg-[#C8942A]' : 'bg-slate-700'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            autoX2Checked ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </label>

                    {/* Always Loop Switch */}
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none min-h-[36px]">
                      <span className="text-xs font-medium text-slate-300">Always Loop</span>
                      <button
                        type="button"
                        role="switch"
                        aria-checked={loopChecked}
                        onClick={handleToggleLoop}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          loopChecked ? 'bg-[#4CAF50]' : 'bg-slate-700'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            loopChecked ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 sm:gap-3">
                  {MATCH_COUNTS.map((cnt) => (
                    <button
                      key={cnt}
                      type="button"
                      onClick={() => setSelectedCount(cnt)}
                      className={`min-h-[48px] rounded-xl border text-base font-bold font-mono-num active:scale-95 transition-all ${
                        selectedCount === cnt
                          ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                          : 'border-white/10 bg-[#12151B] text-slate-200 hover:border-white/25'
                      }`}
                    >
                      {cnt}
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <div className="space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-semibold text-[#4CAF50]">
                      <span className="h-2 w-2 rounded-full bg-[#4CAF50] animate-pulse" />
                      <span>Playing Live</span>
                      {x2IsActive && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#E8B040]">x2 Boost Active</span>
                        </>
                      )}
                    </div>
                    <h3 className="font-display text-xl font-bold text-white mt-0.5 font-mono-num">
                      Game {kong.currentGame}/{kong.alwaysLoop ? '∞' : kong.totalGames} —{' '}
                      {kong.liveBananas.toLocaleString()}
                    </h3>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      disabled={info.total2xBanana <= 0}
                      onClick={kong.useX2Banana}
                      className="inline-flex items-center gap-2 min-h-[44px] rounded-xl border border-[#C8942A]/40 bg-[#C8942A]/15 px-3.5 py-2 text-xs font-bold text-[#E8B040] hover:bg-[#C8942A]/25 disabled:opacity-45 active:scale-95 transition-all"
                    >
                      <img src={KONG_ASSETS.icX2Banana} alt="" className="h-4 w-4 object-contain" />
                      <span>Use x2 ({info.total2xBanana})</span>
                    </button>
                    <span className="font-mono-num text-sm font-bold text-white">
                      {formatDurationSec(kong.elapsedMs)}
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="h-3 w-full rounded-full bg-[#12151B] overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all duration-300"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400 font-mono-num">
                    <span>{formatDurationSec(kong.elapsedMs)} / 10m</span>
                    <span>
                      {progressPct}% · {remainingSec}s left
                    </span>
                  </div>
                </div>

                {/* Runner Telemetry Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-3 border-t border-white/[0.06] text-xs">
                  <div>
                    <p className="text-slate-400">Live Banana</p>
                    <p className="font-mono-num text-sm font-bold text-[#E8B040] mt-0.5">
                      {kong.liveBananas.toLocaleString()}
                      {kong.serverMax > 0 ? ` / ${kong.serverMax.toLocaleString()}` : ''}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400">Rate</p>
                    <p className="font-mono-num text-sm font-semibold text-white mt-0.5">
                      {kong.bananaRatePerMin.toLocaleString()} / min
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400">Started</p>
                    <p className="font-mono-num text-sm font-semibold text-white mt-0.5">
                      {formatTime(kong.startedAt)}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400">Est. End</p>
                    <p className="font-mono-num text-sm font-semibold text-white mt-0.5">
                      {formatTime(kong.estEndAt)}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Play / Stop & Open Box Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {!kong.isPlaying ? (
                <button
                  type="button"
                  onClick={handleStartAutoPlay}
                  disabled={kong.loadingInfo}
                  className="min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-6 py-3 text-sm font-bold text-[#0C0F14] hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>ကစားမည်</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={kong.stopGames}
                  className="min-h-[48px] rounded-xl bg-red-600 px-6 py-3 text-sm font-bold text-white hover:bg-red-500 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                >
                  <Square className="h-4 w-4 fill-current" />
                  <span>ရပ်မည်</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleOpenBox}
                disabled={openingBox || info.totalBox <= 0}
                className="min-h-[48px] rounded-xl border border-white/10 bg-[#12151B] px-6 py-3 text-sm font-bold text-white hover:border-[#C8942A]/50 disabled:opacity-50 active:scale-[0.98] transition-all flex items-center justify-center gap-2 font-mono-num"
              >
                {openingBox ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <img src={KONG_ASSETS.freebox} alt="" className="h-5 w-5 object-contain" />
                )}
                <span>OPEN BOX ({info.totalBox})</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Rank Tab */
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="inline-flex items-center gap-1 rounded-xl border border-white/[0.08] bg-[#141820] p-1">
              <button
                type="button"
                onClick={() => setRankPeriod('week')}
                className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
                  rankPeriod === 'week'
                    ? 'bg-[#C8942A] text-[#0C0F14]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Weekly
              </button>
              <button
                type="button"
                onClick={() => setRankPeriod('month')}
                className={`min-h-[42px] px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
                  rankPeriod === 'month'
                    ? 'bg-[#C8942A] text-[#0C0F14]'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Monthly
              </button>
            </div>

            <button
              type="button"
              onClick={() => loadLeaderboard(rankPeriod)}
              disabled={loadingRank}
              className="min-h-[42px] rounded-xl border border-white/10 bg-[#141820] px-4 py-2 text-xs font-medium text-slate-300 hover:text-white active:scale-95 transition-all"
            >
              Refresh
            </button>
          </div>

          {userRankRow && (
            <div className="rounded-2xl border border-[#C8942A]/50 bg-[#1D1B16] p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <span className="font-mono-num text-base font-bold text-[#E8B040] w-9 text-center shrink-0">
                  #{userRankRow.rank > 0 ? userRankRow.rank : '-'}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white truncate">
                    {userRankRow.playerName} (You)
                  </p>
                  <p className="text-xs font-mono-num text-slate-400">{userRankRow.msisdn}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 font-mono-num text-sm font-bold text-[#E8B040] shrink-0">
                <img src={KONG_ASSETS.icBanana} alt="" className="h-4 w-4 object-contain" />
                <span>{userRankRow.totalBanana.toLocaleString()}</span>
              </div>
            </div>
          )}

          {loadingRank ? (
            <div className="space-y-2.5">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="h-16 rounded-2xl border border-white/[0.06] bg-[#161920] animate-pulse"
                />
              ))}
            </div>
          ) : rankRows.length === 0 ? (
            <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-10 text-center text-sm text-slate-400">
              No leaderboard entries available yet.
            </div>
          ) : (
            <>
              {/* Top 3 Podium Cards */}
              {topThree.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {topThree.map((row, idx) => {
                    const medal = getRankMedal(row.rank);
                    const rewardText = formatRankReward(row.reward, row.rewardType);
                    return (
                      <div
                        key={`podium-${row.rank}-${idx}`}
                        className={`rounded-2xl border p-4 flex sm:flex-col items-center sm:text-center justify-between sm:justify-center gap-3 ${
                          row.rank === 1
                            ? 'border-[#E8B040]/60 bg-[#1D1A12]'
                            : 'border-white/[0.08] bg-[#161920]'
                        }`}
                      >
                        <div className="flex sm:flex-col items-center gap-3 sm:gap-2 min-w-0">
                          <div className="flex items-center gap-1.5 text-xs font-bold font-mono-num text-[#E8B040]">
                            {medal ? (
                              <img src={medal} alt={`#${row.rank}`} className="h-5 w-5 object-contain" />
                            ) : null}
                            <span>Rank #{row.rank}</span>
                          </div>
                          <div className="h-12 w-12 rounded-full border border-white/15 bg-[#12151B] overflow-hidden shrink-0">
                            <AvatarImage
                              src={row.avatar}
                              alt={row.playerName}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-white truncate max-w-[160px]">
                              {row.playerName}
                            </p>
                            {rewardText && (
                              <p className="text-[11px] text-[#81C784] truncate font-mono-num">
                                Prize: {rewardText}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono-num text-sm font-bold text-[#E8B040] shrink-0">
                          <img src={KONG_ASSETS.icBanana} alt="" className="h-4 w-4 object-contain" />
                          <span>{row.totalBanana.toLocaleString()}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Remaining Ranks */}
              {restRanks.length > 0 && (
                <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
                  {restRanks.map((row, idx) => {
                    const rewardText = formatRankReward(row.reward, row.rewardType);
                    return (
                      <div
                        key={`${row.rank}-${row.msisdn}-${idx}`}
                        className="px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <span className="font-mono-num text-sm font-bold w-8 text-center shrink-0 text-slate-400">
                            #{row.rank}
                          </span>
                          <div className="h-10 w-10 rounded-full border border-white/10 bg-[#12151B] overflow-hidden shrink-0">
                            <AvatarImage
                              src={row.avatar}
                              alt={row.playerName}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-white truncate">
                              {row.playerName}
                            </p>
                            {rewardText && (
                              <p className="text-xs text-[#81C784] font-mono-num">
                                Prize: {rewardText}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono-num text-sm font-bold text-[#E8B040] shrink-0">
                          <img src={KONG_ASSETS.icBanana} alt="" className="h-4 w-4 object-contain" />
                          <span>{row.totalBanana.toLocaleString()}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Edit Player Name Modal */}
      {editNameOpen && (
        <div
          onClick={() => setEditNameOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={handleSavePlayerName}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Player Name</h3>
              <button
                type="button"
                onClick={() => setEditNameOpen(false)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <input
              type="text"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              className="w-full min-h-[48px] rounded-xl border border-white/10 bg-[#1E232E] px-4 py-3 text-sm text-white focus:border-[#C8942A] focus:outline-none"
            />
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setEditNameOpen(false)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 px-4 py-2 text-xs font-semibold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingName}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-5 py-2 text-xs font-bold text-[#0C0F14]"
              >
                {savingName ? 'Saving...' : 'Save'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Avatar Picker Bottom Sheet */}
      {avatarModalOpen && (
        <div
          onClick={() => setAvatarModalOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 max-h-[85vh] overflow-y-auto animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Select Kong Avatar</h3>
              <button
                type="button"
                onClick={() => setAvatarModalOpen(false)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {loadingAvatars ? (
              <div className="py-12 flex justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-[#E8B040]" />
              </div>
            ) : avatars.length === 0 ? (
              <p className="text-sm text-slate-400 py-6 text-center">No avatars returned.</p>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {avatars.map((av, idx) => {
                  const isUsing = av.status === 'USING';
                  const isOwned = av.status === 'ACTIVE' || av.status === 'OWNED';
                  return (
                    <button
                      key={`${av.id}-${idx}`}
                      type="button"
                      disabled={buyingAvatarId === av.id || isUsing}
                      onClick={() => handleSelectOrBuyAvatar(av)}
                      className={`rounded-xl border p-2.5 flex flex-col items-center gap-2 transition-all active:scale-95 ${
                        isUsing
                          ? 'border-[#4CAF50] bg-[#18221A]'
                          : 'border-white/10 bg-[#1E232E] hover:border-[#C8942A]'
                      }`}
                    >
                      <AvatarImage
                        src={av.url}
                        alt={av.description || `Avatar ${av.id}`}
                        className="h-14 w-14 rounded-xl object-cover"
                      />
                      <span
                        className={`text-[11px] font-semibold font-mono-num flex items-center gap-1 ${
                          isUsing
                            ? 'text-[#4CAF50]'
                            : isOwned
                            ? 'text-slate-200'
                            : 'text-[#E8B040]'
                        }`}
                      >
                        {buyingAvatarId === av.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : isUsing ? (
                          <>
                            <Check className="h-3 w-3" />
                            <span>Using</span>
                          </>
                        ) : isOwned ? (
                          'Equip'
                        ) : av.price ? (
                          `${av.price.toLocaleString()} Banana`
                        ) : (
                          'Buy'
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Box Result Bottom Sheet */}
      {boxResult && (
        <div
          onClick={() => setBoxResult(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <h3 className="font-display text-lg font-bold text-white">Mystery Box Rewards</h3>
            <ul className="space-y-2 text-sm text-[#E8B040] font-mono-num">
              {boxResult.map((entry, i) => (
                <li
                  key={i}
                  className="rounded-xl border border-white/[0.06] bg-[#1E232E] px-4 py-3 flex items-center gap-3"
                >
                  <img src={entry.icon} alt="" className="h-6 w-6 object-contain shrink-0" />
                  <span>{entry.text}</span>
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => setBoxResult(null)}
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14]"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
