import React, { useState } from 'react';
import { ArrowLeft, Loader2, ShieldCheck } from 'lucide-react';
import { mytelApi } from '../lib/api';
import { KONG_ASSETS } from '../lib/kongAssets';
import { formatMytelPhone } from '../lib/storage';

interface LoginViewProps {
  isAddAccount: boolean;
  onBackToAccounts?: () => void;
  onOtpSent: (params: { phone: string; isRegister: boolean }) => void;
}

export function LoginView({ isAddAccount, onBackToAccounts, onOtpSent }: LoginViewProps) {
  const [phoneInput, setPhoneInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [statusLabel, setStatusLabel] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const normalized = formatMytelPhone(phoneInput);
    if (!normalized || !/^09\d{7,10}$/.test(normalized)) {
      setErrorMsg('Enter a valid Mytel number (09xxxxxxxxx)');
      return;
    }

    setLoading(true);
    setStatusLabel('Checking...');
    try {
      const checkRes = await mytelApi.checkAccount(normalized);
      const errCode = Number(checkRes?.errorCode ?? -1);
      const resultObj = checkRes?.result;
      const isVerify = Boolean(resultObj?.verify);

      if (errCode === 200 && resultObj && isVerify) {
        setStatusLabel('Sending OTP...');
        const otpRes = await mytelApi.getOtp(normalized);
        if (otpRes?.errorCode && Number(otpRes.errorCode) !== 200 && Number(otpRes.errorCode) !== 0) {
          throw new Error(otpRes?.message || 'Failed to send OTP');
        }
        onOtpSent({ phone: normalized, isRegister: false });
      } else {
        setStatusLabel('Registering...');
        const regRes = await mytelApi.registerRequest(normalized);
        if (Number(regRes?.errorCode) !== 200 && Number(regRes?.errorCode) !== 0 && !regRes?.result) {
          throw new Error(regRes?.message || checkRes?.message || 'Account check failed');
        }
        onOtpSent({ phone: normalized, isRegister: true });
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to send OTP');
    } finally {
      setLoading(false);
      setStatusLabel('');
    }
  };

  return (
    <div className="min-h-screen bg-[#0C0F14] flex flex-col justify-center px-4 py-8 sm:py-12 safe-pb">
      <div className="mx-auto w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-stretch">
        {/* Left Visual Sanctuary Panel */}
        <div className="lg:col-span-6 relative overflow-hidden rounded-2xl border border-white/[0.08] bg-[#141820] min-h-[220px] sm:min-h-[260px] flex flex-col justify-between p-6 sm:p-7">
          <img
            src={KONG_ASSETS.heroBanner}
            alt="Kong Island sanctuary"
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0C0F14] via-[#0C0F14]/60 to-black/25" />

          <div className="relative z-10 flex items-center gap-3">
            <img
              src={KONG_ASSETS.brandMark}
              alt="KongPulse"
              referrerPolicy="no-referrer"
              className="h-10 w-10 rounded-xl border border-white/15 object-cover"
            />
            <span className="font-display text-xl font-bold text-white tracking-tight">
              KongPulse
            </span>
          </div>

          <div className="relative z-10 space-y-2 pt-16">
            <p className="text-xs font-medium text-[#E8B040]">
              MyID Account Hub · Kong Island Companion
            </p>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white leading-tight [text-wrap:balance]">
              Manage balances, daily quests, and Kong Island in one place.
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed max-w-md">
              Verify with your Mytel number to sync account balances, loyalty point exchanges, and live Kong Island play sessions.
            </p>
          </div>
        </div>

        {/* Right Sign-in Form */}
        <div className="lg:col-span-6 rounded-2xl border border-white/[0.08] bg-[#141820] p-7 sm:p-9 flex flex-col justify-center">
          {isAddAccount && onBackToAccounts && (
            <button
              type="button"
              onClick={onBackToAccounts}
              className="mb-6 inline-flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors self-start"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to saved accounts
            </button>
          )}

          <div className="space-y-1.5 mb-7">
            <h2 className="font-display text-2xl font-bold text-white">
              {isAddAccount ? 'Add another account' : 'Sign in to play'}
            </h2>
            <p className="text-sm text-slate-400">
              Enter your Mytel number to continue
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label
                htmlFor="phone-input"
                className="block text-xs font-medium text-slate-300"
              >
                Phone Number
              </label>
              <div className="flex items-center rounded-xl border border-white/10 bg-[#1B202B] focus-within:border-[#C8942A] transition-colors">
                <span className="flex items-center gap-2 pl-4 pr-3 py-3 text-sm font-medium text-slate-200 border-r border-white/10 select-none">
                  <span aria-hidden="true">🇲🇲</span>
                  <span className="font-mono-num text-xs text-slate-400">+95</span>
                </span>
                <input
                  id="phone-input"
                  type="tel"
                  inputMode="numeric"
                  autoComplete="tel"
                  placeholder="09xxxxxxxxx"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  disabled={loading}
                  className="w-full bg-transparent px-4 py-3 text-base font-mono-num text-white placeholder:text-slate-500 focus:outline-none"
                />
              </div>
            </div>

            {errorMsg && (
              <div
                role="alert"
                className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300"
              >
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-6 py-3 text-sm font-bold text-[#0C0F14] hover:brightness-105 active:scale-[0.99] transition-all disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>{statusLabel || 'Sending OTP...'}</span>
                </>
              ) : (
                <span>Send OTP</span>
              )}
            </button>
          </form>

          <div className="mt-7 pt-5 border-t border-white/[0.06] flex items-center gap-2.5 text-xs text-slate-400">
            <ShieldCheck className="h-4 w-4 text-[#C8942A] shrink-0" />
            <span>Direct Mytel OTP authentication · Multi-account switching supported</span>
          </div>
        </div>
      </div>
    </div>
  );
}
