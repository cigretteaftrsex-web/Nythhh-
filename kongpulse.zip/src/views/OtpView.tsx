import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { mytelApi } from '../lib/api';
import { decodeJwtSub, upsertAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface OtpViewProps {
  phone: string;
  isRegister: boolean;
  onBack: () => void;
  onSuccess: (account: SavedAccount) => void;
}

export function OtpView({ phone, isRegister, onBack, onSuccess }: OtpViewProps) {
  const [digits, setDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [verifying, setVerifying] = useState(false);
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(60);
  const [errorMsg, setErrorMsg] = useState('');
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = window.setInterval(() => setCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => window.clearInterval(t);
  }, [cooldown]);

  const handleDigitChange = (idx: number, raw: string) => {
    const clean = raw.replace(/\D/g, '');
    if (!clean) {
      setDigits((prev) => {
        const next = [...prev];
        next[idx] = '';
        return next;
      });
      return;
    }

    // Handle paste of full 6-digit code
    if (clean.length > 1) {
      const chars = clean.slice(0, 6).split('');
      setDigits((prev) => {
        const next = [...prev];
        chars.forEach((ch, offset) => {
          if (idx + offset < 6) next[idx + offset] = ch;
        });
        return next;
      });
      const focusIdx = Math.min(5, idx + chars.length);
      inputRefs.current[focusIdx]?.focus();
      return;
    }

    setDigits((prev) => {
      const next = [...prev];
      next[idx] = clean;
      return next;
    });
    if (idx < 5) {
      inputRefs.current[idx + 1]?.focus();
    }
  };

  const handleKeyDown = (idx: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  };

  const handleVerify = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const code = digits.join('');
    if (code.length < 6) {
      setErrorMsg('Please enter all 6 digits');
      return;
    }

    setErrorMsg('');
    setVerifying(true);
    try {
      const res = await mytelApi.validateOtp(phone, code);
      const result = res?.result;
      if (!result?.access_token) {
        throw new Error(res?.message || 'Verification failed');
      }

      const accessToken = String(result.access_token);
      const refreshToken = String(result.refresh_token || '');
      const expiresIn = Number(result.expires_in || 3600);
      const thirdPartyToken = String(result.thirdPartyToken || '');
      const mcuid = thirdPartyToken ? decodeJwtSub(thirdPartyToken) : '';

      let fullName = phone;
      let avatarUrl = '';
      try {
        const custRes = await mytelApi.getCustomer(accessToken);
        const cust = custRes?.result || custRes;
        if (cust?.fullName) fullName = String(cust.fullName);
        if (Array.isArray(cust?.externalRefs)) {
          const av = cust.externalRefs.find((r: any) => r?.type === 'avatar_img');
          if (av?.href) avatarUrl = String(av.href);
        }
      } catch {
        // Fallback to phone if profile fetch fails temporarily
      }

      const account: SavedAccount = {
        phone,
        fullName,
        avatarUrl,
        accessToken,
        refreshToken,
        thirdPartyToken,
        mcuid,
        expiresAt: Date.now() + expiresIn * 1000,
        addedAt: Date.now(),
      };
      upsertAccount(account);
      onSuccess(account);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Verification failed');
    } finally {
      setVerifying(false);
    }
  };

  const handleResend = async () => {
    if (cooldown > 0 || resending) return;
    setResending(true);
    setErrorMsg('');
    try {
      if (isRegister) {
        await mytelApi.registerRequest(phone);
      } else {
        await mytelApi.getOtp(phone);
      }
      setCooldown(60);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to resend OTP');
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0C0F14] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md rounded-2xl border border-white/[0.08] bg-[#141820] p-7 sm:p-9">
        <button
          type="button"
          onClick={onBack}
          className="mb-6 inline-flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Change number
        </button>

        <div className="space-y-1.5 mb-7">
          <h1 className="font-display text-2xl font-bold text-white">Verification</h1>
          <p className="text-sm text-slate-400">
            Enter the 6-digit code sent to{' '}
            <span className="font-mono-num font-semibold text-slate-200">{phone}</span>
          </p>
        </div>

        <form onSubmit={handleVerify} className="space-y-6">
          <div className="grid grid-cols-6 gap-2 sm:gap-2.5">
            {digits.map((digit, i) => (
              <input
                key={i}
                ref={(el) => {
                  inputRefs.current[i] = el;
                }}
                type="text"
                inputMode="numeric"
                autoComplete={i === 0 ? 'one-time-code' : 'off'}
                maxLength={6}
                value={digit}
                onChange={(e) => handleDigitChange(i, e.target.value)}
                onKeyDown={(e) => handleKeyDown(i, e)}
                aria-label={`OTP digit ${i + 1}`}
                className={`min-h-[52px] w-full rounded-xl border text-center text-lg font-bold font-mono-num text-white bg-[#1B202B] focus:outline-none transition-colors ${
                  digit
                    ? 'border-[#C8942A]'
                    : 'border-white/10 focus:border-[#C8942A]'
                }`}
              />
            ))}
          </div>

          {errorMsg && (
            <div
              role="alert"
              className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300"
            >
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={verifying}
            className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-6 py-3 text-sm font-bold text-[#0C0F14] hover:brightness-105 active:scale-[0.99] transition-all disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {verifying ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Verifying...</span>
              </>
            ) : (
              <span>Verify &amp; Login</span>
            )}
          </button>
        </form>

        <div className="mt-6 text-center text-xs text-slate-400">
          <span>Didn&apos;t receive code? </span>
          {cooldown > 0 ? (
            <span className="font-mono-num text-slate-300">Resend in {cooldown}s</span>
          ) : (
            <button
              type="button"
              onClick={handleResend}
              disabled={resending}
              className="font-semibold text-[#E8B040] hover:underline"
            >
              {resending ? 'Sending...' : 'Resend'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
