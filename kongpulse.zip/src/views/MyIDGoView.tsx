import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Compass,
  History,
  Play,
  RefreshCw,
  ShoppingBag,
  Square,
  Trophy,
} from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { GAME_ASSETS, getMyIdGoStatIcon } from '../lib/gameAssets';
import { myidGoApi } from '../lib/gamesApi';
import { getRankMedal } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface MyIDGoViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onBack: () => void;
}

type GoTab = 'play' | 'store' | 'history' | 'rank';

export function MyIDGoView({ account, onAccountUpdated, onBack }: MyIDGoViewProps) {
  const [token, setToken] = useState(account.myidGoToken || '');
  const [tab, setTab] = useState<GoTab>('play');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const [profile, setProfile] = useState<any | null>(null);

  // 10-Step Adventure Bot (slots 5..9 across 10 steps)
  const [isPlaying, setIsPlaying] = useState(false);
  const [autoLoop, setAutoLoop] = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  const [rewardsWon, setRewardsWon] = useState<string[]>([]);
  const stopRef = useRef(false);

  // Store, History, Rank
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCatId, setSelectedCatId] = useState<string>('');
  const [storeItems, setStoreItems] = useState<any[]>([]);
  const [buyingId, setBuyingId] = useState<string | null>(null);
  const [historyRows, setHistoryRows] = useState<any[]>([]);
  const [rankRows, setRankRows] = useState<any[]>([]);

  const ensureSession = useCallback(
    async (force = false): Promise<string> => {
      if (!force && token) return token;
      const res = await myidGoApi.login({
        thirdPartyToken: account.thirdPartyToken,
        mcuid: account.mcuid || account.phone,
        uuid: account.mcuid || account.phone,
        phone: account.phone,
        avatar: account.avatarUrl,
        fullName: account.fullName,
      });
      const tok = res?.token || res?.data?.token || '';
      if (!tok) throw new Error(res?.message || 'MyID Go bootstrap did not return token');
      setToken(tok);
      const updated = updateActiveAccount({ myidGoToken: tok });
      if (updated) onAccountUpdated(updated);
      return tok;
    },
    [account.avatarUrl, account.fullName, account.mcuid, account.phone, account.thirdPartyToken, onAccountUpdated, token]
  );

  const loadProfile = useCallback(async (tok: string) => {
    const res = await myidGoApi.getProfile(tok);
    setProfile(res?.data || res);
  }, []);

  const bootstrap = useCallback(
    async (forceLogin = false) => {
      setLoading(true);
      setErrorMsg('');
      try {
        let tok = await ensureSession(forceLogin);
        try {
          await loadProfile(tok);
        } catch (err) {
          if (err instanceof Error && err.message.includes('401')) {
            tok = await ensureSession(true);
            await loadProfile(tok);
          } else {
            throw err;
          }
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to connect to MyID Go');
      } finally {
        setLoading(false);
      }
    },
    [ensureSession, loadProfile]
  );

  useEffect(() => {
    bootstrap(false);
    return () => {
      stopRef.current = true;
    };
  }, [account.phone]);

  useEffect(() => {
    if (!token) return;
    if (tab === 'store') {
      Promise.allSettled([
        myidGoApi.getStoreCategories(token),
        myidGoApi.getStoreItems(token, selectedCatId || undefined),
      ]).then(([cRes, iRes]) => {
        if (cRes.status === 'fulfilled') {
          const d = cRes.value?.data || cRes.value;
          setCategories(Array.isArray(d) ? d : d?.categories || d?.items || []);
        }
        if (iRes.status === 'fulfilled') {
          const d = iRes.value?.data || iRes.value;
          setStoreItems(Array.isArray(d) ? d : d?.items || d?.products || []);
        }
      });
    } else if (tab === 'history') {
      myidGoApi
        .getHistory(token, 30)
        .then((res) => {
          const d = res?.data || res;
          setHistoryRows(Array.isArray(d) ? d : d?.items || d?.rewards || []);
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load history'));
    } else if (tab === 'rank') {
      myidGoApi
        .getLeaderboard(token)
        .then((res) => {
          const d = res?.data || res;
          setRankRows(Array.isArray(d) ? d : d?.ranks || d?.leaderboard || []);
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load rank'));
    }
  }, [tab, token, selectedCatId]);

  const stopAdventure = async () => {
    stopRef.current = true;
    setIsPlaying(false);
    if (token) {
      await myidGoApi.stopGame(token).catch(() => {});
    }
  };

  const handleStartAdventure = async () => {
    if (!token || isPlaying) return;
    stopRef.current = false;
    setIsPlaying(true);
    setErrorMsg('');
    setStatusMsg('');
    setRewardsWon([]);

    try {
      do {
        setStepIdx(0);
        const startRes = await myidGoApi.startGame(token);
        if (startRes?.success === false) {
          throw new Error(startRes?.message || 'Unable to start MyID Go run');
        }

        const collected: string[] = [];
        for (let step = 0; step < 10; step++) {
          if (stopRef.current) break;
          setStepIdx(step + 1);
          const slotIndex = 5 + (step % 5);
          const rw = await myidGoApi.claimRewardStep(token, slotIndex);
          const rewardText =
            rw?.data?.rewardName || rw?.data?.name || rw?.message || `Slot ${slotIndex} claimed`;
          collected.push(String(rewardText));
          setRewardsWon([...collected]);
          await new Promise((r) => window.setTimeout(r, 750));
        }

        await myidGoApi.stopGame(token).catch(() => {});
        await loadProfile(token);
        setStatusMsg('10-Step MyID Go Adventure finished!');
        if (stopRef.current || !autoLoop) break;
        await new Promise((r) => window.setTimeout(r, 600));
      } while (!stopRef.current && autoLoop);
    } catch (err) {
      if (!stopRef.current) {
        setErrorMsg(err instanceof Error ? err.message : 'MyID Go run failed');
      }
    } finally {
      setIsPlaying(false);
    }
  };

  const turns = Number(profile?.turn ?? profile?.totalTurn ?? profile?.turns ?? 0);
  const hammers = Number(profile?.hammer ?? profile?.hammers ?? 0);
  const diamonds = Number(profile?.diamond ?? profile?.diamonds ?? 0);
  const jackfruits = Number(profile?.jackfruit ?? profile?.jackfruits ?? 0);
  const mixes = Number(profile?.mix ?? profile?.mixes ?? 0);

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="MyID Go"
        subtitle="10-Step Reward Runner · Item Stats · Store · Leaderboard"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => bootstrap(true)}
            disabled={loading}
            aria-label="Sync MyID Go"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Profile + 5-Stat Strip (turns, hammer, diamond, jackfruit, mix) */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 space-y-4">
        <div className="flex items-center gap-3.5">
          <img
            src={profile?.avatar || GAME_ASSETS.myidGoLogo}
            alt="MyID Go"
            referrerPolicy="no-referrer"
            className="h-12 w-12 rounded-2xl border border-[#C8942A]/40 object-cover shrink-0"
          />
          <div className="min-w-0">
            <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
              {profile?.fullname || profile?.playerName || account.fullName || account.phone}
            </h2>
            <p className="text-xs font-mono-num text-slate-400">
              {profile?.phone || account.phone} · Points:{' '}
              <span className="text-[#E8B040] font-bold">
                {Number(profile?.point ?? profile?.score ?? 0).toLocaleString()}
              </span>
            </p>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-2 pt-3 border-t border-white/[0.06]">
          {[
            { label: 'Turn', value: turns, icon: GAME_ASSETS.icStatTurn },
            { label: 'Hammer', value: hammers, icon: GAME_ASSETS.icStatHammer },
            { label: 'Diamond', value: diamonds, icon: GAME_ASSETS.icStatDiamond },
            { label: 'Jackfruit', value: jackfruits, icon: GAME_ASSETS.icStatJackfruit },
            { label: 'Mix', value: mixes, icon: GAME_ASSETS.icStatMix },
          ].map((s) => (
            <div key={s.label} className="flex flex-col items-center text-center gap-1 py-1">
              <img src={s.icon} alt={s.label} className="h-6 w-6 object-contain" />
              <span className="font-mono-num text-xs font-bold text-white">
                {loading ? '--' : s.value}
              </span>
              <span className="text-[10px] text-slate-400 truncate max-w-full">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Horizontal Android Tab Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'play', label: 'Adventure', icon: Compass },
          { id: 'store', label: 'Store', icon: ShoppingBag },
          { id: 'history', label: 'History', icon: History },
          { id: 'rank', label: 'Rank', icon: Trophy },
        ].map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as GoTab)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 flex items-center gap-2 border transition-all ${
                active
                  ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                  : 'border-white/10 bg-[#161920] text-slate-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusMsg}</span>
          <button type="button" onClick={() => setStatusMsg('')} className="text-xs underline">
            OK
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button type="button" onClick={() => setErrorMsg('')} className="text-xs underline">
            Close
          </button>
        </div>
      )}

      {tab === 'play' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-display text-lg font-bold text-white">10-Step Auto Adventure</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Auto-claims reward slots 5–9 across 10 adventure steps
              </p>
            </div>
            <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <span>Auto Loop</span>
              <button
                type="button"
                role="switch"
                aria-checked={autoLoop}
                onClick={() => setAutoLoop((v) => !v)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoLoop ? 'bg-[#4CAF50]' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    autoLoop ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </label>
          </div>

          {isPlaying && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-mono-num">
                <span className="text-[#E8B040]">Step {stepIdx} / 10</span>
                <span>{stepIdx * 10}%</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-[#12151B] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all"
                  style={{ width: `${stepIdx * 10}%` }}
                />
              </div>
            </div>
          )}

          {rewardsWon.length > 0 && (
            <div className="rounded-xl border border-white/[0.06] bg-[#12151B] p-3 max-h-40 overflow-y-auto space-y-1 text-xs text-slate-300 font-mono-num">
              {rewardsWon.map((rw, idx) => (
                <div key={`go-rw-${idx}`}>• Step {idx + 1}: {rw}</div>
              ))}
            </div>
          )}

          {!isPlaying ? (
            <button
              type="button"
              disabled={loading || !token}
              onClick={handleStartAdventure}
              className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Play className="h-4 w-4 fill-current" />
              <span>Start 10-Step Run</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={stopAdventure}
              className="w-full min-h-[48px] rounded-xl bg-red-600 text-sm font-bold text-white flex items-center justify-center gap-2"
            >
              <Square className="h-4 w-4 fill-current" />
              <span>Stop</span>
            </button>
          )}
        </div>
      )}

      {tab === 'store' && (
        <div className="space-y-4">
          {categories.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => setSelectedCatId('')}
                className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold border whitespace-nowrap ${
                  selectedCatId === ''
                    ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                    : 'border-white/10 bg-[#161920] text-slate-300'
                }`}
              >
                All
              </button>
              {categories.map((c, idx) => {
                const cid = String(c.id ?? c.category_id ?? idx);
                return (
                  <button
                    key={`go-cat-${cid}-${idx}`}
                    type="button"
                    onClick={() => setSelectedCatId(cid)}
                    className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold border whitespace-nowrap ${
                      selectedCatId === cid
                        ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                        : 'border-white/10 bg-[#161920] text-slate-300'
                    }`}
                  >
                    {c.name || c.title || `Cat ${cid}`}
                  </button>
                );
              })}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {storeItems.length === 0 ? (
              <div className="sm:col-span-2 lg:col-span-3 rounded-2xl border border-white/[0.08] bg-[#161920] p-8 text-center text-sm text-slate-400">
                No MyID Go store items returned.
              </div>
            ) : (
              storeItems.map((it, idx) => {
                const iid = String(it.id ?? it.code ?? idx);
                return (
                  <div
                    key={`go-store-${iid}-${idx}`}
                    className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={getMyIdGoStatIcon(it.name || it.type || '')}
                        alt=""
                        className="h-9 w-9 object-contain shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{it.name || iid}</p>
                        <p className="text-xs font-mono-num text-[#E8B040]">
                          {Number(it.price ?? it.point ?? 0).toLocaleString()} {it.currency || 'Pts'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={buyingId === iid}
                      onClick={async () => {
                        if (!token) return;
                        setBuyingId(iid);
                        try {
                          const res = await myidGoApi.buyStoreItem(token, {
                            itemId: it.id,
                            code: it.code,
                          });
                          if (res?.success === false) throw new Error(res?.message || 'Buy failed');
                          setStatusMsg(`Purchased ${it.name || iid}`);
                          await loadProfile(token);
                        } catch (err) {
                          setErrorMsg(err instanceof Error ? err.message : 'Buy failed');
                        } finally {
                          setBuyingId(null);
                        }
                      }}
                      className="min-h-[42px] shrink-0 rounded-xl bg-[#C8942A] px-3.5 text-xs font-bold text-[#0C0F14]"
                    >
                      {buyingId === iid ? '...' : 'Buy'}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
          {historyRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No reward history yet.</div>
          ) : (
            historyRows.map((h, idx) => (
              <div key={`go-hist-${h.id ?? idx}-${idx}`} className="p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white truncate">
                    {h.rewardName || h.name || h.title || 'MyID Go Reward'}
                  </p>
                  <p className="text-xs text-slate-400">{h.createdAt || h.created_at || h.date || ''}</p>
                </div>
                <span className="font-mono-num text-xs font-bold text-[#E8B040]">
                  {h.value || h.amount || h.status || ''}
                </span>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'rank' && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
          {rankRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-400">No ranking rows yet.</div>
          ) : (
            rankRows.map((r, idx) => {
              const rank = Number(r.rank ?? idx + 1);
              const medal = getRankMedal(rank);
              return (
                <div key={`go-rank-${rank}-${idx}`} className="px-4 py-3.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {medal ? (
                      <img src={medal} alt="" className="h-6 w-6 object-contain shrink-0" />
                    ) : (
                      <span className="w-6 text-center font-mono-num text-xs font-bold text-slate-400">
                        #{rank}
                      </span>
                    )}
                    <p className="text-sm font-semibold text-white truncate">
                      {r.fullname || r.playerName || r.phone || 'Explorer'}
                    </p>
                  </div>
                  <span className="font-mono-num text-sm font-bold text-[#E8B040]">
                    {Number(r.score ?? r.point ?? r.points ?? 0).toLocaleString()}
                  </span>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
