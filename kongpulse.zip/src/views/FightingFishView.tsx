import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  Fish,
  Loader2,
  Pencil,
  Play,
  RefreshCw,
  ShoppingBag,
  Square,
  Swords,
  Trophy,
  X,
} from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { GAME_ASSETS, getFishPowerupIcon } from '../lib/gameAssets';
import { fishioApi } from '../lib/gamesApi';
import { getPackageAsset, getRankMedal } from '../lib/kongAssets';
import { updateActiveAccount } from '../lib/storage';
import type { SavedAccount } from '../types';

interface FightingFishViewProps {
  account: SavedAccount;
  onAccountUpdated: (account: SavedAccount) => void;
  onBack: () => void;
}

type FishTab = 'play' | 'shop' | 'tasks' | 'rank';

export function FightingFishView({ account, onAccountUpdated, onBack }: FightingFishViewProps) {
  const [jwt, setJwt] = useState(account.fishioToken || '');
  const [refreshTok, setRefreshTok] = useState(account.fishioRefreshToken || '');
  const [tab, setTab] = useState<FishTab>('play');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  const [userInfo, setUserInfo] = useState<any | null>(null);

  // WS Runner State (Story & PvP with server HMAC-SHA256)
  const [gameMode, setGameMode] = useState<'game' | 'pvp'>('game');
  const [isPlaying, setIsPlaying] = useState(false);
  const [autoLoop, setAutoLoop] = useState(false);
  const [wsStatus, setWsStatus] = useState('Idle');
  const [elapsedSec, setElapsedSec] = useState(0);
  const [matchCount, setMatchCount] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const stopRef = useRef(false);

  // Shop
  const [shopItems, setShopItems] = useState<any[]>([]);
  const [packages, setPackages] = useState<any[]>([]);
  const [buyingCode, setBuyingCode] = useState<string | null>(null);

  // Tasks & Achievements
  const [achievements, setAchievements] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [claimingId, setClaimingId] = useState<string | null>(null);

  // Rank
  const [rankType, setRankType] = useState<'WEEK' | 'MONTH'>('WEEK');
  const [rankRows, setRankRows] = useState<any[]>([]);

  // Rename Modal
  const [editNameOpen, setEditNameOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState('');

  const ensureSession = useCallback(
    async (force = false): Promise<string> => {
      if (!force && jwt) return jwt;
      if (force && refreshTok) {
        try {
          const refRes = await fishioApi.refresh(refreshTok);
          const nextTok = refRes?.data?.accessToken || refRes?.accessToken;
          if (nextTok) {
            setJwt(nextTok);
            const updated = updateActiveAccount({ fishioToken: nextTok });
            if (updated) onAccountUpdated(updated);
            return nextTok;
          }
        } catch {
          // fallback to gateway login
        }
      }
      const res = await fishioApi.login({
        thirdPartyToken: account.thirdPartyToken,
        mcuid: account.mcuid || account.phone,
        uuid: account.mcuid || account.phone,
        phone: account.phone,
        avatar: account.avatarUrl,
        fullName: account.fullName,
      });
      const tok = res?.data?.accessToken || res?.accessToken || res?.token || '';
      const rTok = res?.data?.refreshToken || res?.refreshToken || '';
      if (!tok) throw new Error(res?.message || 'Fighting Fish login failed');
      setJwt(tok);
      setRefreshTok(rTok);
      const updated = updateActiveAccount({
        fishioToken: tok,
        fishioRefreshToken: rTok || undefined,
      });
      if (updated) onAccountUpdated(updated);
      return tok;
    },
    [account.avatarUrl, account.fullName, account.mcuid, account.phone, account.thirdPartyToken, jwt, onAccountUpdated, refreshTok]
  );

  const loadInfo = useCallback(async (token: string) => {
    const res = await fishioApi.getUserInfo(token);
    setUserInfo(res?.data || res);
  }, []);

  const bootstrap = useCallback(
    async (forceLogin = false) => {
      setLoading(true);
      setErrorMsg('');
      try {
        let tok = await ensureSession(forceLogin);
        try {
          await loadInfo(tok);
        } catch (err) {
          if (err instanceof Error && err.message.includes('401')) {
            tok = await ensureSession(true);
            await loadInfo(tok);
          } else {
            throw err;
          }
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to connect to Fighting Fish');
      } finally {
        setLoading(false);
      }
    },
    [ensureSession, loadInfo]
  );

  useEffect(() => {
    bootstrap(false);
    return () => {
      stopRef.current = true;
      wsRef.current?.close();
    };
  }, [account.phone]);

  useEffect(() => {
    if (!jwt) return;
    if (tab === 'shop') {
      Promise.allSettled([
        fishioApi.getShopItems(jwt, 'GEM'),
        fishioApi.getPackages(jwt, 'ALL'),
      ]).then(([sRes, pRes]) => {
        if (sRes.status === 'fulfilled') {
          const d = sRes.value?.data || sRes.value;
          setShopItems(Array.isArray(d) ? d : d?.items || d?.listShop || []);
        }
        if (pRes.status === 'fulfilled') {
          const d = pRes.value?.data || pRes.value;
          setPackages(Array.isArray(d) ? d : d?.listPackage || []);
        }
      });
    } else if (tab === 'tasks') {
      Promise.allSettled([
        fishioApi.getAchievements(jwt),
        fishioApi.getTasks(jwt, 'DAILY'),
      ]).then(([aRes, tRes]) => {
        if (aRes.status === 'fulfilled') {
          const d = aRes.value?.data || aRes.value;
          setAchievements(Array.isArray(d) ? d : d?.list || []);
        }
        if (tRes.status === 'fulfilled') {
          const d = tRes.value?.data || tRes.value;
          setTasks(Array.isArray(d) ? d : d?.list || []);
        }
      });
    } else if (tab === 'rank') {
      fishioApi
        .getLeaderboard(jwt, rankType)
        .then((res) => {
          const d = res?.data || res;
          setRankRows(Array.isArray(d) ? d : d?.ranks || d?.list || []);
        })
        .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Unable to load leaderboard'));
    }
  }, [tab, jwt, rankType]);

  const stopGame = () => {
    stopRef.current = true;
    wsRef.current?.close();
    wsRef.current = null;
    setIsPlaying(false);
    setWsStatus('Stopped');
  };

  const runFishMatch = async (token: string, mode: 'game' | 'pvp'): Promise<void> => {
    return new Promise<void>((resolve, reject) => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(
        `${proto}//${window.location.host}/ws/fishio?mode=${mode}&token=${encodeURIComponent(token)}`
      );
      wsRef.current = ws;

      let seq = 1;
      let sessionId = '';
      let sessionToken = '';
      let matchTimer: number | null = null;
      let tickTimer: number | null = null;
      const startedAt = Date.now();

      const cleanup = () => {
        if (matchTimer) window.clearTimeout(matchTimer);
        if (tickTimer) window.clearInterval(tickTimer);
        try {
          ws.close();
        } catch {
          // ignore
        }
        if (wsRef.current === ws) wsRef.current = null;
      };

      const sendEnvelope = (type: string, payload: Record<string, unknown>, sign = false) => {
        const ts = Date.now();
        const env: any = {
          type,
          sequence: seq++,
          timestamp: ts,
          payload,
        };
        if (sessionId) env.sessionId = sessionId;
        if (sign && sessionToken) env._signWithToken = sessionToken;
        ws.send(JSON.stringify(env));
      };

      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(String(evt.data || '{}'));
          if (msg.type === 'BRIDGE_OPEN') {
            setWsStatus(mode === 'pvp' ? 'Joining PvP Arena...' : 'Creating Story Session...');
            if (mode === 'pvp') {
              sendEnvelope('JOIN_PVP', {
                photonRoomId: `room_${Date.now()}`,
                fishId: 'FISH_1',
                swordId: 'SWORD_3',
                trailId: 'TRAIL_1',
              });
            }
            return;
          }
          if (msg.type === 'SESSION_CREATED') {
            sessionId = String(msg.sessionId || msg.payload?.sessionId || '');
            sessionToken = String(msg.sessionToken || msg.payload?.sessionToken || '');
            const levelConfig = msg.payload?.levelConfig || {};
            setWsStatus(mode === 'pvp' ? 'PvP Battle Active (25s)...' : 'Story Battle Active (25s)...');

            if (mode === 'game') {
              sendEnvelope('START_ACTION', {
                mode: levelConfig.mode || 'NORMAL',
                fishId: 'FISH_1',
              });
            }

            tickTimer = window.setInterval(() => {
              const sec = Math.round((Date.now() - startedAt) / 1000);
              setElapsedSec(sec);
              if (sec % 5 === 0) {
                sendEnvelope('GAMEPLAY_EVENT', {
                  eventType: mode === 'pvp' ? 'EAT_MEAT' : 'EAT_FOOD',
                  fishType: 'SMALL',
                  playerExpAfter: sec * 40,
                });
              }
            }, 1000);

            matchTimer = window.setTimeout(() => {
              const elapsed = Date.now() - startedAt;
              if (mode === 'pvp') {
                sendEnvelope(
                  'END_MATCH',
                  {
                    result: 'WIN',
                    rank: 1,
                    rankPoint: 25,
                    killCount: 4,
                    maxComboKill: 2,
                    isDead: false,
                    clientElapsed: elapsed,
                    endReason: 'PLAYER_DEAD',
                    aliveAiFish: [],
                  },
                  true
                );
              } else {
                sendEnvelope(
                  'END_GAME',
                  {
                    result: 'WIN',
                    clientElapsed: elapsed,
                  },
                  true
                );
              }
            }, 25000);
            return;
          }
          if (msg.type === 'GAME_RESULT' || msg.type === 'MATCH_RESULT') {
            cleanup();
            resolve();
            return;
          }
          if (msg.type === 'BRIDGE_ERROR' || msg.type === 'ERROR') {
            cleanup();
            reject(new Error(msg.message || msg.payload?.message || 'Fish.io WS error'));
          }
        } catch {
          // ignore non-json frames
        }
      };

      ws.onerror = () => {
        cleanup();
        reject(new Error('Fish.io WebSocket error'));
      };
    });
  };

  const handleStartMatch = async () => {
    if (!jwt || isPlaying) return;
    stopRef.current = false;
    setIsPlaying(true);
    setErrorMsg('');
    setMatchCount(0);

    try {
      do {
        setElapsedSec(0);
        await runFishMatch(jwt, gameMode);
        setMatchCount((c) => c + 1);
        await loadInfo(jwt);
        setStatusMsg(`${gameMode === 'pvp' ? 'PvP Arena' : 'Story'} match finished & signed!`);
        if (stopRef.current || !autoLoop) break;
        await new Promise((r) => window.setTimeout(r, 700));
      } while (!stopRef.current && autoLoop);
    } catch (err) {
      if (!stopRef.current) {
        setErrorMsg(err instanceof Error ? err.message : 'Match failed');
      }
    } finally {
      setIsPlaying(false);
      setWsStatus('Idle');
    }
  };

  const coins = Number(userInfo?.totalCoin ?? userInfo?.coin ?? 0);
  const gems = Number(userInfo?.totalGem ?? userInfo?.gem ?? 0);
  const tickets = Number(userInfo?.totalTicket ?? userInfo?.ticket ?? 0);

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Fighting Fish"
        subtitle="HMAC-SHA256 Signed Story & PvP Arena · Power-Ups · Shop"
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={() => bootstrap(true)}
            disabled={loading}
            aria-label="Sync Fighting Fish"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-300 hover:text-white active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Profile + Currency */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <img
              src={userInfo?.avatar || GAME_ASSETS.fightingFishLogo}
              alt="Fighting Fish"
              referrerPolicy="no-referrer"
              className="h-12 w-12 rounded-2xl border border-[#C8942A]/40 object-cover shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
                  {userInfo?.playerName || account.fullName || account.phone}
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    setNameDraft(userInfo?.playerName || '');
                    setEditNameOpen(true);
                  }}
                  aria-label="Edit Fighting Fish name"
                  className="h-8 w-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-[#E8B040]"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="text-xs font-mono-num text-slate-400">{userInfo?.msisdn || account.phone}</p>
            </div>
          </div>
          <span className="text-xs font-mono-num text-slate-400">
            {isPlaying ? `${elapsedSec}s` : `Matches: ${matchCount}`}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2.5 sm:gap-3 pt-2 border-t border-white/[0.06]">
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icCoinFf} alt="Coins" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Coins</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-[#E8B040] truncate">
                {loading ? '--' : coins.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icGemFf} alt="Gems" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Gems</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-sky-400 truncate">
                {loading ? '--' : gems.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-[#12151B] border border-white/[0.06] px-3 py-2.5 flex items-center gap-2.5">
            <img src={GAME_ASSETS.icTicketFf} alt="Ticket" className="h-6 w-6 object-contain shrink-0" />
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400">Tickets</p>
              <p className="font-mono-num text-sm sm:text-base font-bold text-white truncate">
                {loading ? '--' : tickets.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Android Tab Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'play', label: 'Arena', icon: Fish },
          { id: 'shop', label: 'Shop', icon: ShoppingBag },
          { id: 'tasks', label: 'Tasks', icon: Check },
          { id: 'rank', label: 'Rank', icon: Trophy },
        ].map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as FishTab)}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 flex items-center gap-2 border transition-all ${
                active
                  ? 'border-[#E8B040] bg-[#C8942A] text-[#0C0F14]'
                  : 'border-white/10 bg-[#161920] text-slate-300'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs text-[#81C784] flex items-center justify-between gap-3">
          <span>{statusMsg}</span>
          <button type="button" onClick={() => setStatusMsg('')} className="text-xs underline">
            OK
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300 flex items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button type="button" onClick={() => setErrorMsg('')} className="text-xs underline">
            Close
          </button>
        </div>
      )}

      {/* TAB: ARENA RUNNER */}
      {tab === 'play' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="inline-flex rounded-xl border border-white/10 bg-[#12151B] p-1">
                <button
                  type="button"
                  disabled={isPlaying}
                  onClick={() => setGameMode('game')}
                  className={`min-h-[40px] px-4 rounded-lg text-xs font-bold flex items-center gap-1.5 ${
                    gameMode === 'game' ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                  }`}
                >
                  <Fish className="h-3.5 w-3.5" />
                  <span>Story Mode</span>
                </button>
                <button
                  type="button"
                  disabled={isPlaying}
                  onClick={() => setGameMode('pvp')}
                  className={`min-h-[40px] px-4 rounded-lg text-xs font-bold flex items-center gap-1.5 ${
                    gameMode === 'pvp' ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                  }`}
                >
                  <Swords className="h-3.5 w-3.5" />
                  <span>PvP Arena</span>
                </button>
              </div>

              <label className="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                <span>Auto Loop</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={autoLoop}
                  onClick={() => setAutoLoop((v) => !v)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    autoLoop ? 'bg-[#4CAF50]' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      autoLoop ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </label>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Status: <strong className="text-[#E8B040]">{wsStatus}</strong></span>
              <span className="font-mono-num">{elapsedSec}s / 25s</span>
            </div>

            {isPlaying && (
              <div className="h-2.5 w-full rounded-full bg-[#12151B] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all"
                  style={{ width: `${Math.min(100, Math.round((elapsedSec / 25) * 100))}%` }}
                />
              </div>
            )}

            {!isPlaying ? (
              <button
                type="button"
                disabled={loading || !jwt}
                onClick={handleStartMatch}
                className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>{gameMode === 'pvp' ? 'Start Signed PvP Match' : 'Start Signed Story Match'}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={stopGame}
                className="w-full min-h-[48px] rounded-xl bg-red-600 text-sm font-bold text-white flex items-center justify-center gap-2"
              >
                <Square className="h-4 w-4 fill-current" />
                <span>Stop Match</span>
              </button>
            )}
          </div>

          {/* Power-ups Strip using authentic APK assets */}
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Fish.io Boosters</h3>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
              {[
                { label: 'Shield', icon: GAME_ASSETS.icFfShield, key: 'shield' },
                { label: 'Speed Up', icon: GAME_ASSETS.icFfSpeedup, key: 'speed' },
                { label: 'Magnet', icon: GAME_ASSETS.icFfMagnetism, key: 'magnet' },
                { label: 'Multi Food', icon: GAME_ASSETS.icFfMultifood, key: 'multifood' },
                { label: 'Revive', icon: GAME_ASSETS.icFfRevive, key: 'revive' },
                { label: 'Viewport+', icon: GAME_ASSETS.icFfViewport, key: 'viewport' },
              ].map((b) => (
                <div
                  key={b.key}
                  className="rounded-xl border border-white/[0.06] bg-[#12151B] p-2.5 flex flex-col items-center text-center gap-1.5"
                >
                  <img src={b.icon} alt={b.label} className="h-8 w-8 object-contain" />
                  <span className="text-[11px] font-medium text-slate-200">{b.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB: SHOP */}
      {tab === 'shop' && (
        <div className="space-y-5">
          {packages.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Ticket Packages</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {packages.map((pkg, idx) => (
                  <div
                    key={`ff-pkg-${pkg.code ?? idx}-${idx}`}
                    className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img src={getPackageAsset(pkg.code || pkg.name || '')} alt="" className="h-10 w-10 object-contain shrink-0" />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{pkg.name || pkg.code}</p>
                        <p className="text-xs font-mono-num text-[#E8B040]">
                          {Number(pkg.price ?? 0).toLocaleString()} Ks
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={buyingCode === pkg.code}
                      onClick={async () => {
                        if (!jwt) return;
                        setBuyingCode(pkg.code);
                        try {
                          const res = await fishioApi.buyPackage(jwt, pkg.code);
                          if (res?.success === false) throw new Error(res?.message || 'Buy failed');
                          setStatusMsg(`Purchased ${pkg.code}`);
                          await loadInfo(jwt);
                        } catch (err) {
                          setErrorMsg(err instanceof Error ? err.message : 'Buy failed');
                        } finally {
                          setBuyingCode(null);
                        }
                      }}
                      className="min-h-[42px] shrink-0 rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 text-xs font-bold text-[#0C0F14]"
                    >
                      {buyingCode === pkg.code ? '...' : 'Buy'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Gem Item Shop</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {shopItems.map((item, idx) => {
                const code = String(item.code || item.id || idx);
                return (
                  <div
                    key={`ff-item-${code}-${idx}`}
                    className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={getFishPowerupIcon(item.code || item.name || '')}
                        alt=""
                        className="h-9 w-9 object-contain shrink-0"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">{item.name || code}</p>
                        <p className="text-xs font-mono-num text-[#E8B040]">
                          {Number(item.price ?? 0).toLocaleString()} Gems
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={buyingCode === code}
                      onClick={async () => {
                        if (!jwt) return;
                        setBuyingCode(code);
                        try {
                          const price = Number(item.price ?? 0);
                          const res = await fishioApi.buyShopItem(jwt, {
                            code: item.code || code,
                            value: Number(item.value ?? 1),
                            quantity: 1,
                            amount: price,
                          });
                          if (res?.success === false) throw new Error(res?.message || 'Buy failed');
                          setStatusMsg(`Purchased ${item.name || code}`);
                          await loadInfo(jwt);
                        } catch (err) {
                          setErrorMsg(err instanceof Error ? err.message : 'Buy failed');
                        } finally {
                          setBuyingCode(null);
                        }
                      }}
                      className="min-h-[42px] shrink-0 rounded-xl border border-[#C8942A]/40 bg-[#C8942A]/15 px-3.5 text-xs font-bold text-[#E8B040]"
                    >
                      {buyingCode === code ? '...' : 'Buy'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB: TASKS */}
      {tab === 'tasks' && (
        <div className="space-y-4">
          {[
            { label: 'Daily Tasks', rows: tasks, kind: 'task' },
            { label: 'Achievements', rows: achievements, kind: 'ach' },
          ].map((sec) => (
            <div key={sec.kind} className="space-y-2">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{sec.label}</h3>
              <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
                {sec.rows.length === 0 ? (
                  <p className="p-4 text-xs text-slate-400">No items available.</p>
                ) : (
                  sec.rows.map((r, idx) => {
                    const id = String(r.id ?? idx);
                    const claimed = r.claimed === true || r.status === 'CLAIMED';
                    return (
                      <div key={`${sec.kind}-${id}-${idx}`} className="p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-white truncate">
                            {r.name || r.title || r.description || `Task #${id}`}
                          </p>
                          <p className="text-xs font-mono-num text-slate-400">
                            +{r.reward ?? r.value ?? 1} {r.typeItem || ''}
                          </p>
                        </div>
                        <button
                          type="button"
                          disabled={claimed || claimingId === `${sec.kind}-${id}`}
                          onClick={async () => {
                            if (!jwt) return;
                            setClaimingId(`${sec.kind}-${id}`);
                            try {
                              if (sec.kind === 'task') await fishioApi.claimTask(jwt, r.id);
                              else await fishioApi.claimAchievement(jwt, r.id);
                              setStatusMsg('Reward claimed!');
                              await loadInfo(jwt);
                            } catch (err) {
                              setErrorMsg(err instanceof Error ? err.message : 'Claim failed');
                            } finally {
                              setClaimingId(null);
                            }
                          }}
                          className="min-h-[40px] shrink-0 rounded-xl bg-[#C8942A] px-3.5 text-xs font-bold text-[#0C0F14] disabled:opacity-45"
                        >
                          {claimingId === `${sec.kind}-${id}` ? '...' : claimed ? 'Done' : 'Claim'}
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB: RANK */}
      {tab === 'rank' && (
        <div className="space-y-3">
          <div className="inline-flex rounded-xl border border-white/10 bg-[#141820] p-1">
            {(['WEEK', 'MONTH'] as const).map((rt) => (
              <button
                key={rt}
                type="button"
                onClick={() => setRankType(rt)}
                className={`min-h-[40px] px-4 rounded-lg text-xs font-semibold ${
                  rankType === rt ? 'bg-[#C8942A] text-[#0C0F14]' : 'text-slate-400'
                }`}
              >
                {rt === 'WEEK' ? 'Weekly' : 'Monthly'}
              </button>
            ))}
          </div>
          <div className="rounded-2xl border border-white/[0.08] bg-[#161920] divide-y divide-white/[0.06]">
            {rankRows.length === 0 ? (
              <p className="p-8 text-center text-sm text-slate-400">No leaderboard rows yet.</p>
            ) : (
              rankRows.map((row, idx) => {
                const rank = Number(row.order ?? row.rank ?? idx + 1);
                const medal = getRankMedal(rank);
                return (
                  <div key={`ff-rank-${rank}-${idx}`} className="px-4 py-3.5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {medal ? (
                        <img src={medal} alt="" className="h-6 w-6 object-contain shrink-0" />
                      ) : (
                        <span className="w-6 text-center font-mono-num text-xs font-bold text-slate-400">
                          #{rank}
                        </span>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {row.playerName || row.msisdn || 'Player'}
                        </p>
                        <p className="text-xs font-mono-num text-slate-400">{row.msisdn || ''}</p>
                      </div>
                    </div>
                    <span className="font-mono-num text-sm font-bold text-[#E8B040]">
                      {Number(row.score ?? row.coin ?? 0).toLocaleString()}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Rename Modal */}
      {editNameOpen && (
        <div
          onClick={() => setEditNameOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={async (e) => {
              e.preventDefault();
              if (!jwt || !nameDraft.trim()) return;
              await fishioApi.updatePlayerName(jwt, nameDraft.trim());
              setEditNameOpen(false);
              await loadInfo(jwt);
            }}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto" />
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Fish.io Name</h3>
              <button type="button" onClick={() => setEditNameOpen(false)} className="h-9 w-9 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>
            <input
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              className="w-full min-h-[48px] rounded-xl border border-white/10 bg-[#12151B] px-4 text-sm text-white"
            />
            <button
              type="submit"
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14]"
            >
              Save
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
