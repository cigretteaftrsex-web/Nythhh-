import React, { useCallback, useEffect, useState } from 'react';
import { Check, ChevronRight, Gift, Loader2, Lock, RefreshCw, Sparkles, X } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { mytelApi } from '../lib/api';
import { KONG_ASSETS } from '../lib/kongAssets';
import type { DailyHl2Package, DailyQuestItem, SavedAccount } from '../types';

interface DailyClaimViewProps {
  account: SavedAccount;
  onBack: () => void;
}

function getClaimedMiniKey(phone: string, configCode: string): string {
  return `kp_mini_claimed_${phone}_${configCode}`;
}

function isMiniClaimedLocally(phone: string, configCode?: string): boolean {
  if (!configCode) return false;
  try {
    return window.localStorage.getItem(getClaimedMiniKey(phone, configCode)) === '1';
  } catch {
    return false;
  }
}

function markMiniClaimedLocally(phone: string, configCode?: string) {
  if (!configCode) return;
  try {
    window.localStorage.setItem(getClaimedMiniKey(phone, configCode), '1');
  } catch {
    // ignore storage quota errors
  }
}

function extractApplyRange(applyTime?: string): string {
  if (!applyTime) return '';
  const match = applyTime.match(/(\d{1,2}\/\d{1,2}\/\d{2,4}\s*-\s*\d{1,2}\/\d{1,2}\/\d{2,4})/);
  return match ? match[1] : applyTime;
}

export function DailyClaimView({ account, onBack }: DailyClaimViewProps) {
  const [loading, setLoading] = useState(true);
  const [claimingDaily, setClaimingDaily] = useState(false);
  const [claimingMiniId, setClaimingMiniId] = useState<string | null>(null);
  const [headerDate, setHeaderDate] = useState('');
  const [totalPoints, setTotalPoints] = useState(0);
  const [dailyQuest, setDailyQuest] = useState<DailyQuestItem | null>(null);
  const [grandQuest, setGrandQuest] = useState<DailyQuestItem | null>(null);
  const [miniQuests, setMiniQuests] = useState<DailyQuestItem[]>([]);
  const [hl2Pkg, setHl2Pkg] = useState<DailyHl2Package | null>(null);

  // HL2 Package Detail Sheet
  const [hl2SheetOpen, setHl2SheetOpen] = useState(false);
  const [loadingHl2Detail, setLoadingHl2Detail] = useState(false);
  const [hl2Detail, setHl2Detail] = useState<{
    name: string;
    price: number;
    validity: string;
    description: string;
  } | null>(null);
  const [buyingHl2, setBuyingHl2] = useState(false);

  const [message, setMessage] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadQuests = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await mytelApi.getDailyQuest(account.accessToken, account.phone);
      const root = res?.result?.mainScreenResponse || res?.result || res?.data || res;

      setHeaderDate(extractApplyRange(root?.applyTime || root?.dateTime));
      if (root?.totalPrize !== undefined) {
        setTotalPoints(Number(root.totalPrize || 0));
      }

      // HL2 Featured Package
      let hl2: DailyHl2Package | null = null;
      if (root?.hl2package && typeof root.hl2package === 'object' && root.hl2package.title) {
        hl2 = {
          title: String(root.hl2package.title || ''),
          packageCode: String(root.hl2package.packageCode || ''),
          buttonName: String(root.hl2package.buttonName || 'ဝယ်မည်'),
          isComplete: Boolean(root.hl2package.isComplete),
        };
      }
      setHl2Pkg(hl2);

      const questLockedByHl2 = Boolean(hl2 && hl2.title && !hl2.isComplete);

      // Daily Quest (JSONObject per DailyClaimActivity.smali, with array fallback)
      const rawDaily = Array.isArray(root?.daily) ? root.daily[0] : root?.daily;
      if (rawDaily && typeof rawDaily === 'object') {
        const isComplete = Boolean(rawDaily.isComplete);
        setDailyQuest({
          id: 'daily_checkin',
          title: String(rawDaily.title || 'Daily Check-in'),
          value: Number(rawDaily.value || 0),
          numCompleteAction: Number(rawDaily.numCompleteAction || 0),
          totalAction: Number(rawDaily.totalAction || 1),
          isComplete,
          dateTime: rawDaily.dateTime ? String(rawDaily.dateTime) : undefined,
          status: isComplete ? 'CLAIMED' : questLockedByHl2 ? 'LOCKED' : 'READY',
          type: 'DAILY',
        });
      } else {
        setDailyQuest(null);
      }

      // Grand Bonus Quest (JSONObject)
      const rawGrand = root?.grand;
      if (rawGrand && typeof rawGrand === 'object') {
        const numDone = Number(rawGrand.numCompleteAction || 0);
        const total = Number(rawGrand.totalAction || 1);
        setGrandQuest({
          id: 'grand_quest',
          title: String(rawGrand.title || 'Grand Bonus'),
          value: Number(rawGrand.value || 0),
          numCompleteAction: numDone,
          totalAction: total,
          isComplete: numDone >= total && total > 0,
          status: numDone >= total && total > 0 ? 'CLAIMED' : 'PENDING',
          type: 'GRAND',
        });
      } else {
        setGrandQuest(null);
      }

      // Mini Quest Array
      const miniList = Array.isArray(root?.miniQuest) ? root.miniQuest : [];
      setMiniQuests(
        miniList.map((q: any, idx: number) => {
          const code = String(q.configCode || `mini_${idx}`);
          const claimed = Boolean(q.isComplete) || isMiniClaimedLocally(account.phone, code);
          return {
            id: code,
            configCode: code,
            urlCallBack: q.urlCallBack ? String(q.urlCallBack) : undefined,
            title: String(q.title || 'Mini Quest'),
            buttonName: q.buttonName ? String(q.buttonName) : 'Claim',
            value: Number(q.value || 0),
            numCompleteAction: Number(q.numCompleteAction || 0),
            totalAction: Number(q.totalAction || 1),
            isComplete: claimed,
            status: claimed ? 'CLAIMED' : questLockedByHl2 ? 'LOCKED' : 'READY',
            type: 'MINI',
          };
        })
      );
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load Daily Quest');
    } finally {
      setLoading(false);
    }
  }, [account.accessToken, account.phone]);

  useEffect(() => {
    loadQuests();
  }, [loadQuests]);

  const handleDailyClaim = async () => {
    setClaimingDaily(true);
    setMessage('');
    setErrorMsg('');
    try {
      const res = await mytelApi.postDailyClaim(account.accessToken, account.phone);
      const ok =
        res?.success === true ||
        Number(res?.errorCode) === 0 ||
        Number(res?.errorCode) === 200 ||
        res?.errorCode === '00000';
      if (!ok) {
        throw new Error(res?.message || 'Daily claim failed');
      }
      setMessage(res?.message || 'Daily check-in reward claimed!');
      await loadQuests();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Daily claim failed');
    } finally {
      setClaimingDaily(false);
    }
  };

  const handleClaimMini = async (q: DailyQuestItem) => {
    if (!q.urlCallBack) {
      await handleDailyClaim();
      return;
    }
    setClaimingMiniId(q.id);
    setMessage('');
    setErrorMsg('');
    try {
      const res = await mytelApi.claimMiniQuest(account.accessToken, account.phone, q.urlCallBack);
      const ok =
        res?.success === true ||
        Number(res?.errorCode) === 0 ||
        Number(res?.errorCode) === 200;
      if (!ok) {
        throw new Error(res?.message || 'Mini quest claim failed');
      }
      markMiniClaimedLocally(account.phone, q.configCode);
      setMessage(res?.message || `${q.title} claimed!`);
      await loadQuests();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Mini quest claim failed');
    } finally {
      setClaimingMiniId(null);
    }
  };

  const handleOpenHl2Detail = async () => {
    if (!hl2Pkg?.packageCode) return;
    setHl2SheetOpen(true);
    setLoadingHl2Detail(true);
    setHl2Detail(null);
    try {
      const res = await mytelApi.getVasDetail(
        account.accessToken,
        hl2Pkg.packageCode,
        account.phone
      );
      const r = res?.result || res?.data || res;
      const descs = Array.isArray(r?.vasDescriptions) ? r.vasDescriptions : [];
      const fullDesc =
        descs
          .map((d: any) => d?.description || d?.shortDesCription || d?.shortDescription)
          .filter(Boolean)
          .join('\n') ||
        r?.shortDesCription ||
        r?.description ||
        hl2Pkg.title;

      setHl2Detail({
        name: String(r?.name || hl2Pkg.title),
        price: Number(r?.price || 0),
        validity: r?.validity ? `${r.validity} ရက်` : 'Featured Pack',
        description: String(fullDesc),
      });
    } catch (err) {
      setHl2Detail({
        name: hl2Pkg.title,
        price: 0,
        validity: 'Featured Pack',
        description: err instanceof Error ? err.message : hl2Pkg.title,
      });
    } finally {
      setLoadingHl2Detail(false);
    }
  };

  const handleBuyHl2 = async () => {
    if (!hl2Pkg?.packageCode) return;
    setBuyingHl2(true);
    setMessage('');
    setErrorMsg('');
    try {
      const res = await mytelApi.registerVasPackage(
        account.accessToken,
        hl2Pkg.packageCode,
        account.phone
      );
      const ok = Number(res?.errorCode) === 0 || Number(res?.errorCode) === 200 || res?.success === true;
      if (!ok) {
        throw new Error(res?.message || 'Package registration failed');
      }
      setMessage(res?.message || `${hl2Pkg.title} ဝယ်ယူပြီးပါပြီ!`);
      setHl2SheetOpen(false);
      await loadQuests();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Package registration failed');
      setHl2SheetOpen(false);
    } finally {
      setBuyingHl2(false);
    }
  };

  const grandPct = grandQuest
    ? Math.min(100, Math.round(((grandQuest.numCompleteAction || 0) / Math.max(1, grandQuest.totalAction || 1)) * 100))
    : 0;

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Daily Quest"
        subtitle={headerDate || 'Check-in & Bonus Quests'}
        onBack={onBack}
        rightSlot={
          <button
            type="button"
            onClick={loadQuests}
            disabled={loading}
            aria-label="Refresh Daily Quest"
            className="h-11 w-11 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        }
      />

      {/* Total Prize + Primary Daily Check-in Card */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="h-12 w-12 rounded-xl bg-[#C8942A]/12 border border-[#C8942A]/25 flex items-center justify-center shrink-0">
              <img src={KONG_ASSETS.icPrizePoint} alt="Quest Rewards" className="h-8 w-8 object-contain" />
            </div>
            <div>
              <p className="text-xs text-slate-400">Total Quest Rewards</p>
              <p className="font-mono-num text-2xl sm:text-3xl font-bold text-[#E8B040] mt-0.5">
                {totalPoints.toLocaleString()} pts
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDailyClaim}
            disabled={claimingDaily || dailyQuest?.isComplete || dailyQuest?.status === 'LOCKED'}
            className="min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-5 py-2.5 text-sm font-bold text-[#0C0F14] hover:brightness-105 disabled:opacity-50 active:scale-[0.98] transition-all flex items-center gap-2"
          >
            {claimingDaily ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : dailyQuest?.isComplete ? (
              <Check className="h-4 w-4" />
            ) : dailyQuest?.status === 'LOCKED' ? (
              <Lock className="h-4 w-4" />
            ) : (
              <Gift className="h-4 w-4" />
            )}
            <span>
              {claimingDaily
                ? 'Claiming...'
                : dailyQuest?.isComplete
                ? 'ယနေ့ ရယူပြီးပါပြီ'
                : 'ရယူရန် (Daily Claim)'}
            </span>
          </button>
        </div>

        {dailyQuest && (
          <div className="pt-3 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
            <span>{dailyQuest.title}</span>
            <span className="font-mono-num text-[#E8B040]">
              {dailyQuest.value ? `+${dailyQuest.value.toLocaleString()} pts` : ''}
              {dailyQuest.dateTime ? ` · Next: ${dailyQuest.dateTime}` : ''}
            </span>
          </div>
        )}
      </div>

      {/* Grand Streak Progress */}
      {grandQuest && (
        <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-5 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <Sparkles className="h-4 w-4 text-[#E8B040] shrink-0" />
              <p className="text-sm font-semibold text-white truncate">{grandQuest.title}</p>
            </div>
            <span className="font-mono-num text-xs font-bold text-[#E8B040] shrink-0">
              +{grandQuest.value?.toLocaleString() || 0} pts
            </span>
          </div>
          <div className="h-2.5 w-full rounded-full bg-[#1E2430] overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#C8942A] to-[#E8B040] transition-all duration-500"
              style={{ width: `${grandPct}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono-num">
            <span>
              {grandQuest.numCompleteAction || 0} / {grandQuest.totalAction || 1} completed
            </span>
            <span>{grandPct}%</span>
          </div>
        </div>
      )}

      {/* HL2 Featured Package Card */}
      {hl2Pkg && hl2Pkg.title && (
        <button
          type="button"
          onClick={handleOpenHl2Detail}
          className="w-full rounded-2xl border border-[#C8942A]/35 bg-[#191C22] p-5 flex items-center justify-between gap-4 text-left hover:border-[#E8B040] active:scale-[0.99] transition-all"
        >
          <div className="min-w-0 space-y-1">
            <p className="text-xs font-semibold text-[#E8B040]">
              Featured Unlock Package · {hl2Pkg.isComplete ? 'Completed' : 'Unlock Quests'}
            </p>
            <p className="text-sm sm:text-base font-semibold text-white truncate">
              {hl2Pkg.title}
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 min-h-[40px] rounded-xl bg-[#C8942A]/20 px-3.5 py-2 text-xs font-bold text-[#E8B040] shrink-0">
            <span>{hl2Pkg.isComplete ? 'Bought' : hl2Pkg.buttonName || 'View'}</span>
            <ChevronRight className="h-4 w-4" />
          </span>
        </button>
      )}

      {message && (
        <div className="rounded-xl border border-[#4CAF50]/30 bg-[#4CAF50]/10 px-4 py-3 text-xs font-medium text-[#81C784]">
          {message}
        </div>
      )}
      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          {errorMsg}
        </div>
      )}

      {/* Mini Quests List */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-slate-300">Mini Quests</h2>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((k) => (
              <div
                key={k}
                className="h-20 rounded-2xl border border-white/[0.06] bg-[#141820] animate-pulse"
              />
            ))}
          </div>
        ) : miniQuests.length === 0 ? (
          <div className="rounded-2xl border border-white/[0.08] bg-[#141820] p-8 text-center text-sm text-slate-400">
            No mini-quests available right now.
          </div>
        ) : (
          <div className="space-y-3">
            {miniQuests.map((q, idx) => {
              const isClaimed = q.isComplete || q.status === 'CLAIMED';
              const isLocked = q.status === 'LOCKED';
              const isBusy = claimingMiniId === q.id;
              return (
                <div
                  key={`${q.id}-${idx}`}
                  className="rounded-2xl border border-white/[0.08] bg-[#141820] p-4 sm:p-5 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="h-10 w-10 rounded-xl bg-[#1A1F2A] border border-white/[0.06] flex items-center justify-center shrink-0">
                      <img src={KONG_ASSETS.icLoyalPoint} alt="" className="h-6 w-6 object-contain" />
                    </div>
                    <div className="space-y-1 min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{q.title}</p>
                      <div className="flex items-center gap-2 text-xs text-slate-400 font-mono-num">
                        {q.value ? (
                          <span className="text-[#E8B040]">+{q.value.toLocaleString()} pts</span>
                        ) : (
                          <span>Quest</span>
                        )}
                        {q.totalAction ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>
                              {q.numCompleteAction || 0}/{q.totalAction}
                            </span>
                          </>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0">
                    {isClaimed ? (
                      <span className="inline-flex items-center gap-1.5 min-h-[40px] px-2 text-xs font-semibold text-[#4CAF50]">
                        <Check className="h-4 w-4" />
                        ရယူပြီး
                      </span>
                    ) : isLocked ? (
                      <span className="inline-flex items-center gap-1.5 min-h-[40px] px-2 text-xs font-medium text-slate-500">
                        <Lock className="h-4 w-4" />
                        Locked
                      </span>
                    ) : (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => handleClaimMini(q)}
                        className="min-h-[44px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] px-4 py-2 text-xs font-bold text-[#0C0F14] hover:brightness-105 active:scale-95 transition-all flex items-center gap-1.5"
                      >
                        {isBusy && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                        <span>{q.buttonName || 'ရယူရန်'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* HL2 Package Purchase Bottom Sheet */}
      {hl2SheetOpen && (
        <div
          onClick={() => setHl2SheetOpen(false)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-display text-lg font-bold text-white truncate">
                {hl2Detail?.name || hl2Pkg?.title}
              </h3>
              <button
                type="button"
                onClick={() => setHl2SheetOpen(false)}
                className="h-10 w-10 rounded-xl flex items-center justify-center text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {loadingHl2Detail ? (
              <div className="py-8 flex items-center justify-center gap-2 text-xs text-slate-400">
                <Loader2 className="h-5 w-5 animate-spin text-[#E8B040]" />
                <span>Loading package details...</span>
              </div>
            ) : (
              <>
                <div className="rounded-xl border border-white/[0.08] bg-[#1C212C] divide-y divide-white/[0.06] text-xs">
                  {hl2Detail && hl2Detail.price > 0 && (
                    <div className="px-4 py-3 flex items-center justify-between">
                      <span className="text-slate-400">Price</span>
                      <span className="font-mono-num font-bold text-[#E8B040]">
                        {hl2Detail.price.toLocaleString()} Ks
                      </span>
                    </div>
                  )}
                  <div className="px-4 py-3 flex items-center justify-between">
                    <span className="text-slate-400">Validity</span>
                    <span className="text-white">{hl2Detail?.validity || '--'}</span>
                  </div>
                </div>
                {hl2Detail?.description && (
                  <p className="text-xs text-slate-300 whitespace-pre-line leading-relaxed max-h-40 overflow-y-auto">
                    {hl2Detail.description}
                  </p>
                )}
              </>
            )}

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => setHl2SheetOpen(false)}
                className="flex-1 min-h-[46px] rounded-xl border border-white/10 text-xs font-semibold text-slate-300"
              >
                Close
              </button>
              <button
                type="button"
                disabled={buyingHl2 || loadingHl2Detail || hl2Pkg?.isComplete}
                onClick={handleBuyHl2}
                className="flex-1 min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-xs font-bold text-[#0C0F14] disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {buyingHl2 && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>{hl2Pkg?.isComplete ? 'Completed' : 'ဝယ်ယူမည်'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
