import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Loader2, Play, RefreshCw, Square } from 'lucide-react';
import { PageBackHeader } from '../components/TopBar';
import { useKongRunner } from '../context/KongRunnerContext';
import { kongApi } from '../lib/api';
import { KONG_ASSETS, getRewardAsset } from '../lib/kongAssets';
import type { KongSpinSegment, SavedAccount } from '../types';

interface KongSpinViewProps {
  account: SavedAccount;
  onBack: () => void;
}

const SLICE_COLORS = [
  '#B88422',
  '#1A1F29',
  '#9A6314',
  '#232A36',
  '#C8942A',
  '#151A22',
  '#8A5A12',
  '#272F3D',
];

function extractSegment(raw: any, idx: number): KongSpinSegment {
  const rewardsArr = Array.isArray(raw?.rewards) ? raw.rewards : [];
  const firstReward = rewardsArr[0] || {};
  const typeItem = String(
    firstReward.typeItem ||
      raw?.typeItem ||
      raw?.description ||
      (typeof raw?.rewards === 'string' ? raw.rewards : '') ||
      'GOOD_LUCK'
  );
  const value = Number(firstReward.value ?? raw?.value ?? 0);
  return {
    id: Number(raw?.id ?? idx),
    name: raw?.name ? String(raw.name) : undefined,
    description: raw?.description ? String(raw.description) : undefined,
    icon: raw?.icon ? String(raw.icon) : null,
    typeItem,
    value,
    rewards: rewardsArr.length > 0 ? rewardsArr : undefined,
  };
}

function shortWheelValue(seg: KongSpinSegment): string {
  const t = seg.typeItem.toUpperCase();
  if (t.includes('GOOD_LUCK') || t === 'LUCK') return 'Luck';
  if (t === 'BANANA') return seg.value >= 1000 ? `${(seg.value / 1000).toFixed(seg.value % 1000 === 0 ? 0 : 1)}K` : `${seg.value}`;
  if (t.includes('TURN')) return `+${seg.value || 1}`;
  if (t.includes('X2')) return `×${seg.value || 1}`;
  return `×${seg.value || 1}`;
}

function fullRewardLabel(seg: KongSpinSegment): string {
  const t = seg.typeItem.toUpperCase();
  if (t.includes('X2')) return `x2 Banana ×${seg.value || 1}`;
  if (t === 'BANANA') return `${seg.value.toLocaleString()} Banana`;
  if (t === 'TICKET') return `${seg.value} Play Ticket`;
  if (t === 'PROTECT') return `${seg.value} Protect Shield`;
  if (t === 'REBORN') return `${seg.value} Reborn Heart`;
  if (t === 'MAGNET') return `${seg.value} Magnet`;
  if (t.includes('TURN')) return `+${seg.value || 1} Free Spin`;
  if (t.includes('GOOD_LUCK') || t === 'LUCK') return 'Good Luck Next Time';
  return seg.description || seg.name || seg.typeItem;
}

export function KongSpinView({ account, onBack }: KongSpinViewProps) {
  const kong = useKongRunner();
  const [segments, setSegments] = useState<KongSpinSegment[]>([]);
  const [freeSpins, setFreeSpins] = useState(0);
  const [spinPrice, setSpinPrice] = useState(0);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [resultModal, setResultModal] = useState<KongSpinSegment | null>(null);
  const [autoSpinning, setAutoSpinning] = useState(false);
  const [autoSummary, setAutoSummary] = useState<
    Array<{ key: string; label: string; icon: string; hits: number }> | null
  >(null);
  const [errorMsg, setErrorMsg] = useState('');
  const stopAutoRef = useRef(false);
  const rotationRef = useRef(0);
  const freeSpinsRef = useRef(0);

  const loadSpinData = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      let tok = kong.kongToken;
      if (!tok) {
        const resolved = await kong.ensureKongSession(account);
        if (!resolved) {
          setLoading(false);
          return;
        }
        tok = resolved;
      }
      const [spinRes] = await Promise.all([
        kongApi.getSpinList(tok),
        kong.refreshUserInfo(tok),
      ]);
      const d = spinRes?.data || spinRes;
      const list = Array.isArray(d?.luckySpin) ? d.luckySpin : [];
      setSegments(list.map((s: any, idx: number) => extractSegment(s, idx)));
      const tf = Number(d?.turnFree || 0);
      freeSpinsRef.current = tf;
      setFreeSpins(tf);
      setSpinPrice(Number(d?.price || 0));
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Spin list ရယူ၍မရပါ');
    } finally {
      setLoading(false);
    }
  }, [account, kong]);

  useEffect(() => {
    loadSpinData();
    return () => {
      stopAutoRef.current = true;
    };
  }, [account.phone]);

  const executeSingleSpin = async (): Promise<KongSpinSegment | null> => {
    if (!kong.kongToken) return null;
    const res = await kongApi.spin(kong.kongToken);
    if (res?.success === false) {
      throw new Error(res?.message || 'Spin မအောင်မြင်ပါ');
    }
    const rawWin = res?.data || {};
    const parsedWin = extractSegment(rawWin, 0);
    const winId = parsedWin.id;

    let targetIdx = segments.findIndex((s) => s.id === winId);
    if (targetIdx < 0) {
      targetIdx = segments.findIndex(
        (s) => s.typeItem === parsedWin.typeItem && s.value === parsedWin.value
      );
    }
    if (targetIdx < 0) targetIdx = 0;

    const n = Math.max(1, segments.length);
    const sliceAngle = 360 / n;
    const targetCenter = targetIdx * sliceAngle + sliceAngle / 2;

    const current = rotationRef.current;
    const base = current - (current % 360);
    const nextAngle = base + 360 * 5 + (360 - targetCenter);
    rotationRef.current = nextAngle;
    setRotation(nextAngle);

    await new Promise((r) => window.setTimeout(r, 2600));
    await kong.refreshUserInfo();

    const wonSeg = segments[targetIdx] || parsedWin;
    let nextFree = freeSpinsRef.current > 0 ? freeSpinsRef.current - 1 : 0;
    if (wonSeg.typeItem.toUpperCase().includes('TURN')) {
      nextFree += wonSeg.value || 1;
    }
    freeSpinsRef.current = nextFree;
    setFreeSpins(nextFree);

    return wonSeg;
  };

  const handleSpin = async () => {
    if (spinning || autoSpinning) return;
    const bananas = kong.userInfo?.totalBanana ?? 0;
    if (freeSpins <= 0 && bananas < spinPrice) {
      setErrorMsg('Banana မလောက်ပါ');
      return;
    }
    setSpinning(true);
    setErrorMsg('');
    try {
      const won = await executeSingleSpin();
      if (won) {
        setResultModal(won);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Spin failed');
    } finally {
      setSpinning(false);
    }
  };

  const handleAutoSpin = async () => {
    if (autoSpinning) {
      stopAutoRef.current = true;
      return;
    }
    if (spinning) return;
    if (segments.length === 0) {
      setErrorMsg('Spin data မရှိသေးပါ');
      return;
    }
    stopAutoRef.current = false;
    setAutoSpinning(true);
    setErrorMsg('');
    const results: Record<string, { label: string; icon: string; hits: number }> = {};
    let count = 0;

    try {
      while (!stopAutoRef.current) {
        const info = await kong.refreshUserInfo();
        const currentBananas = info?.totalBanana ?? kong.userInfo?.totalBanana ?? 0;
        if (freeSpinsRef.current <= 0 && currentBananas < spinPrice) break;
        const won = await executeSingleSpin();
        if (!won) break;
        count += 1;
        const label = fullRewardLabel(won);
        const icon = getRewardAsset(won.typeItem || won.description || '');
        if (!results[label]) {
          results[label] = { label, icon, hits: 1 };
        } else {
          results[label].hits += 1;
        }
        await new Promise((r) => window.setTimeout(r, 450));
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Auto spin stopped');
    } finally {
      setAutoSpinning(false);
      if (count > 0) {
        setAutoSummary(
          Object.entries(results).map(([key, item]) => ({
            key,
            label: item.label,
            icon: item.icon,
            hits: item.hits,
          }))
        );
      }
    }
  };

  const n = Math.max(1, segments.length);
  const sliceDeg = 360 / n;
  const rimDots = Array.from({ length: 16 }, (_, idx) => {
    const a = ((idx * 360) / 16) * (Math.PI / 180);
    return {
      x: 100 + 95 * Math.cos(a),
      y: 100 + 95 * Math.sin(a),
      bright: idx % 2 === 0,
    };
  });

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 py-5 sm:py-6 pb-24 md:pb-12 space-y-5">
      <PageBackHeader
        title="Lucky Spin"
        subtitle="Free Spins & Banana Wheel"
        onBack={onBack}
        rightSlot={
          <div className="flex items-center gap-2">
            <div className="rounded-xl border border-white/10 bg-[#141820] px-3 py-2 text-xs font-bold font-mono-num text-[#E8B040] flex items-center gap-1.5">
              <img src={KONG_ASSETS.icBanana} alt="" className="h-4 w-4 object-contain" />
              <span>{(kong.userInfo?.totalBanana ?? 0).toLocaleString()}</span>
            </div>
            <button
              type="button"
              onClick={loadSpinData}
              disabled={loading || spinning || autoSpinning}
              aria-label="Refresh spin wheel"
              className="h-10 w-10 rounded-xl border border-white/10 bg-[#161A22] text-slate-200 hover:border-[#C8942A]/50 active:scale-95 flex items-center justify-center transition-all"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        }
      />

      {/* Free Spins & Cost Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center gap-3.5">
          <div className="h-11 w-11 rounded-xl bg-[#4CAF50]/12 border border-[#4CAF50]/25 flex items-center justify-center shrink-0">
            <img src={KONG_ASSETS.icTurn} alt="Free Spins" className="h-7 w-7 object-contain" />
          </div>
          <div className="min-w-0">
            <p className="text-xs text-slate-400">Free Spins</p>
            <p className="font-mono-num text-xl sm:text-2xl font-bold text-[#4CAF50] mt-0.5">
              {loading ? '--' : freeSpins}
            </p>
          </div>
        </div>

        <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-4 flex items-center gap-3.5">
          <div className="h-11 w-11 rounded-xl bg-[#C8942A]/12 border border-[#C8942A]/25 flex items-center justify-center shrink-0">
            <img src={KONG_ASSETS.icBanana} alt="Cost" className="h-7 w-7 object-contain" />
          </div>
          <div className="min-w-0">
            <p className="text-xs text-slate-400">Cost / Spin</p>
            <p className="font-mono-num text-xl sm:text-2xl font-bold text-[#E8B040] mt-0.5">
              {loading ? '--' : spinPrice.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-xs text-red-300">
          {errorMsg}
        </div>
      )}

      {/* Wheel Container */}
      <div className="rounded-2xl border border-white/[0.08] bg-[#161920] p-5 sm:p-7 flex flex-col items-center gap-6">
        {loading ? (
          <div className="h-72 w-72 sm:h-80 sm:w-80 rounded-full border-4 border-[#C8942A]/30 bg-[#12151B] flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-[#E8B040]" />
          </div>
        ) : (
          <div className="relative flex flex-col items-center">
            {/* Pointer */}
            <div className="z-20 -mb-3.5 flex flex-col items-center drop-shadow-[0_4px_10px_rgba(0,0,0,0.75)]">
              <div className="h-3 w-3 rounded-full bg-[#FFF2C4] border-2 border-[#C8942A]" />
              <div className=" -mt-1 h-0 w-0 border-x-[12px] border-x-transparent border-t-[20px] border-t-[#E8B040]" />
            </div>

            <div className="relative p-2 rounded-full bg-gradient-to-b from-[#E8B040] via-[#9E6F1A] to-[#6E4B0D] shadow-[0_14px_40px_rgba(0,0,0,0.65)]">
              <div
                className="relative h-72 w-72 sm:h-84 sm:w-84 rounded-full bg-[#0C0F14] overflow-hidden transition-transform duration-[2500ms] ease-[cubic-bezier(0.16,1,0.3,1)]"
                style={{ transform: `rotate(${rotation}deg)` }}
              >
                <svg viewBox="0 0 200 200" className="h-full w-full">
                  <defs>
                    <clipPath id="spinCenterHubClip">
                      <circle cx="100" cy="100" r="15" />
                    </clipPath>
                  </defs>

                  {/* Outer bezel ring */}
                  <circle cx="100" cy="100" r="99" fill="#12161E" stroke="#C8942A" strokeWidth="2" />

                  {segments.map((seg, i) => {
                    const startAngle = (i * sliceDeg - 90) * (Math.PI / 180);
                    const endAngle = ((i + 1) * sliceDeg - 90) * (Math.PI / 180);
                    const r = 90;
                    const x1 = 100 + r * Math.cos(startAngle);
                    const y1 = 100 + r * Math.sin(startAngle);
                    const x2 = 100 + r * Math.cos(endAngle);
                    const y2 = 100 + r * Math.sin(endAngle);
                    const largeArc = sliceDeg > 180 ? 1 : 0;

                    const midAngle = ((i + 0.5) * sliceDeg - 90) * (Math.PI / 180);
                    const rotDeg = (i + 0.5) * sliceDeg;

                    // Outer image spot (r = 66) & inner value text (r = 40)
                    const ix = 100 + 66 * Math.cos(midAngle);
                    const iy = 100 + 66 * Math.sin(midAngle);
                    const tx = 100 + 40 * Math.cos(midAngle);
                    const ty = 100 + 40 * Math.sin(midAngle);
                    const rewardImg = getRewardAsset(seg.typeItem || seg.description || '');
                    const imgSize = n >= 10 ? 18 : 22;

                    return (
                      <g key={`${seg.id}-${i}`}>
                        <path
                          d={`M100,100 L${x1},${y1} A${r},${r} 0 ${largeArc},1 ${x2},${y2} Z`}
                          fill={SLICE_COLORS[i % SLICE_COLORS.length]}
                          stroke="#0B0E14"
                          strokeWidth="1.2"
                        />
                        <g transform={`rotate(${rotDeg}, ${ix}, ${iy})`}>
                          <image
                            href={rewardImg}
                            x={ix - imgSize / 2}
                            y={iy - imgSize / 2}
                            width={imgSize}
                            height={imgSize}
                            preserveAspectRatio="xMidYMid meet"
                          />
                        </g>
                        <text
                          x={tx}
                          y={ty}
                          fill="#FFFFFF"
                          fontSize={n >= 10 ? '6.5' : '7.5'}
                          fontWeight="800"
                          textAnchor="middle"
                          dominantBaseline="middle"
                          transform={`rotate(${rotDeg}, ${tx}, ${ty})`}
                        >
                          {shortWheelValue(seg)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Rim indicator dots */}
                  {rimDots.map((dot, i) => (
                    <circle
                      key={`rim-${i}`}
                      cx={dot.x}
                      cy={dot.y}
                      r={dot.bright ? 2.1 : 1.5}
                      fill={dot.bright ? '#FFF4C8' : '#C8942A'}
                    />
                  ))}

                  {/* Center Hub with Kong Spin Emblem */}
                  <circle cx="100" cy="100" r="17" fill="#0C0F14" stroke="#E8B040" strokeWidth="2.5" />
                  <image
                    href={KONG_ASSETS.icSpinCenter}
                    x="85"
                    y="85"
                    width="30"
                    height="30"
                    clipPath="url(#spinCenterHubClip)"
                    preserveAspectRatio="xMidYMid slice"
                  />
                </svg>
              </div>
            </div>
          </div>
        )}

        {/* Controls */}
        <div className="w-full max-w-md grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            disabled={loading || spinning || autoSpinning}
            onClick={handleSpin}
            className="min-h-[48px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14] hover:brightness-105 active:scale-[0.98] transition-all disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {spinning ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4 fill-current" />
            )}
            <span>
              {freeSpins > 0
                ? `SPIN (Free ${freeSpins})`
                : `SPIN ${spinPrice.toLocaleString()} Banana`}
            </span>
          </button>

          <button
            type="button"
            disabled={loading || spinning}
            onClick={handleAutoSpin}
            className={`min-h-[48px] rounded-xl px-4 text-sm font-bold flex items-center justify-center gap-2 border active:scale-[0.98] transition-all ${
              autoSpinning
                ? 'border-red-500 bg-red-600 text-white'
                : 'border-white/10 bg-[#12151B] text-white hover:border-[#C8942A]/50'
            }`}
          >
            {autoSpinning ? <Square className="h-4 w-4 fill-current" /> : null}
            <span>{autoSpinning ? 'STOP AUTO SPIN' : 'AUTO SPIN'}</span>
          </button>
        </div>

        {/* Visual Prize Slots Grid */}
        {!loading && segments.length > 0 && (
          <div className="w-full pt-4 border-t border-white/[0.06] space-y-2.5">
            <p className="text-xs font-semibold text-slate-400">Wheel Prizes ({segments.length})</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {segments.map((seg, i) => (
                <div
                  key={`legend-${seg.id}-${i}`}
                  className="rounded-xl border border-white/[0.06] bg-[#12151B] px-3 py-2 flex items-center gap-2.5 min-w-0"
                >
                  <img
                    src={getRewardAsset(seg.typeItem || seg.description || '')}
                    alt={fullRewardLabel(seg)}
                    className="h-7 w-7 object-contain shrink-0"
                  />
                  <span className="text-xs font-medium text-slate-200 truncate">
                    {fullRewardLabel(seg)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Single Spin Result Sheet */}
      {resultModal && (
        <div
          onClick={() => setResultModal(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb text-center space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <div className="mx-auto h-20 w-20 rounded-2xl bg-[#1E232E] border border-[#C8942A]/35 flex items-center justify-center">
              <img
                src={getRewardAsset(resultModal.typeItem || resultModal.description || '')}
                alt={fullRewardLabel(resultModal)}
                className="h-14 w-14 object-contain"
              />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">Spin Reward</h3>
              <p className="font-mono-num text-xl font-bold text-[#E8B040] mt-1">
                {fullRewardLabel(resultModal)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setResultModal(null)}
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14]"
            >
              ရယူမည်
            </button>
          </div>
        </div>
      )}

      {/* Auto Spin Summary Sheet */}
      {autoSummary && (
        <div
          onClick={() => setAutoSummary(null)}
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-sm rounded-t-3xl sm:rounded-2xl border border-white/10 bg-[#161A22] px-6 pt-3 pb-6 safe-pb space-y-4 animate-sheet-in"
          >
            <div className="sm:hidden w-10 h-1.5 rounded-full bg-white/20 mx-auto mb-1" />
            <h3 className="font-display text-lg font-bold text-white">Auto Spin Complete</h3>
            <ul className="space-y-2 text-sm text-[#E8B040] font-mono-num max-h-60 overflow-y-auto">
              {autoSummary.map((row) => (
                <li
                  key={row.key}
                  className="rounded-xl border border-white/[0.06] bg-[#1E232E] px-4 py-2.5 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img src={row.icon} alt="" className="h-6 w-6 object-contain shrink-0" />
                    <span className="truncate text-white text-xs font-sans">{row.label}</span>
                  </div>
                  <span className="font-bold shrink-0">× {row.hits}</span>
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => setAutoSummary(null)}
              className="w-full min-h-[46px] rounded-xl bg-gradient-to-r from-[#C8942A] to-[#E8B040] text-sm font-bold text-[#0C0F14]"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
