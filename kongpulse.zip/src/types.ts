export type AppRoute =
  | 'login'
  | 'otp'
  | 'dashboard'
  | 'accounts'
  | 'daily-claim'
  | 'points-exchange'
  | 'points-history'
  | 'data-packages'
  | 'kong-island'
  | 'kong-shop'
  | 'kong-exchange'
  | 'kong-spin'
  | 'beat-zoo'
  | 'car-racing'
  | 'fighting-fish'
  | 'kitty-fall'
  | 'soft-climbers'
  | 'myid-go';

export interface SavedAccount {
  phone: string;
  fullName: string;
  avatarUrl: string;
  accessToken: string;
  refreshToken: string;
  thirdPartyToken: string;
  mcuid: string;
  expiresAt: number;
  kongToken?: string;
  kongPlayerName?: string;
  kongPlayerAvatar?: string;
  kongPlayerPhone?: string;
  beatzooToken?: string;
  carRacingToken?: string;
  fishioToken?: string;
  fishioRefreshToken?: string;
  kittyCookie?: string;
  softClimbersToken?: string;
  myidGoToken?: string;
  addedAt: number;
}

export interface AccountBalances {
  mainBalance: string;
  dataText: string;
  voiceText: string;
  points: number;
  rawPoints: number;
}

export interface LoyaltyExtendInfo {
  monthlyLimit: number;
  currentLimit: number;
  afterLimit: number;
  exchanged: number;
  mainBalanceSpend: number;
  extendRemain: number;
  canExtend: boolean;
}

export interface LoyaltyUsage {
  rankName: string;
  used: number;
  limit: number;
  canExtend: boolean;
  extendInfo?: LoyaltyExtendInfo;
  progressText?: string;
}

export interface KongUserInfo {
  playerName: string;
  msisdn: string;
  avatar: string;
  totalBanana: number;
  totalTicket: number;
  totalBox: number;
  total2xBanana: number;
  totalMagnet?: number;
  totalProtect?: number;
  totalReborn?: number;
  turnFree?: number;
}

export interface KongAvatar {
  id: number;
  url: string;
  status: string;
  price?: number;
  currency?: string;
  description?: string;
  owned?: boolean;
}

export interface KongLeaderboardRow {
  rank: number;
  playerName: string;
  msisdn: string;
  avatar: string;
  totalBanana: number;
  reward?: string;
  rewardType?: string;
}

export interface KongPackage {
  code: string;
  name: string;
  icon?: string;
  price: number;
  typePrice?: string;
  typePackage?: string;
  ticket: number;
  banana: number;
  magnet: number;
  protect: number;
  reborn: number;
  x2banana: number;
  autoRenew?: boolean;
  vipRequire?: boolean;
}

export interface KongExchangeItem {
  id: number;
  name: string;
  typeItem: string;
  price: number;
  description?: string;
}

export interface KongSpinSegment {
  id: number;
  name?: string;
  description?: string;
  icon?: string | null;
  typeItem: string;
  value: number;
  rewards?: Array<{ typeItem?: string; value?: number }>;
}

export interface LoyaltyPack {
  rewardCode: string;
  rewardName: string;
  pointAmount: number;
  validityDayText?: string;
  category: string;
}

export interface LoyaltyHistoryItem {
  id?: string;
  title: string;
  points: number;
  date: string;
  type?: string;
  description?: string;
}

export interface VasPackage {
  id: string;
  code: string;
  name: string;
  price: number;
  validityDays: number;
  validity: string;
  shortDescription?: string;
  description?: string;
}

export interface DailyQuestItem {
  id: string;
  configCode?: string;
  urlCallBack?: string;
  title: string;
  buttonName?: string;
  status: 'PENDING' | 'LOCKED' | 'CLAIMED' | 'READY' | string;
  isComplete?: boolean;
  numCompleteAction?: number;
  totalAction?: number;
  value?: number;
  dateTime?: string;
  type?: 'DAILY' | 'MINI' | 'GRAND';
}

export interface DailyHl2Package {
  title: string;
  packageCode: string;
  buttonName: string;
  isComplete: boolean;
}
