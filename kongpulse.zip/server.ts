import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { handleGameWsUpgrade, registerAllGameRoutes } from './server/gamesRoutes';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3000;
const isProd = process.env.NODE_ENV === 'production';

const MYTEL_BASE = 'https://apis.mytel.com.mm';
const TELCO_GW = 'https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login';
const KONG_BASE = 'https://kong.mascom.vn';
const KONG_WS_BASE = 'wss://kong.mascom.vn/api/ws/game';

function normalizePhone09(raw: string): string {
  const digits = String(raw || '').trim().replace(/\s+/g, '');
  if (digits.startsWith('+95')) return `0${digits.slice(3)}`;
  if (digits.startsWith('95')) return `0${digits.slice(2)}`;
  if (digits.startsWith('0')) return digits;
  return `0${digits}`;
}

function normalizePhonePlus95(raw: string): string {
  const digits = String(raw || '').trim().replace(/\s+/g, '');
  if (digits.startsWith('+95')) return digits;
  if (digits.startsWith('95')) return `+${digits}`;
  if (digits.startsWith('0')) return `+95${digits.slice(1)}`;
  return `+95${digits}`;
}

function mytelCommonHeaders(token: string, msisdn: string, deviceId: string, lang = 'en'): Record<string, string> {
  return {
    Authorization: `Bearer ${token}`,
    device_id: deviceId || 'zeno-web-device',
    client_type: '1',
    local_code: '95',
    version: '2.0.16',
    revision: '300',
    language_code: lang,
    country_code: 'MM',
    msisdn: normalizePhonePlus95(msisdn),
    'user-agent': 'okhttp/4.12.0',
  };
}

async function forwardJson(res: Response, upstreamPromise: Promise<globalThis.Response>) {
  try {
    const upstream = await upstreamPromise;
    const text = await upstream.text();
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = { raw: text };
    }
    res.status(upstream.status).json(parsed);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Upstream request failed';
    res.status(502).json({ error: true, message: msg });
  }
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // Health
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, service: 'KongPulse' });
  });

  // =========================================================================
  // MYTEL AUTH & TELECOM PROXY ROUTES
  // =========================================================================

  app.post('/api/mytel/check-account', (req: Request, res: Response) => {
    const phone = normalizePhone09(String(req.body?.phone || ''));
    const url = `${MYTEL_BASE}/myid/authen/v1.0/v2/login/action/check-account?phoneNumber=${encodeURIComponent(phone)}`;
    forwardJson(
      res,
      fetch(url, {
        method: 'GET',
        headers: {
          'accept-language': 'en',
          'user-agent': 'okhttp/4.12.0',
        },
      })
    );
  });

  app.post('/api/mytel/get-otp', (req: Request, res: Response) => {
    const phone = normalizePhone09(String(req.body?.phone || ''));
    const url = `${MYTEL_BASE}/myid/authen/v1.0/login/method/otp/get-otp?phoneNumber=${encodeURIComponent(phone)}`;
    forwardJson(
      res,
      fetch(url, {
        method: 'GET',
        headers: {
          'accept-language': 'my',
          'user-agent': 'okhttp/4.12.0',
        },
      })
    );
  });

  app.post('/api/mytel/register', (req: Request, res: Response) => {
    const phone = normalizePhone09(String(req.body?.phone || ''));
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/myid/authen/v1.0/v2/register/request`, {
        method: 'POST',
        headers: {
          'accept-language': 'my',
          'content-type': 'application/json; charset=UTF-8',
          'user-agent': 'okhttp/4.12.0',
        },
        body: JSON.stringify({ msisdn: phone }),
      })
    );
  });

  app.post('/api/mytel/validate-otp', (req: Request, res: Response) => {
    const phone = normalizePhone09(String(req.body?.phone || ''));
    const otp = String(req.body?.otp || '').trim();
    const deviceId = String(req.body?.deviceId || 'kongpulse-web-01');
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/myid/authen/v1.0/login/method/otp/validate-otp`, {
        method: 'POST',
        headers: {
          'accept-language': 'en',
          'content-type': 'application/json; charset=UTF-8',
          'user-agent': 'okhttp/4.12.0',
        },
        body: JSON.stringify({
          appVersion: '2.0.16',
          buildVersionApp: '300',
          deviceId,
          imei: deviceId,
          os: 'ANDROID Redmi Redmi K30 5G',
          osApp: 'ANDROID',
          password: otp,
          phoneNumber: phone,
          version: '12',
        }),
      })
    );
  });

  app.get('/api/mytel/account-detail', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    const url = `${MYTEL_BASE}/account-detail/api/v1.2/individual/account-main?isdn=${encodeURIComponent(phone)}&language=en`;
    forwardJson(res, fetch(url, { headers: mytelCommonHeaders(token, phone, deviceId, 'en') }));
  });

  app.get('/api/mytel/customer', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/cpm/v1.0/api/customer`, {
        headers: {
          Authorization: `Bearer ${token}`,
          'user-agent': 'okhttp/4.12.0',
        },
      })
    );
  });

  app.put('/api/mytel/customer', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const { fullName, birthDate = '', gender = 'male' } = req.body || {};
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/cpm/v1.0/api/customer`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
          Accept: '*/*',
          'user-agent': 'MyID/17232 CFNetwork/3860.700.1 Darwin/25.6.0',
        },
        body: JSON.stringify({ birthDate, gender, fullName }),
      })
    );
  });

  app.post('/api/mytel/upload-avatar', async (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const { imageBase64, mimeType = 'image/jpeg' } = req.body || {};
    if (!imageBase64) {
      res.status(400).json({ error: true, message: 'Missing imageBase64' });
      return;
    }
    try {
      const cleanBase64 = String(imageBase64).replace(/^data:[^;]+;base64,/, '');
      const buf = Buffer.from(cleanBase64, 'base64');
      const form = new FormData();
      form.append('file', new Blob([buf], { type: mimeType }), 'avatar.jpg');
      const upstream = await fetch(`${MYTEL_BASE}/cpm/v1.0/api/external-ref/upload?type=avatar_img`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: '*/*',
          'user-agent': 'mocha/2.95 (iPhone; iOS 26.6; Scale/3.00)',
        },
        body: form,
      });
      const text = await upstream.text();
      res.status(upstream.status).send(text);
    } catch (err) {
      res.status(502).json({ error: true, message: err instanceof Error ? err.message : 'Upload failed' });
    }
  });

  app.get('/api/mytel/loyalty-csm', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = String(req.query.phone || '');
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/csm/v1.0/api/loyalty`, {
        headers: {
          ...mytelCommonHeaders(token, phone, deviceId, 'en'),
          session_token: '',
          country_code: 'VN',
          user_id: '0',
          'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 5G Build/SKQ1.211006.001)',
        },
      })
    );
  });

  app.get('/api/mytel/loyalty-inquiry', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    const url = `${MYTEL_BASE}/loyalty/api/v3.1/customer/inquiry?phoneNo=${encodeURIComponent(phone)}`;
    forwardJson(
      res,
      fetch(url, {
        headers: {
          ...mytelCommonHeaders(token, phone, deviceId, 'en'),
          session_token: '',
          country_code: 'VN',
          user_id: '0',
          'Accept-Language': 'EN',
          'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 5G Build/SKQ1.211006.001)',
        },
      })
    );
  });

  app.get('/api/mytel/loyalty-packs', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    const url = `${MYTEL_BASE}/loyalty/api/v3.1/pack?phoneNo=${encodeURIComponent(phone)}`;
    forwardJson(
      res,
      fetch(url, {
        headers: mytelCommonHeaders(token, phone, deviceId, 'en'),
      })
    );
  });

  app.post('/api/mytel/loyalty-exchange', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.body?.phone || ''));
    const rewardCode = String(req.body?.rewardCode || '');
    const requestId = `kp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const requestTime = Date.now();
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/loyalty/api/v3.1/pack/exchange`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'accept-language': 'EN',
          'content-type': 'application/json; charset=utf-8',
          'user-agent': 'okhttp/4.12.0',
        },
        body: JSON.stringify({
          requestId,
          requestTime,
          msisdn: phone,
          rewardCode,
        }),
      })
    );
  });

  app.get('/api/mytel/loyalty-history', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const type = String(req.query.type || 'BURN');
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    const url = `${MYTEL_BASE}/loyalty/api/v3.1/history?phoneNo=${encodeURIComponent(phone)}&type=${encodeURIComponent(type)}&page=0&size=50`;
    forwardJson(
      res,
      fetch(url, {
        headers: mytelCommonHeaders(token, phone, deviceId, 'my'),
      })
    );
  });

  app.post('/api/mytel/loyalty-extend', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhone09(String(req.body?.phone || ''));
    const requestId = `kp_ext_${Date.now()}`;
    const requestTime = String(Date.now());
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/loyalty/api/v3.1/exchanged/extend`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Accept-Language': 'my',
          'content-type': 'application/json',
          'user-agent': 'okhttp/4.12.0',
        },
        body: JSON.stringify({
          requestTime,
          msisdn: phone,
          requestId,
        }),
      })
    );
  });

  app.get('/api/mytel/vas-packs', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    const url = `${MYTEL_BASE}/csm/v1.0/api/vas-package/special-packs?msisdn=${encodeURIComponent(phone)}&language=en`;
    forwardJson(res, fetch(url, { headers: mytelCommonHeaders(token, phone, deviceId, 'en') }));
  });

  app.get('/api/mytel/vas-detail/:code', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const deviceId = String(req.query.deviceId || 'kongpulse-web-01');
    const code = encodeURIComponent(String(req.params.code || ''));
    const url = `${MYTEL_BASE}/csm/v1.0/api/vas-package/${code}?msisdn=${encodeURIComponent(phone)}&language=mu`;
    forwardJson(
      res,
      fetch(url, {
        headers: {
          ...mytelCommonHeaders(token, phone, deviceId, 'my'),
          languageCode: 'my',
          'accept-language': 'my',
          'Accept-Language': 'my',
        },
      })
    );
  });

  app.post('/api/mytel/vas-register/:code', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.body?.phone || ''));
    const code = encodeURIComponent(String(req.params.code || ''));
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/csm/v1.0/api/vas-package/${code}/register`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'content-type': 'application/json; charset=utf-8',
          'user-agent': 'okhttp/4.12.0',
        },
        body: JSON.stringify({ msisdn: phone, isRenew: false }),
      })
    );
  });

  app.get('/api/mytel/daily-quest', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.query.phone || ''));
    const url = `${MYTEL_BASE}/daily-quest-v3/api/v3/daily-quest/main-screen?clientType=Android&Platform=myid&msisdn=${encodeURIComponent(phone)}&revision=16300`;
    forwardJson(
      res,
      fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
          country_code: 'MM',
          countryCode: 'MM',
          language_code: 'my',
          languageCode: 'my',
          'accept-language': 'my',
          'Accept-Language': 'my',
          countrycode: 'MM',
          languagecode: 'my',
          'user-agent': 'okhttp/4.12.0',
        },
      })
    );
  });

  app.post('/api/mytel/daily-claim', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.body?.phone || ''));
    forwardJson(
      res,
      fetch(`${MYTEL_BASE}/daily-quest-v3/api/v3/daily-quest/daily-claim`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          country_code: 'MM',
          countryCode: 'MM',
          language_code: 'my',
          languageCode: 'my',
          'accept-language': 'my',
          'Accept-Language': 'my',
          countrycode: 'MM',
          languagecode: 'my',
          'content-type': 'application/json',
          'user-agent': 'okhttp/4.12.0',
        },
        body: JSON.stringify({
          msisdn: phone,
          platform: 'myid',
          clientType: 'Android',
          revision: 16300,
        }),
      })
    );
  });

  app.post('/api/mytel/mini-quest-claim', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const phone = normalizePhonePlus95(String(req.body?.phone || ''));
    const rawCallback = String(req.body?.urlCallBack || '').trim();
    if (!rawCallback.startsWith(`${MYTEL_BASE}/`)) {
      res.status(400).json({ success: false, message: 'Invalid mini-quest callback URL' });
      return;
    }
    const targetUrl = rawCallback.replace(/\{msisdn\}/gi, encodeURIComponent(phone));
    forwardJson(
      res,
      fetch(targetUrl, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          country_code: 'MM',
          countryCode: 'MM',
          language_code: 'my',
          languageCode: 'my',
          'accept-language': 'my',
          'Accept-Language': 'my',
          countrycode: 'MM',
          languagecode: 'my',
          'user-agent': 'okhttp/4.12.0',
        },
      })
    );
  });

  // =========================================================================
  // KONG ISLAND PROXY ROUTES
  // =========================================================================

  function safeHeaderVal(val: string, fallback = ''): string {
    const cleaned = String(val || '')
      .replace(/[\r\n]+/g, ' ')
      .replace(/[^\x20-\x7E]/g, '')
      .trim();
    return cleaned || fallback;
  }

  app.post('/api/kong/login', async (req: Request, res: Response) => {
    const { thirdPartyToken, mcuid, phone, avatar = '', fullName = '' } = req.body || {};
    if (!thirdPartyToken || !mcuid) {
      res.status(400).json({ success: false, message: 'Missing thirdPartyToken or mcuid' });
      return;
    }

    try {
      const normalized09 = normalizePhone09(String(phone || ''));
      const gwUrl = `${TELCO_GW}?game-code=KONG_ONLINE&mcuid=${encodeURIComponent(String(mcuid))}&mcapp=myid`;
      const gwResp = await fetch(gwUrl, {
        method: 'GET',
        redirect: 'manual',
        headers: {
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X)',
          'access-token': safeHeaderVal(String(thirdPartyToken)),
          'phone-number': safeHeaderVal(normalized09 || normalizePhonePlus95(String(phone || ''))),
          avatar: safeHeaderVal(String(avatar || '')),
          username: safeHeaderVal(String(fullName || ''), normalized09 || 'Player'),
          lang: 'my',
          Accept: 'text/html,application/xhtml+xml,*/*',
        },
      });

      const location = gwResp.headers.get('location') || '';
      let gatewayToken = '';
      if (location) {
        try {
          const parsedUrl = new URL(location, KONG_BASE);
          gatewayToken = parsedUrl.searchParams.get('token') || '';
        } catch {
          const match = location.match(/[?&]token=([^&]+)/);
          if (match) gatewayToken = decodeURIComponent(match[1]);
        }
      }

      if (!gatewayToken) {
        const bodyText = await gwResp.text();
        res.status(502).json({
          success: false,
          message: 'Gateway redirect did not return game token',
          status: gwResp.status,
          detail: bodyText.slice(0, 300),
        });
        return;
      }

      const authResp = await fetch(`${KONG_BASE}/api/auth/login`, {
        method: 'POST',
        headers: {
          accept: '*/*',
          'Accept-Language': 'my',
          'content-type': 'application/json',
          Origin: KONG_BASE,
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X)',
        },
        body: JSON.stringify({ token: gatewayToken }),
      });

      const authData = await authResp.json();
      res.status(authResp.status).json(authData);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Kong login failed',
      });
    }
  });

  function kongHeaders(kongToken: string): Record<string, string> {
    return {
      Authorization: `Bearer ${kongToken}`,
      Accept: '*/*',
      'Accept-Language': 'my',
      'Content-Type': 'application/json',
      Origin: KONG_BASE,
      'User-Agent': 'Mozilla/5.0',
    };
  }

  app.get('/api/kong/user/info', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(res, fetch(`${KONG_BASE}/api/user/info`, { headers: kongHeaders(token) }));
  });

  app.put('/api/kong/user/player-name', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(
      res,
      fetch(`${KONG_BASE}/api/user/player-name`, {
        method: 'PUT',
        headers: kongHeaders(token),
        body: JSON.stringify({ playerName: req.body?.playerName || '' }),
      })
    );
  });

  app.get('/api/kong/avatar/list', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(res, fetch(`${KONG_BASE}/api/avatar/list`, { headers: kongHeaders(token) }));
  });

  app.get('/api/kong/avatar/buy/:id', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(res, fetch(`${KONG_BASE}/api/avatar/buy/${id}`, { headers: kongHeaders(token) }));
  });

  app.get('/api/kong/event/open/:count', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const count = encodeURIComponent(String(req.params.count || '1'));
    forwardJson(res, fetch(`${KONG_BASE}/api/event/open/${count}`, { headers: kongHeaders(token) }));
  });

  app.get('/api/kong/leaderboard/:period', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const period = req.params.period === 'month' ? 'month' : 'week';
    const query = period === 'month' ? 'page=1&size=100&preMonth=False' : 'page=1&size=100&preWeek=False';
    forwardJson(res, fetch(`${KONG_BASE}/api/leaderboard/${period}?${query}`, { headers: kongHeaders(token) }));
  });

  app.get('/api/kong/package/list', async (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const typeFilter = String(req.query.type || '').toUpperCase();
    try {
      const upstream = await fetch(`${KONG_BASE}/api/package/list`, {
        headers: kongHeaders(token),
      });
      const data: any = await upstream.json();
      if (
        upstream.ok &&
        data?.data?.listPackage &&
        Array.isArray(data.data.listPackage) &&
        typeFilter &&
        typeFilter !== 'ALL'
      ) {
        data.data.listPackage = data.data.listPackage.filter((p: any) => {
          const tp = String(p?.typePackage || '').toUpperCase();
          if (typeFilter === 'RENEW') return tp === 'RENEW' || Boolean(p?.autoRenew);
          if (typeFilter === 'RETAIL') return tp !== 'RENEW' && !p?.autoRenew;
          return tp === typeFilter;
        });
      }
      res.status(upstream.status).json(data);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Unable to fetch Kong packages',
      });
    }
  });

  app.post('/api/kong/package/buy', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(
      res,
      fetch(`${KONG_BASE}/api/package/buy-package`, {
        method: 'POST',
        headers: kongHeaders(token),
        body: JSON.stringify({ code: req.body?.code || '' }),
      })
    );
  });

  app.get('/api/kong/shop/item', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(res, fetch(`${KONG_BASE}/api/shop/item`, { headers: kongHeaders(token) }));
  });

  app.post('/api/kong/shop/item', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(
      res,
      fetch(`${KONG_BASE}/api/shop/item`, {
        method: 'POST',
        headers: kongHeaders(token),
        body: JSON.stringify({ id: req.body?.id, value: req.body?.value ?? 1 }),
      })
    );
  });

  app.get('/api/kong/luckSpin/list', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(res, fetch(`${KONG_BASE}/api/luckSpin/list`, { headers: kongHeaders(token) }));
  });

  app.get('/api/kong/luckSpin/spin', (req: Request, res: Response) => {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    forwardJson(res, fetch(`${KONG_BASE}/api/luckSpin/spin`, { headers: kongHeaders(token) }));
  });

  // All 6 Additional Mini-Game Proxy Routes
  registerAllGameRoutes(app);

  // =========================================================================
  // VITE / STATIC SERVING
  // =========================================================================

  const server = http.createServer(app);

  // WebSocket bridges (/ws/kong, /ws/carracing, /ws/fishio)
  const wss = new WebSocketServer({ noServer: true });
  server.on('upgrade', (request, socket, head) => {
    const reqUrl = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    if (handleGameWsUpgrade(reqUrl, wss, request, socket, head)) {
      return;
    }
    if (reqUrl.pathname === '/ws/kong') {
      wss.handleUpgrade(request, socket, head, (clientWs) => {
        const authToken = reqUrl.searchParams.get('authToken') || '';
        if (!authToken) {
          clientWs.close(4001, 'Missing authToken');
          return;
        }
        const upstreamWs = new WebSocket(`${KONG_WS_BASE}?authToken=${encodeURIComponent(authToken)}`, {
          headers: {
            Origin: KONG_BASE,
            'User-Agent': 'Mozilla/5.0',
          },
        });

        upstreamWs.on('open', () => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'BRIDGE_OPEN' }));
          }
        });

        upstreamWs.on('message', (data) => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(data.toString());
          }
        });

        upstreamWs.on('error', (err) => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'BRIDGE_ERROR', message: err.message }));
            clientWs.close(1011, err.message);
          }
        });

        upstreamWs.on('close', (code, reason) => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.close(code || 1000, reason?.toString() || '');
          }
        });

        clientWs.on('message', (data) => {
          if (upstreamWs.readyState === WebSocket.OPEN) {
            upstreamWs.send(data.toString());
          }
        });

        clientWs.on('close', () => {
          if (upstreamWs.readyState === WebSocket.OPEN || upstreamWs.readyState === WebSocket.CONNECTING) {
            upstreamWs.close();
          }
        });
      });
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`KongPulse server listening on http://0.0.0.0:${PORT}`);
  });
}

createServer();
