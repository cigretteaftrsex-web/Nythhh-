import crypto from 'crypto';
import type { Express, Request, Response } from 'express';
import type http from 'http';
import type { Duplex } from 'stream';
import { WebSocket, type WebSocketServer } from 'ws';

const TELCO_GW = 'https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login';
const BEATZOO_BASE = 'https://beatzoo.mascom.vn/api/client-api';
const BEATZOO_API_KEY =
  '60015110c58af6c4a6beec794ab40b89b1042b42cb5380e86daee037cf96ef8b';
const CARRACING_BASE = 'https://car-racing.mascom.vn';
const CARRACING_WS = 'wss://car-racing.mascom.vn/api/ws';
const FISHIO_BASE = 'https://fishio.mascom.vn';
const FISHIO_WS_BASE = 'wss://fishio.mascom.vn/api/ws';
const KITTYFALL_BASE = 'https://kittyfall.com.mm';
const SOFTCLIMBERS_BASE = 'https://api.softclimbers.com';
const MYIDGO_BASE = 'https://pubapi-mygov2.mtgmm.co/v1/engine';

function normalizePhone09(raw: string): string {
  const digits = String(raw || '').trim().replace(/\s+/g, '');
  if (!digits) return '';
  if (digits.startsWith('+95')) return `0${digits.slice(3)}`;
  if (digits.startsWith('95')) return `0${digits.slice(2)}`;
  if (digits.startsWith('0')) return digits;
  return `0${digits}`;
}

function normalizePhonePlus95(raw: string): string {
  const digits = String(raw || '').trim().replace(/\s+/g, '');
  if (!digits) return '';
  if (digits.startsWith('+95')) return digits;
  if (digits.startsWith('95')) return `+${digits}`;
  if (digits.startsWith('0')) return `+95${digits.slice(1)}`;
  return `+95${digits}`;
}

function safeHeaderVal(val: string, fallback = ''): string {
  const cleaned = String(val || '')
    .replace(/[\r\n]+/g, ' ')
    .replace(/[^\x20-\x7E]/g, '')
    .trim();
  return cleaned || fallback;
}

function bearerToken(req: Request): string {
  return String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
}

async function forwardJson(res: Response, upstreamPromise: Promise<globalThis.Response>) {
  try {
    const upstream = await upstreamPromise;
    const text = await upstream.text();
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = { raw: text, success: upstream.ok };
    }
    res.status(upstream.status).json(parsed);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Upstream request failed';
    res.status(502).json({ success: false, error: true, message: msg });
  }
}

async function fetchWithMethodFallback(
  url: string,
  headers: Record<string, string>,
  primaryMethod: 'POST' | 'GET',
  body?: unknown
): Promise<globalThis.Response> {
  const first = await fetch(url, {
    method: primaryMethod,
    headers,
    ...(primaryMethod === 'POST' && body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  if (first.status === 405) {
    const fallbackMethod = primaryMethod === 'POST' ? 'GET' : 'POST';
    return fetch(url, {
      method: fallbackMethod,
      headers,
      ...(fallbackMethod === 'POST' && body !== undefined ? { body: JSON.stringify(body) } : {}),
    });
  }
  return first;
}

async function exchangeTelcoGatewayToken(params: {
  gameCode: string;
  mcuid: string;
  uuid?: string;
  thirdPartyToken: string;
  phone: string;
  avatar?: string;
  fullName?: string;
  fallbackOrigin: string;
}): Promise<{ token?: string; status: number; detail?: string }> {
  const normalized09 = normalizePhone09(params.phone);
  const query = new URLSearchParams({
    'game-code': params.gameCode,
    mcuid: String(params.mcuid),
    mcapp: 'myid',
  });
  if (params.uuid) query.set('uuid', params.uuid);

  const gwUrl = `${TELCO_GW}?${query.toString()}`;
  const gwResp = await fetch(gwUrl, {
    method: 'GET',
    redirect: 'manual',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36',
      'access-token': safeHeaderVal(params.thirdPartyToken),
      'phone-number': safeHeaderVal(normalized09 || normalizePhonePlus95(params.phone)),
      avatar: safeHeaderVal(params.avatar || ''),
      username: safeHeaderVal(params.fullName || '', normalized09 || 'Player'),
      lang: 'my',
      Accept: 'text/html,application/xhtml+xml,*/*',
    },
  });

  const location = gwResp.headers.get('location') || '';
  let gatewayToken = '';
  if (location) {
    try {
      const parsedUrl = new URL(location, params.fallbackOrigin);
      gatewayToken = parsedUrl.searchParams.get('token') || '';
    } catch {
      const match = location.match(/[?&]token=([^&]+)/);
      if (match) gatewayToken = decodeURIComponent(match[1]);
    }
  }
  if (gatewayToken) {
    return { token: gatewayToken, status: gwResp.status };
  }
  const detail = await gwResp.text().catch(() => '');
  return { status: gwResp.status, detail: detail.slice(0, 300) };
}

function applyLocalPackageFilter(data: any, typeFilter: string): any {
  const tf = String(typeFilter || '').toUpperCase();
  if (!tf || tf === 'ALL') return data;
  const list = data?.data?.listPackage || data?.data;
  if (Array.isArray(list)) {
    const filtered = list.filter((p: any) => {
      const tp = String(p?.typePackage || p?.type || '').toUpperCase();
      if (tf === 'RENEW') return tp === 'RENEW' || Boolean(p?.autoRenew);
      if (tf === 'RETAIL') return tp !== 'RENEW' && !p?.autoRenew;
      return tp === tf;
    });
    if (data?.data?.listPackage) data.data.listPackage = filtered;
    else if (Array.isArray(data?.data)) data.data = filtered;
  }
  return data;
}

// ============================================================================
// KITTY FALL HTML PARSERS
// ============================================================================

function mergeCookies(existingCookie: string, setCookieHeaders: string[]): string {
  const jar = new Map<string, string>();
  for (const part of String(existingCookie || '').split(';')) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    const eq = trimmed.indexOf('=');
    if (eq > 0) jar.set(trimmed.slice(0, eq).trim(), trimmed.slice(eq + 1).trim());
  }
  for (const sc of setCookieHeaders) {
    const firstPart = sc.split(';')[0]?.trim() || '';
    const eq = firstPart.indexOf('=');
    if (eq > 0) jar.set(firstPart.slice(0, eq).trim(), firstPart.slice(eq + 1).trim());
  }
  return Array.from(jar.entries())
    .map(([k, v]) => `${k}=${v}`)
    .join('; ');
}

function stripTags(html: string): string {
  return String(html || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractKittyUserInfo(html: string) {
  const msisdnMatch =
    html.match(/class=["'][^"']*profile-copy[^"']*["'][^>]*data-phone=["']([^"']+)["']/i) ||
    html.match(/data-phone=["']([^"']+)["']/i) ||
    html.match(/class=["'][^"']*profile-copy[^"']*["'][^>]*>([^<]+)</i);
  const pointsMatch =
    html.match(/class=["'][^"']*points[^"']*["'][^>]*>\s*([0-9,\.]+)/i) ||
    html.match(/id=["']total-points["'][^>]*>\s*([0-9,\.]+)/i);
  const turnMatch =
    html.match(/data-(?:play-total-turn|total-turn)=["']?([0-9,]+)["']?/i) ||
    html.match(/id=["'](?:total-turn|play-total-turn)["'][^>]*>\s*([0-9,]+)/i);
  const avatarMatch = html.match(/class=["'][^"']*profile-avatar[^"']*["'][^>]*src=["']([^"']+)["']/i);
  const tokenMatch =
    html.match(/data-token=["']([^"']+)["']/i) ||
    html.match(/token\s*[:=]\s*["']([^"']+)["']/i);
  const transIdMatch =
    html.match(/data-transid=["']([^"']+)["']/i) ||
    html.match(/transId\s*[:=]\s*["']([^"']+)["']/i);

  // Parse buy-turn packages from buttons with data-select-buy-turn-package
  const buyTurnPackages: Array<{
    code: string;
    name: string;
    price: string;
    turns: string;
    description: string;
  }> = [];
  const pkgRegex = /<button[^>]*data-select-buy-turn-package[^>]*>([\s\S]*?)<\/button>/gi;
  let pkgMatch: RegExpExecArray | null;
  while ((pkgMatch = pkgRegex.exec(html)) !== null) {
    const attrs = pkgMatch[0];
    const inner = pkgMatch[1];
    const code =
      attrs.match(/data-package-code=["']([^"']+)["']/i)?.[1] ||
      attrs.match(/data-code=["']([^"']+)["']/i)?.[1] ||
      attrs.match(/data-product=["']([^"']+)["']/i)?.[1] ||
      '';
    const price = attrs.match(/data-price=["']([^"']+)["']/i)?.[1] || '';
    const turns = attrs.match(/data-turns?=["']([^"']+)["']/i)?.[1] || '';
    const name =
      attrs.match(/data-name=["']([^"']+)["']/i)?.[1] || stripTags(inner) || code;
    if (code) {
      buyTurnPackages.push({
        code,
        name,
        price,
        turns,
        description: stripTags(inner),
      });
    }
  }

  // Parse subscription package card
  let dailySubscription: { code: string; name: string; status: string; rawText: string } | null = null;
  const subCardMatch = html.match(
    /<(?:div|button|a)[^>]*data-open-subscription[^>]*>([\s\S]*?)<\/(?:div|button|a)>/i
  );
  if (subCardMatch) {
    const attrs = subCardMatch[0];
    const code =
      attrs.match(/data-package-code=["']([^"']+)["']/i)?.[1] ||
      attrs.match(/data-code=["']([^"']+)["']/i)?.[1] ||
      attrs.match(/data-product=["']([^"']+)["']/i)?.[1] ||
      'DAILY';
    const rawText = stripTags(subCardMatch[1]);
    dailySubscription = {
      code,
      name: attrs.match(/data-name=["']([^"']+)["']/i)?.[1] || 'Daily Subscription',
      status: attrs.match(/data-status=["']([^"']+)["']/i)?.[1] || '',
      rawText,
    };
  }

  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const points = Number(String(pointsMatch?.[1] || '0').replace(/,/g, '')) || 0;
  const turns = Number(String(turnMatch?.[1] || '0').replace(/,/g, '')) || 0;
  const needsRegistration =
    /register|subscribe|not registered/i.test(stripTags(html).slice(0, 600)) &&
    !msisdnMatch &&
    turns === 0;

  return {
    msisdn: msisdnMatch?.[1]?.trim() || '',
    points,
    turns,
    avatar: avatarMatch?.[1]
      ? avatarMatch[1].startsWith('http')
        ? avatarMatch[1]
        : `${KITTYFALL_BASE}${avatarMatch[1].startsWith('/') ? '' : '/'}${avatarMatch[1]}`
      : '',
    sessionToken: tokenMatch?.[1] || '',
    transId: transIdMatch?.[1] || '',
    buyTurnPackages,
    dailySubscription,
    needsRegistration,
    title: stripTags(titleMatch?.[1] || 'Kitty Fall'),
  };
}

function parseKittyLeaderboard(html: string) {
  const rows: Array<{
    rank: number;
    phone: string;
    score: string;
    reward: string;
    isMe: boolean;
  }> = [];

  const rowRegex = /<div[^>]*data-rank-row[^>]*>([\s\S]*?)<\/div>\s*(?=<div[^>]*data-rank-row|<\/section|<\/div|$)/gi;
  const simpleRowRegex = /<(?:div|tr|li)[^>]*class=["'][^"']*(?:rank-row|leaderboard-row)[^"']*["'][^>]*>([\s\S]*?)<\/(?:div|tr|li)>/gi;
  let matched = false;
  let m: RegExpExecArray | null;

  while ((m = rowRegex.exec(html)) !== null) {
    matched = true;
    const block = m[0];
    const rankNum = Number(
      block.match(/data-rank=["']?(\d+)/i)?.[1] ||
        stripTags(block).match(/^#?(\d+)/)?.[1] ||
        rows.length + 1
    );
    const phone =
      block.match(/class=["'][^"']*leaderboard-phone[^"']*["'][^>]*>([^<]+)</i)?.[1]?.trim() ||
      stripTags(block).match(/(09\d[\d*xX]+|\+95\d[\d*xX]+)/)?.[1] ||
      'Player';
    const score =
      block.match(/class=["'][^"']*(?:score|points)[^"']*["'][^>]*>([^<]+)</i)?.[1]?.trim() || '0';
    const reward =
      block.match(/class=["'][^"']*(?:reward|prize)[^"']*["'][^>]*>([^<]+)</i)?.[1]?.trim() || '';
    const isMe = /leaderboard-my-badge/i.test(block);
    rows.push({ rank: rankNum, phone, score, reward, isMe });
  }

  if (!matched) {
    while ((m = simpleRowRegex.exec(html)) !== null) {
      const text = stripTags(m[0]);
      const phone =
        m[0].match(/class=["'][^"']*leaderboard-phone[^"']*["'][^>]*>([^<]+)</i)?.[1]?.trim() ||
        text.match(/(09[\d*xX]+)/)?.[1] ||
        'Player';
      const nums = text.match(/\b\d[\d,]*\b/g) || [];
      rows.push({
        rank: Number(nums[0]?.replace(/,/g, '')) || rows.length + 1,
        phone,
        score: nums[nums.length - 1] || '0',
        reward: '',
        isMe: /leaderboard-my-badge/i.test(m[0]),
      });
    }
  }

  const myBadgeMatch = html.match(/class=["'][^"']*leaderboard-my-badge[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
  const myRankSummary = myBadgeMatch ? stripTags(myBadgeMatch[1]) : '';
  const hasNext = /pageNumber=\d+/i.test(html) && /next/i.test(html);

  return { rows, myRankSummary, hasNext };
}

function parseKittyHistory(html: string) {
  const items: Array<{
    date: string;
    title: string;
    detail: string;
    pointsOrPrize: string;
    status: string;
  }> = [];
  const rowRegex = /<div class="history-row"[^>]*>([\s\S]*?)<\/div>/gi;
  let m: RegExpExecArray | null;
  while ((m = rowRegex.exec(html)) !== null) {
    const inner = m[1];
    const spans = Array.from(inner.matchAll(/<span[^>]*>([\s\S]*?)<\/span>/gi)).map((s) =>
      stripTags(s[1])
    );
    const cleaned = spans.filter(Boolean);
    if (cleaned.length >= 2) {
      items.push({
        date: cleaned[0] || '',
        title: cleaned[1] || 'Reward',
        detail: cleaned[2] || '',
        pointsOrPrize: cleaned[3] || cleaned[1] || '',
        status: cleaned[cleaned.length - 1] || '',
      });
    } else {
      const text = stripTags(inner);
      if (text) {
        items.push({ date: '', title: text, detail: '', pointsOrPrize: '', status: '' });
      }
    }
  }
  return items;
}

// ============================================================================
// MAIN ROUTE REGISTRATION
// ============================================================================

export function registerAllGameRoutes(app: Express): void {
  // --------------------------------------------------------------------------
  // 1. BEAT ZOO (https://beatzoo.mascom.vn/api/client-api)
  // --------------------------------------------------------------------------
  const beatHeaders = (jwt?: string): Record<string, string> => ({
    'x-api-key': BEATZOO_API_KEY,
    ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}),
    Accept: '*/*',
    'Accept-Language': 'my',
    'Content-Type': 'application/json',
    Origin: 'https://beatzoo.mascom.vn',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36',
  });

  app.post('/api/beatzoo/login', async (req: Request, res: Response) => {
    const { thirdPartyToken, mcuid, phone = '', avatar = '', fullName = '' } = req.body || {};
    if (!thirdPartyToken || !mcuid) {
      res.status(400).json({ success: false, message: 'Missing thirdPartyToken or mcuid' });
      return;
    }
    try {
      const gw = await exchangeTelcoGatewayToken({
        gameCode: 'BEAT_ZOO',
        mcuid: String(mcuid),
        thirdPartyToken: String(thirdPartyToken),
        phone: String(phone),
        avatar: String(avatar),
        fullName: String(fullName),
        fallbackOrigin: 'https://beatzoo.mascom.vn',
      });
      if (!gw.token) {
        res.status(502).json({
          success: false,
          message: 'Beat Zoo gateway did not return token',
          status: gw.status,
          detail: gw.detail,
        });
        return;
      }
      const authResp = await fetch(`${BEATZOO_BASE}/token-auth`, {
        method: 'POST',
        headers: beatHeaders(),
        body: JSON.stringify({ token: gw.token }),
      });
      const text = await authResp.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { raw: text };
      }
      res.status(authResp.status).json(parsed);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Beat Zoo login failed',
      });
    }
  });

  app.get('/api/beatzoo/balance', async (req, res) => {
    const headers = beatHeaders(bearerToken(req));
    try {
      let r = await fetch(`${BEATZOO_BASE}/balance`, { headers });
      if (r.status === 404) {
        r = await fetch(`${BEATZOO_BASE}/currency`, { headers });
      }
      const text = await r.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { success: r.ok, raw: text };
      }
      res.status(r.status).json(parsed);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Beat Zoo balance failed',
      });
    }
  });

  app.get('/api/beatzoo/currency/:code', async (req, res) => {
    const code = encodeURIComponent(String(req.params.code || 'ticket'));
    const headers = beatHeaders(bearerToken(req));
    try {
      let r = await fetch(`${BEATZOO_BASE}/currency/${code}`, { headers });
      if (r.status === 404) {
        r = await fetch(`${BEATZOO_BASE}/currency`, { headers });
      }
      const text = await r.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { success: r.ok, raw: text };
      }
      res.status(r.status).json(parsed);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Beat Zoo currency failed',
      });
    }
  });

  app.get('/api/beatzoo/songs/top', (req, res) => {
    forwardJson(res, fetch(`${BEATZOO_BASE}/songs/top`, { headers: beatHeaders(bearerToken(req)) }));
  });

  app.post('/api/beatzoo/songs/buy', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/songs/buy`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({ song_id: req.body?.song_id }),
      })
    );
  });

  app.post('/api/beatzoo/game-play/start', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/game-play/start`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({ song_id: req.body?.song_id }),
      })
    );
  });

  app.post('/api/beatzoo/songs/save-score', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/songs/save-score`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({
          song_id: req.body?.song_id,
          score: Number(req.body?.score ?? 0),
          mode: req.body?.mode === 'hard' ? 'hard' : 'easy',
        }),
      })
    );
  });

  app.get('/api/beatzoo/leaderboard', (req, res) => {
    const type = encodeURIComponent(String(req.query.type || 'weekly'));
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/leaderboard?type=${type}`, { headers: beatHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/beatzoo/missions', (req, res) => {
    forwardJson(res, fetch(`${BEATZOO_BASE}/missions`, { headers: beatHeaders(bearerToken(req)) }));
  });

  app.post('/api/beatzoo/missions/claim', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/missions/claim`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({ mission_id: req.body?.mission_id }),
      })
    );
  });

  app.get('/api/beatzoo/shop/items/:kind', (req, res) => {
    const kind = req.params.kind === 'external' ? 'external' : 'internal';
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/shop/items/${kind}`, { headers: beatHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/beatzoo/cart/buy/internal', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/cart/buy/internal`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({
          item_code: req.body?.item_code,
          note: req.body?.note || '',
        }),
      })
    );
  });

  app.post('/api/beatzoo/payment/package', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/payment/package`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({ code: req.body?.code }),
      })
    );
  });

  app.get('/api/beatzoo/lucky-wheel/prizes', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/lucky-wheel/prizes`, { headers: beatHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/beatzoo/lucky-wheel/spin', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/lucky-wheel/spin`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({}),
      })
    );
  });

  app.post('/api/beatzoo/name', (req, res) => {
    forwardJson(
      res,
      fetch(`${BEATZOO_BASE}/name`, {
        method: 'POST',
        headers: beatHeaders(bearerToken(req)),
        body: JSON.stringify({ name: req.body?.name || '' }),
      })
    );
  });

  // --------------------------------------------------------------------------
  // 2. CAR RACING (https://car-racing.mascom.vn)
  // --------------------------------------------------------------------------
  const carHeaders = (jwt?: string): Record<string, string> => ({
    ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}),
    Accept: '*/*',
    'Accept-Language': 'my',
    'Content-Type': 'application/json',
    Origin: CARRACING_BASE,
    'X-Requested-With': 'com.myentertainment.oneid',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36',
  });

  app.post('/api/carracing/login', async (req: Request, res: Response) => {
    const { thirdPartyToken, mcuid, uuid, phone = '', avatar = '', fullName = '' } = req.body || {};
    if (!thirdPartyToken || !mcuid) {
      res.status(400).json({ success: false, message: 'Missing thirdPartyToken or mcuid' });
      return;
    }
    try {
      const gw = await exchangeTelcoGatewayToken({
        gameCode: 'CAR_ONLINE',
        mcuid: String(mcuid),
        uuid: String(uuid || mcuid),
        thirdPartyToken: String(thirdPartyToken),
        phone: String(phone),
        avatar: String(avatar),
        fullName: String(fullName),
        fallbackOrigin: CARRACING_BASE,
      });
      if (!gw.token) {
        res.status(502).json({
          success: false,
          message: 'Car Racing gateway did not return token',
          status: gw.status,
          detail: gw.detail,
        });
        return;
      }
      const authResp = await fetch(`${CARRACING_BASE}/api/auth/login`, {
        method: 'POST',
        headers: carHeaders(),
        body: JSON.stringify({ token: gw.token }),
      });
      const text = await authResp.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { raw: text };
      }
      res.status(authResp.status).json(parsed);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Car Racing login failed',
      });
    }
  });

  app.get('/api/carracing/user/info', (req, res) => {
    forwardJson(res, fetch(`${CARRACING_BASE}/api/user/info`, { headers: carHeaders(bearerToken(req)) }));
  });

  app.put('/api/carracing/user/player-name', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/user/player-name`, {
        method: 'PUT',
        headers: carHeaders(bearerToken(req)),
        body: JSON.stringify({ playerName: req.body?.playerName || '' }),
      })
    );
  });

  app.get('/api/carracing/avatar/list', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/avatar/list`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/carracing/avatar/buy/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/avatar/buy/${id}`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/carracing/car/buy-or-use/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/car/buy-or-use/${id}`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/carracing/game-pvp/check/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/game-pvp/check/${id}`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/carracing/game-pvp/suggest-cars/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/game-pvp/suggest-cars/${id}`, {
        headers: carHeaders(bearerToken(req)),
      })
    );
  });

  app.get('/api/carracing/leaderboard/config-pvp', (req, res) => {
    const typeItem = encodeURIComponent(String(req.query.typeItem || 'COIN'));
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/leaderboard/config-pvp?typeItem=${typeItem}`, {
        headers: carHeaders(bearerToken(req)),
      })
    );
  });

  app.get('/api/carracing/leaderboard/type', (req, res) => {
    const typeConfigRank = encodeURIComponent(String(req.query.typeConfigRank || 'RANK_MONTH'));
    const typeRank = encodeURIComponent(String(req.query.typeRank || 'DISTANCE'));
    forwardJson(
      res,
      fetch(
        `${CARRACING_BASE}/api/leaderboard/type?typeConfigRank=${typeConfigRank}&typeRank=${typeRank}`,
        { headers: carHeaders(bearerToken(req)) }
      )
    );
  });

  app.get('/api/carracing/shop/gem', (req, res) => {
    forwardJson(res, fetch(`${CARRACING_BASE}/api/shop/GEM`, { headers: carHeaders(bearerToken(req)) }));
  });

  app.post('/api/carracing/shop/buy', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/shop/buy`, {
        method: 'POST',
        headers: carHeaders(bearerToken(req)),
        body: JSON.stringify({
          typeCurrency: req.body?.typeCurrency || 'GEM',
          id: req.body?.id,
        }),
      })
    );
  });

  app.get('/api/carracing/package/list', async (req, res) => {
    try {
      const upstream = await fetch(`${CARRACING_BASE}/api/package/list`, {
        headers: carHeaders(bearerToken(req)),
      });
      const text = await upstream.text();
      let data: any;
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }
      if (upstream.ok) {
        data = applyLocalPackageFilter(data, String(req.query.type || 'ALL'));
      }
      res.status(upstream.status).json(data);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Unable to load Car Racing packages',
      });
    }
  });

  app.post('/api/carracing/package/buy', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/package/buy-package`, {
        method: 'POST',
        headers: carHeaders(bearerToken(req)),
        body: JSON.stringify({ code: req.body?.code || '' }),
      })
    );
  });

  app.get('/api/carracing/achievement', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/achievement`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/carracing/achievement/claim/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetchWithMethodFallback(
        `${CARRACING_BASE}/api/achievement/claim/${id}`,
        carHeaders(bearerToken(req)),
        'POST',
        {}
      )
    );
  });

  app.get('/api/carracing/task/daily-login', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/task/daily-login`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/carracing/task/daily-login/claim/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetchWithMethodFallback(
        `${CARRACING_BASE}/api/task/daily-login/claim/${id}`,
        carHeaders(bearerToken(req)),
        'POST',
        {}
      )
    );
  });

  app.get('/api/carracing/task/user', (req, res) => {
    forwardJson(res, fetch(`${CARRACING_BASE}/api/task/user/`, { headers: carHeaders(bearerToken(req)) }));
  });

  app.post('/api/carracing/task/user/claim/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetchWithMethodFallback(
        `${CARRACING_BASE}/api/task/user/claim/${id}`,
        carHeaders(bearerToken(req)),
        'POST',
        {}
      )
    );
  });

  app.get('/api/carracing/lucky-spin', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/lucky-spin/LUCKY_SPIN`, { headers: carHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/carracing/lucky-spin/spin', (req, res) => {
    forwardJson(
      res,
      fetch(`${CARRACING_BASE}/api/lucky-spin/spin`, {
        method: 'POST',
        headers: carHeaders(bearerToken(req)),
        body: JSON.stringify({}),
      })
    );
  });

  // --------------------------------------------------------------------------
  // 3. FIGHTING FISH (https://fishio.mascom.vn)
  // --------------------------------------------------------------------------
  const fishHeaders = (jwt?: string): Record<string, string> => ({
    ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}),
    Accept: '*/*',
    'Accept-Language': 'my',
    'Content-Type': 'application/json',
    Origin: FISHIO_BASE,
    'X-Requested-With': 'com.myentertainment.oneid',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36',
  });

  app.post('/api/fishio/login', async (req: Request, res: Response) => {
    const { thirdPartyToken, mcuid, uuid, phone = '', avatar = '', fullName = '' } = req.body || {};
    if (!thirdPartyToken || !mcuid) {
      res.status(400).json({ success: false, message: 'Missing thirdPartyToken or mcuid' });
      return;
    }
    try {
      const gw = await exchangeTelcoGatewayToken({
        gameCode: 'FISH_IO',
        mcuid: String(mcuid),
        uuid: String(uuid || mcuid),
        thirdPartyToken: String(thirdPartyToken),
        phone: String(phone),
        avatar: String(avatar),
        fullName: String(fullName),
        fallbackOrigin: FISHIO_BASE,
      });
      if (!gw.token) {
        res.status(502).json({
          success: false,
          message: 'Fighting Fish gateway did not return token',
          status: gw.status,
          detail: gw.detail,
        });
        return;
      }
      const authResp = await fetch(`${FISHIO_BASE}/api/auth/login`, {
        method: 'POST',
        headers: fishHeaders(),
        body: JSON.stringify({ token: gw.token }),
      });
      const text = await authResp.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { raw: text };
      }
      res.status(authResp.status).json(parsed);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Fighting Fish login failed',
      });
    }
  });

  app.post('/api/fishio/refresh', (req, res) => {
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/auth/refresh`, {
        method: 'POST',
        headers: fishHeaders(),
        body: JSON.stringify({ refreshToken: req.body?.refreshToken || '' }),
      })
    );
  });

  app.get('/api/fishio/user/info', (req, res) => {
    forwardJson(res, fetch(`${FISHIO_BASE}/api/user/info`, { headers: fishHeaders(bearerToken(req)) }));
  });

  app.put('/api/fishio/user/player-name', (req, res) => {
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/user/player-name`, {
        method: 'PUT',
        headers: fishHeaders(bearerToken(req)),
        body: JSON.stringify({ playerName: req.body?.playerName || '' }),
      })
    );
  });

  app.get('/api/fishio/avatar/list', (req, res) => {
    forwardJson(res, fetch(`${FISHIO_BASE}/api/avatar/list`, { headers: fishHeaders(bearerToken(req)) }));
  });

  app.get('/api/fishio/avatar/buy/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/avatar/buy/${id}`, { headers: fishHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/fishio/leaderboard/rank', (req, res) => {
    const rankType = encodeURIComponent(String(req.query.rankType || 'WEEK'));
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/leaderboard/rank?rankType=${rankType}`, {
        headers: fishHeaders(bearerToken(req)),
      })
    );
  });

  app.get('/api/fishio/shop/item', (req, res) => {
    const typeCurrency = encodeURIComponent(String(req.query.typeCurrency || 'GEM'));
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/shop/item?typeCurrency=${typeCurrency}`, {
        headers: fishHeaders(bearerToken(req)),
      })
    );
  });

  app.post('/api/fishio/shop/item', (req, res) => {
    const quantity = Number(req.body?.quantity ?? 1);
    const price = Number(req.body?.price ?? 0);
    const amount = req.body?.amount !== undefined ? Number(req.body.amount) : price * quantity;
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/shop/item`, {
        method: 'POST',
        headers: fishHeaders(bearerToken(req)),
        body: JSON.stringify({
          code: req.body?.code,
          value: req.body?.value,
          quantity,
          amount,
        }),
      })
    );
  });

  app.get('/api/fishio/package/list', async (req, res) => {
    try {
      const upstream = await fetch(`${FISHIO_BASE}/api/package/list`, {
        headers: fishHeaders(bearerToken(req)),
      });
      const text = await upstream.text();
      let data: any;
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }
      if (upstream.ok) {
        data = applyLocalPackageFilter(data, String(req.query.type || 'ALL'));
      }
      res.status(upstream.status).json(data);
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Unable to fetch Fighting Fish packages',
      });
    }
  });

  app.post('/api/fishio/package/buy', (req, res) => {
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/package/buy-package`, {
        method: 'POST',
        headers: fishHeaders(bearerToken(req)),
        body: JSON.stringify({ code: req.body?.code || '' }),
      })
    );
  });

  app.get('/api/fishio/achievement/list', (req, res) => {
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/achievement/list`, { headers: fishHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/fishio/achievement/claim/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetchWithMethodFallback(
        `${FISHIO_BASE}/api/achievement/claim/${id}`,
        fishHeaders(bearerToken(req)),
        'GET'
      )
    );
  });

  app.get('/api/fishio/task/list', (req, res) => {
    const type = encodeURIComponent(String(req.query.type || 'DAILY'));
    forwardJson(
      res,
      fetch(`${FISHIO_BASE}/api/task/list?type=${type}`, { headers: fishHeaders(bearerToken(req)) })
    );
  });

  app.post('/api/fishio/task/award/:id', (req, res) => {
    const id = encodeURIComponent(String(req.params.id || ''));
    forwardJson(
      res,
      fetchWithMethodFallback(
        `${FISHIO_BASE}/api/task/award/${id}`,
        fishHeaders(bearerToken(req)),
        'GET'
      )
    );
  });

  // --------------------------------------------------------------------------
  // 4. KITTY FALL (https://kittyfall.com.mm)
  // --------------------------------------------------------------------------
  const kittyCommonHeaders = (
    cookie: string,
    extra: Record<string, string> = {}
  ): Record<string, string> => ({
    Accept: 'text/html,application/xhtml+xml,application/json,*/*',
    'User-Agent': 'ZenoMyID-KittyFall/1.0',
    ...(cookie ? { Cookie: safeHeaderVal(cookie) } : {}),
    ...extra,
  });

  app.post('/api/kittyfall/bootstrap', async (req: Request, res: Response) => {
    const { thirdPartyToken = '', phone = '', lang = 'mu', cookie = '' } = req.body || {};
    if (!thirdPartyToken && !cookie) {
      res.status(400).json({ success: false, message: 'Missing thirdPartyToken or cookie' });
      return;
    }
    try {
      const normalized09 = normalizePhone09(String(phone || ''));
      const upstream = await fetch(`${KITTYFALL_BASE}/?mcuid=android-app&mcapp=myid`, {
        method: 'GET',
        headers: kittyCommonHeaders(String(cookie || ''), {
          'access-token': safeHeaderVal(String(thirdPartyToken)),
          'phone-number': safeHeaderVal(normalized09 || normalizePhonePlus95(String(phone || ''))),
          lang: safeHeaderVal(String(lang || 'mu'), 'mu'),
        }),
      });
      const setCookies =
        typeof (upstream.headers as any).getSetCookie === 'function'
          ? (upstream.headers as any).getSetCookie()
          : upstream.headers.get('set-cookie')
          ? [upstream.headers.get('set-cookie') as string]
          : [];
      const mergedCookie = mergeCookies(String(cookie || ''), setCookies);
      const html = await upstream.text();
      const parsed = extractKittyUserInfo(html);
      res.status(upstream.ok ? 200 : upstream.status).json({
        success: upstream.ok,
        cookie: mergedCookie,
        data: parsed,
      });
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Kitty Fall bootstrap failed',
      });
    }
  });

  app.post('/api/kittyfall/start-session', (req, res) => {
    const {
      cookie = '',
      msisdn = '',
      token = '',
      transId = '',
      gameType = 'catpuzzle',
      level = 1,
      score = 0,
      gameOver = 0,
    } = req.body || {};
    forwardJson(
      res,
      fetch(`${KITTYFALL_BASE}/Game/StartSession`, {
        method: 'POST',
        headers: kittyCommonHeaders(String(cookie), {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Origin: KITTYFALL_BASE,
          Referer: `${KITTYFALL_BASE}/Play`,
        }),
        body: JSON.stringify({ msisdn, token, transId, gameType, level, score, gameOver }),
      })
    );
  });

  app.post('/api/kittyfall/save-result', (req, res) => {
    const {
      cookie = '',
      token = '',
      msisdn = '',
      transId = '',
      level = 1,
      score = 0,
      gameType = 'catpuzzle',
      gameOver = 0,
    } = req.body || {};
    forwardJson(
      res,
      fetch(`${KITTYFALL_BASE}/Game/SaveLevelResult`, {
        method: 'POST',
        headers: kittyCommonHeaders(String(cookie), {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Origin: KITTYFALL_BASE,
          Referer: `${KITTYFALL_BASE}/catpuzzle/index.html`,
        }),
        body: JSON.stringify({ token, msisdn, transId, level, score, gameType, gameOver }),
      })
    );
  });

  app.get('/api/kittyfall/leaderboard', async (req, res) => {
    const cookie = String(req.headers['x-kitty-cookie'] || '');
    const pageNumber = Math.max(1, Number(req.query.pageNumber || 1));
    try {
      const upstream = await fetch(`${KITTYFALL_BASE}/Leaderboard?pageNumber=${pageNumber}`, {
        headers: kittyCommonHeaders(cookie),
      });
      const html = await upstream.text();
      const data = parseKittyLeaderboard(html);
      res.status(upstream.ok ? 200 : upstream.status).json({
        success: upstream.ok,
        pageNumber,
        data,
      });
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Unable to fetch Kitty Fall leaderboard',
      });
    }
  });

  app.get('/api/kittyfall/history', async (req, res) => {
    const cookie = String(req.headers['x-kitty-cookie'] || '');
    try {
      const upstream = await fetch(`${KITTYFALL_BASE}/History`, {
        headers: kittyCommonHeaders(cookie),
      });
      const html = await upstream.text();
      const items = parseKittyHistory(html);
      res.status(upstream.ok ? 200 : upstream.status).json({
        success: upstream.ok,
        data: items,
      });
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Unable to fetch Kitty Fall history',
      });
    }
  });

  app.post('/api/kittyfall/buy-turn', (req, res) => {
    const { cookie = '', productName = '' } = req.body || {};
    forwardJson(
      res,
      fetch(`${KITTYFALL_BASE}/Home/BuyTurnQAction`, {
        method: 'POST',
        headers: kittyCommonHeaders(String(cookie), {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'x-requested-with': 'XMLHttpRequest',
          Accept: 'application/json, text/plain, */*',
          Origin: KITTYFALL_BASE,
          Referer: `${KITTYFALL_BASE}/`,
        }),
        body: new URLSearchParams({ productName: String(productName) }).toString(),
      })
    );
  });

  app.post('/api/kittyfall/register-sub', (req, res) => {
    const { cookie = '', productName = '' } = req.body || {};
    forwardJson(
      res,
      fetch(`${KITTYFALL_BASE}/Home/RegisterQAction`, {
        method: 'POST',
        headers: kittyCommonHeaders(String(cookie), {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'x-requested-with': 'XMLHttpRequest',
          Accept: 'application/json, text/plain, */*',
          Origin: KITTYFALL_BASE,
          Referer: `${KITTYFALL_BASE}/`,
        }),
        body: new URLSearchParams({ productName: String(productName) }).toString(),
      })
    );
  });

  // --------------------------------------------------------------------------
  // 5. SOFT CLIMBERS (https://api.softclimbers.com)
  // --------------------------------------------------------------------------
  const scHeaders = (token?: string, msisdn?: string): Record<string, string> => ({
    ...(token ? { Authorization: `Bearer ${token}`, 'access-token': token } : {}),
    ...(msisdn
      ? {
          'phone-number': safeHeaderVal(normalizePhone09(msisdn)),
          msisdn: safeHeaderVal(normalizePhone09(msisdn)),
        }
      : {}),
    Accept: 'application/json',
    'Content-Type': 'application/json',
    Origin: 'http://game.softclimbers.com',
    'User-Agent': 'ZenoMyID/2.0',
  });

  app.post('/api/softclimbers/login', (req, res) => {
    const { msisdn = '', accessToken = '', avatar = '', username = '', lang = 'mu' } = req.body || {};
    if (!accessToken || !msisdn) {
      res.status(400).json({ success: false, message: 'Missing accessToken or msisdn' });
      return;
    }
    const normalized = normalizePhone09(String(msisdn));
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/auth/login`, {
        method: 'POST',
        headers: scHeaders(),
        body: JSON.stringify({
          msisdn: normalized,
          accessToken,
          avatar: avatar || '',
          username: username || normalized,
          lang: lang || 'mu',
        }),
      })
    );
  });

  app.get('/api/softclimbers/subscription/status', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || req.query.msisdn || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/subscription/status`, {
        headers: scHeaders(bearerToken(req), msisdn),
      })
    );
  });

  app.get('/api/softclimbers/leaderboard', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || '');
    const type = encodeURIComponent(String(req.query.type || 'WEEK'));
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/leaderboard?type=${type}`, {
        headers: scHeaders(bearerToken(req), msisdn),
      })
    );
  });

  app.get('/api/softclimbers/prize-history', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || '');
    const page = encodeURIComponent(String(req.query.page || 1));
    const size = encodeURIComponent(String(req.query.size || 20));
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/prize-history?page=${page}&size=${size}`, {
        headers: scHeaders(bearerToken(req), msisdn),
      })
    );
  });

  app.get('/api/softclimbers/plans/one-time', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/plans/one-time`, {
        headers: scHeaders(bearerToken(req), msisdn),
      })
    );
  });

  app.post('/api/softclimbers/attempts/purchase', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || req.body?.msisdn || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/attempts/purchase`, {
        method: 'POST',
        headers: scHeaders(bearerToken(req), msisdn),
        body: JSON.stringify({ planId: req.body?.planId }),
      })
    );
  });

  app.post('/api/softclimbers/subscription/subscribe', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || req.body?.msisdn || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/subscription/subscribe`, {
        method: 'POST',
        headers: scHeaders(bearerToken(req), msisdn),
        body: JSON.stringify({ planId: req.body?.planId }),
      })
    );
  });

  app.post('/api/softclimbers/game/start', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || req.body?.msisdn || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/game/start`, {
        method: 'POST',
        headers: scHeaders(bearerToken(req), msisdn),
        body: JSON.stringify({ level: Number(req.body?.level ?? 1) }),
      })
    );
  });

  app.post('/api/softclimbers/game/event', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || req.body?.msisdn || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/game/event`, {
        method: 'POST',
        headers: scHeaders(bearerToken(req), msisdn),
        body: JSON.stringify({
          sessionId: req.body?.sessionId,
          level: Number(req.body?.level ?? 1),
          score: Number(req.body?.score ?? 0),
          coins: Number(req.body?.coins ?? 0),
          distance: Number(req.body?.distance ?? 0),
          eventType: req.body?.eventType || 'LEVEL_CLEAR',
        }),
      })
    );
  });

  app.post('/api/softclimbers/game/end', (req, res) => {
    const msisdn = String(req.headers['x-phone'] || req.body?.msisdn || '');
    forwardJson(
      res,
      fetch(`${SOFTCLIMBERS_BASE}/api/v1/game/end`, {
        method: 'POST',
        headers: scHeaders(bearerToken(req), msisdn),
        body: JSON.stringify({
          sessionId: req.body?.sessionId,
          finalLevel: Number(req.body?.finalLevel ?? 1),
          finalScore: Number(req.body?.finalScore ?? 0),
          distance: Number(req.body?.distance ?? 0),
          reason: req.body?.reason || 'GAME_OVER',
        }),
      })
    );
  });

  // --------------------------------------------------------------------------
  // 6. MYID GO (https://pubapi-mygov2.mtgmm.co/v1/engine)
  // --------------------------------------------------------------------------
  const goHeaders = (jwt?: string): Record<string, string> => ({
    ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}),
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'User-Agent': 'MyID/1.0.300 (Android)',
  });

  app.post('/api/myidgo/login', async (req: Request, res: Response) => {
    const {
      thirdPartyToken = '',
      mcuid = '',
      uuid = '',
      phone = '',
      avatar = '',
      fullName = '',
    } = req.body || {};
    if (!thirdPartyToken || !mcuid) {
      res.status(400).json({ success: false, message: 'Missing thirdPartyToken or mcuid' });
      return;
    }
    try {
      const normalized09 = normalizePhone09(String(phone || ''));
      const url = `${MYIDGO_BASE}/web/bootstrap.html?uuid=${encodeURIComponent(
        String(uuid || mcuid)
      )}&mcuid=${encodeURIComponent(String(mcuid))}`;
      const resp = await fetch(url, {
        method: 'GET',
        redirect: 'manual',
        headers: {
          'access-token': safeHeaderVal(String(thirdPartyToken)),
          'phone-number': safeHeaderVal(normalized09 || normalizePhonePlus95(String(phone || ''))),
          avatar: safeHeaderVal(String(avatar || '')),
          fullname: safeHeaderVal(String(fullName || ''), normalized09 || 'Player'),
          Accept: 'text/html,application/json',
          'User-Agent': 'MyID/1.0.300 (Android)',
        },
      });
      const location = resp.headers.get('location') || '';
      let token = '';
      if (location) {
        try {
          const parsedUrl = new URL(location, MYIDGO_BASE);
          token = parsedUrl.searchParams.get('token') || '';
        } catch {
          const match = location.match(/[?&]token=([^&]+)/);
          if (match) token = decodeURIComponent(match[1]);
        }
      }
      const bodyText = await resp.text().catch(() => '');
      if (!token && bodyText) {
        try {
          const j = JSON.parse(bodyText);
          token = j?.token || j?.data?.token || '';
        } catch {
          const m = bodyText.match(/[?&]token=([^&"'\s<>]+)/);
          if (m) token = decodeURIComponent(m[1]);
        }
      }
      if (!token) {
        res.status(502).json({
          success: false,
          message: 'MyID Go bootstrap did not return a session token',
          status: resp.status,
          detail: bodyText.slice(0, 300),
        });
        return;
      }
      res.json({ success: true, token });
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'MyID Go login failed',
      });
    }
  });

  app.get('/api/myidgo/user/profile', (req, res) => {
    forwardJson(res, fetch(`${MYIDGO_BASE}/user/profile`, { headers: goHeaders(bearerToken(req)) }));
  });

  app.get('/api/myidgo/user/avatar/default', (req, res) => {
    forwardJson(
      res,
      fetch(`${MYIDGO_BASE}/user/avatar/default`, { headers: goHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/myidgo/game/start', (req, res) => {
    forwardJson(res, fetch(`${MYIDGO_BASE}/game/start`, { headers: goHeaders(bearerToken(req)) }));
  });

  app.get('/api/myidgo/game/reward', (req, res) => {
    const slotIndex = encodeURIComponent(String(req.query.slot_index ?? 5));
    forwardJson(
      res,
      fetch(`${MYIDGO_BASE}/game/reward?slot_index=${slotIndex}`, {
        headers: goHeaders(bearerToken(req)),
      })
    );
  });

  app.get('/api/myidgo/game/stop', (req, res) => {
    forwardJson(res, fetch(`${MYIDGO_BASE}/game/stop`, { headers: goHeaders(bearerToken(req)) }));
  });

  app.get('/api/myidgo/game/leaderboard/current', (req, res) => {
    forwardJson(
      res,
      fetch(`${MYIDGO_BASE}/game/leaderboard/current`, { headers: goHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/myidgo/game/history', async (req, res) => {
    const jwt = bearerToken(req);
    const limit = encodeURIComponent(String(req.query.limit || '30'));
    const paths = [
      `/game/reward/history?limit=${limit}`,
      `/game/history?limit=${limit}`,
      `/user/reward/history?limit=${limit}`,
    ];
    try {
      let lastResp: globalThis.Response | null = null;
      for (const p of paths) {
        const r = await fetch(`${MYIDGO_BASE}${p}`, { headers: goHeaders(jwt) });
        lastResp = r;
        if (r.status !== 404) {
          const text = await r.text();
          try {
            res.status(r.status).json(JSON.parse(text));
          } catch {
            res.status(r.status).json({ raw: text });
          }
          return;
        }
      }
      res.status(lastResp?.status || 404).json({ success: false, message: 'History endpoint not found' });
    } catch (err) {
      res.status(502).json({
        success: false,
        message: err instanceof Error ? err.message : 'Unable to load MyID Go history',
      });
    }
  });

  app.get('/api/myidgo/store/categories', (req, res) => {
    forwardJson(
      res,
      fetch(`${MYIDGO_BASE}/game/store/categories`, { headers: goHeaders(bearerToken(req)) })
    );
  });

  app.get('/api/myidgo/store/items', (req, res) => {
    const categoryId = String(req.query.categoryId || '').trim();
    const url = categoryId
      ? `${MYIDGO_BASE}/game/store/categories/${encodeURIComponent(categoryId)}`
      : `${MYIDGO_BASE}/game/store/`;
    forwardJson(res, fetch(url, { headers: goHeaders(bearerToken(req)) }));
  });

  app.post('/api/myidgo/store/buy', (req, res) => {
    forwardJson(
      res,
      fetch(`${MYIDGO_BASE}/game/store/buy`, {
        method: 'POST',
        headers: goHeaders(bearerToken(req)),
        body: JSON.stringify(req.body || {}),
      })
    );
  });
}

// ============================================================================
// WEBSOCKET BRIDGES FOR CAR RACING (/ws/carracing) & FIGHTING FISH (/ws/fishio)
// ============================================================================

function computeFishIoHmac(
  sessionToken: string,
  sequence: number,
  timestamp: number,
  payload: unknown
): string {
  let key = sessionToken;
  try {
    const decoded = Buffer.from(sessionToken, 'base64').toString('utf8');
    if (decoded && /^[\x20-\x7E]+$/.test(decoded)) {
      key = decoded;
    }
  } catch {
    key = sessionToken;
  }
  const msg = `${sequence}${timestamp}${JSON.stringify(payload ?? {})}`;
  return crypto.createHmac('sha256', key).update(msg).digest('base64');
}

export function handleGameWsUpgrade(
  reqUrl: URL,
  wss: WebSocketServer,
  request: http.IncomingMessage,
  socket: Duplex,
  head: Buffer
): boolean {
  if (reqUrl.pathname === '/ws/carracing') {
    wss.handleUpgrade(request, socket, head, (clientWs) => {
      const upstreamWs = new WebSocket(CARRACING_WS, {
        headers: {
          Origin: CARRACING_BASE,
          'X-Requested-With': 'com.myentertainment.oneid',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36',
        },
      });

      upstreamWs.on('open', () => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(JSON.stringify({ type: 'BRIDGE_OPEN' }));
        }
      });

      upstreamWs.on('message', (data) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(data.toString());
        }
      });

      upstreamWs.on('error', (err) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(JSON.stringify({ type: 'BRIDGE_ERROR', message: err.message }));
          clientWs.close(1011, err.message);
        }
      });

      upstreamWs.on('close', (code, reason) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.close(code || 1000, reason?.toString() || '');
        }
      });

      clientWs.on('message', (data) => {
        if (upstreamWs.readyState === WebSocket.OPEN) {
          upstreamWs.send(data.toString());
        }
      });

      clientWs.on('close', () => {
        if (
          upstreamWs.readyState === WebSocket.OPEN ||
          upstreamWs.readyState === WebSocket.CONNECTING
        ) {
          upstreamWs.close();
        }
      });
    });
    return true;
  }

  if (reqUrl.pathname === '/ws/fishio') {
    wss.handleUpgrade(request, socket, head, (clientWs) => {
      const mode = reqUrl.searchParams.get('mode') === 'pvp' ? 'pvp' : 'game';
      const token = reqUrl.searchParams.get('token') || '';
      if (!token) {
        clientWs.close(4001, 'Missing Fish.io token');
        return;
      }

      const upstreamWs = new WebSocket(`${FISHIO_WS_BASE}/${mode}?token=${encodeURIComponent(token)}`, {
        headers: {
          Origin: FISHIO_BASE,
          'X-Requested-With': 'com.myentertainment.oneid',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36',
        },
      });

      upstreamWs.on('open', () => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(JSON.stringify({ type: 'BRIDGE_OPEN', mode }));
        }
      });

      upstreamWs.on('message', (data) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(data.toString());
        }
      });

      upstreamWs.on('error', (err) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.send(JSON.stringify({ type: 'BRIDGE_ERROR', message: err.message }));
          clientWs.close(1011, err.message);
        }
      });

      upstreamWs.on('close', (code, reason) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          clientWs.close(code || 1000, reason?.toString() || '');
        }
      });

      clientWs.on('message', (data) => {
        if (upstreamWs.readyState !== WebSocket.OPEN) return;
        const raw = data.toString();
        try {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object' && parsed._signWithToken) {
            const sessionToken = String(parsed._signWithToken);
            delete parsed._signWithToken;
            parsed.hmac = computeFishIoHmac(
              sessionToken,
              Number(parsed.sequence ?? 0),
              Number(parsed.timestamp ?? 0),
              parsed.payload ?? {}
            );
            upstreamWs.send(JSON.stringify(parsed));
            return;
          }
        } catch {
          // forward raw text
        }
        upstreamWs.send(raw);
      });

      clientWs.on('close', () => {
        if (
          upstreamWs.readyState === WebSocket.OPEN ||
          upstreamWs.readyState === WebSocket.CONNECTING
        ) {
          upstreamWs.close();
        }
      });
    });
    return true;
  }

  return false;
}
